import { DriverSidebar } from "@/components/driver/sidebar"
import { DriverHeader } from "@/components/driver/header"
import { requireAuth } from "@/lib/auth"
import { ExpenseForm } from "@/components/driver/expense-form"
import { ExpenseSummary } from "@/components/driver/expense-summary"

export default async function DriverExpensePage() {
  const user = await requireAuth("driver")

  // This would normally come from your database
  const vehicleData = {
    plateNumber: "KDG 442X",
  }

  // Mock data for the expense summary
  const incomeData = [
    {
      id: "1",
      name: "Delivery to Kaberewo",
      amount: 25000,
      date: "2023-04-10",
      paidBy: "John Doe",
      paymentMethod: "M-Pesa",
      hasReceipt: true,
      notes: "Regular delivery",
    },
    {
      id: "2",
      name: "Transport to MTRH",
      amount: 10000,
      date: "2023-04-15",
      paidBy: "Jane Smith",
      paymentMethod: "Cash",
      hasReceipt: false,
      notes: "",
    },
  ]

  const expenseData = [
    {
      id: "1",
      name: "Fuel",
      amount: 5000,
      date: "2023-04-12",
      paidBy: "Driver",
      paymentMethod: "M-Pesa",
      category: "Fuel Costs",
      hasReceipt: true,
      notes: "Full tank",
    },
    {
      id: "2",
      name: "Tire repair",
      amount: 1500,
      date: "2023-04-14",
      paidBy: "Driver",
      paymentMethod: "Cash",
      category: "Service & Maintenance",
      hasReceipt: true,
      notes: "Puncture repair",
    },
  ]

  return (
    <div className="flex h-screen">
      <DriverSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <DriverHeader user={user} vehicleInfo={vehicleData} />

        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="mx-auto max-w-7xl space-y-6">
            <h1 className="text-2xl font-bold">Expense Log</h1>

            <ExpenseForm />

            <ExpenseSummary incomeData={incomeData} expenseData={expenseData} />
          </div>

          <footer className="mt-8 rounded-lg border bg-white p-4 text-center text-sm text-gray-500">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
