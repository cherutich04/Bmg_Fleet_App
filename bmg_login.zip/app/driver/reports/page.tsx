import { DriverSidebar } from "@/components/driver/sidebar"
import { DriverHeader } from "@/components/driver/header"
import { requireAuth } from "@/lib/auth"
import { ReportsFilters } from "@/components/driver/reports-filters"
import { ReportsTable } from "@/components/driver/reports-table"
import { ReportsCharts } from "@/components/driver/reports-charts"
import { RejectedExpenses } from "@/components/driver/rejected-expenses"

export default async function DriverReportsPage() {
  const user = await requireAuth("driver")

  // This would normally come from your database
  const vehicleData = {
    plateNumber: "KDG 442X",
  }

  // Mock data for the expense reports
  const expenseData = [
    {
      id: "1",
      name: "Fuel",
      amount: 5000,
      date: "2023-04-12",
      category: "Fuel Costs",
      paymentMethod: "M-Pesa",
      hasReceipt: true,
      notes: "Full tank",
    },
    {
      id: "2",
      name: "Tire repair",
      amount: 1500,
      date: "2023-04-14",
      category: "Service & Maintenance",
      paymentMethod: "Cash",
      hasReceipt: true,
      notes: "Puncture repair",
    },
    {
      id: "3",
      name: "Oil change",
      amount: 3000,
      date: "2023-04-20",
      category: "Service & Maintenance",
      paymentMethod: "Cash",
      hasReceipt: true,
      notes: "Regular maintenance",
    },
    {
      id: "4",
      name: "Parking fee",
      amount: 200,
      date: "2023-04-22",
      category: "Miscellaneous",
      paymentMethod: "Cash",
      hasReceipt: false,
      notes: "City center parking",
    },
  ]

  // Mock data for rejected expenses
  const rejectedExpenses = [
    {
      id: "1",
      name: "Hotel accommodation",
      amount: 5000,
      date: "2023-04-18",
      category: "Miscellaneous",
      paymentMethod: "M-Pesa",
      notes: "Overnight stay",
      adminComments: "Personal expense, not related to work",
    },
    {
      id: "2",
      name: "Lunch",
      amount: 800,
      date: "2023-04-19",
      category: "Miscellaneous",
      paymentMethod: "Cash",
      notes: "Meal during trip",
      adminComments: "No receipt provided, please resubmit with receipt",
    },
  ]

  // Mock data for monthly target
  const targetData = {
    month: "April",
    targetPercentage: 15,
    amountRealized: 35000,
    targetAmount: 200000,
    tripsCompleted: 4,
  }

  // Mock data for expense analytics
  const analyticsData = {
    categories: {
      "Fuel Costs": 5000,
      "Service & Maintenance": 4500,
      Miscellaneous: 200,
    },
    monthly: [
      { month: "January", amount: 12000 },
      { month: "February", amount: 15000 },
      { month: "March", amount: 10000 },
      { month: "April", amount: 9700 },
    ],
  }

  return (
    <div className="flex h-screen">
      <DriverSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <DriverHeader user={user} vehicleInfo={vehicleData} />

        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="mx-auto max-w-7xl space-y-6">
            <h1 className="text-2xl font-bold">Reports & Analytics</h1>

            <ReportsFilters />

            <ReportsTable expenseData={expenseData} />

            <ReportsCharts targetData={targetData} analyticsData={analyticsData} />

            <RejectedExpenses rejectedExpenses={rejectedExpenses} />
          </div>

          <footer className="mt-8 rounded-lg border bg-white p-4 text-center text-sm text-gray-500">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
