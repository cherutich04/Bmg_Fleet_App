import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { cn } from "@/lib/utils"

interface Alert {
  id: string
  message: string
  type: "critical" | "warning" | "low"
  timestamp: string
}

interface AlertsProps {
  alerts: Alert[]
}

export function AdminAlerts({ alerts }: AlertsProps) {
  const getAlertStyles = (type: string) => {
    switch (type) {
      case "critical":
        return "bg-red-100 border-red-500 text-red-800"
      case "warning":
        return "bg-yellow-100 border-yellow-500 text-yellow-800"
      case "low":
        return "bg-gray-100 border-gray-500 text-gray-800"
      default:
        return "bg-gray-100 border-gray-500 text-gray-800"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Alerts Panel</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="max-h-[400px] space-y-3 overflow-auto">
          {alerts.length > 0 ? (
            alerts.map((alert) => (
              <div key={alert.id} className={cn("rounded-md border-l-4 p-3", getAlertStyles(alert.type))}>
                <div className="flex items-start justify-between">
                  <div>
                    <p className="font-medium">{alert.message}</p>
                    <p className="text-xs">{alert.timestamp}</p>
                  </div>
                  <div className="flex gap-1">
                    <Button size="sm" variant="outline" className="h-7 text-xs">
                      View
                    </Button>
                    <Button size="sm" className="h-7 text-xs">
                      Resolve
                    </Button>
                  </div>
                </div>
              </div>
            ))
          ) : (
            <p className="py-4 text-center text-sm text-muted-foreground">No alerts at this time.</p>
          )}
        </div>
      </CardContent>
    </Card>
  )
}
