import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"

interface AnalyticsData {
  mileageFuel: Array<{
    vehicle: string
    mileage: number
    fuelCost: number
  }>
}

interface AnalyticsProps {
  data: AnalyticsData
}

export function AdminAnalytics({ data }: AnalyticsProps) {
  // Find max values for scaling
  const maxMileage = Math.max(...data.mileageFuel.map((item) => item.mileage))
  const maxFuelCost = Math.max(...data.mileageFuel.map((item) => item.fuelCost))

  return (
    <div className="grid gap-6 lg:grid-cols-2">
      <Card>
        <CardHeader>
          <CardTitle>Mileage vs. Fuel Cost (Last 30 Days)</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-4">
            {data.mileageFuel.map((item) => {
              const mileageWidth = (item.mileage / maxMileage) * 100
              const fuelWidth = (item.fuelCost / maxFuelCost) * 100

              return (
                <div key={item.vehicle} className="space-y-2">
                  <div className="flex items-center justify-between">
                    <span className="font-medium">{item.vehicle}</span>
                    <span className="text-sm text-muted-foreground">
                      {item.mileage.toLocaleString()} km | Ksh. {item.fuelCost.toLocaleString()}
                    </span>
                  </div>
                  <div className="space-y-1">
                    <div className="h-2 w-full rounded-full bg-gray-200">
                      <div className="h-full rounded-full bg-blue-500" style={{ width: `${mileageWidth}%` }} />
                    </div>
                    <div className="h-2 w-full rounded-full bg-gray-200">
                      <div className="h-full rounded-full bg-green-500" style={{ width: `${fuelWidth}%` }} />
                    </div>
                  </div>
                </div>
              )
            })}
          </div>
          <div className="mt-4 flex items-center justify-center gap-6">
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-blue-500" />
              <span className="text-xs">Mileage (km)</span>
            </div>
            <div className="flex items-center gap-2">
              <div className="h-3 w-3 rounded-full bg-green-500" />
              <span className="text-xs">Fuel Cost (Ksh)</span>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Driver Efficiency Heatmap</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="h-[300px] w-full rounded-md bg-gray-200">
            {/* This would be replaced with an actual heatmap component */}
            <div className="flex h-full items-center justify-center">
              <p className="text-muted-foreground">Heatmap visualization would be integrated here</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
