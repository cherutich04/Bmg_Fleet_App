import { Card, CardContent } from "@/components/ui/card"
import { ArrowDown, ArrowUp, Car, CheckCircle, Fuel, AlertTriangle } from "lucide-react"

interface DashboardSummaryProps {
  summary: {
    activeVehicles: number
    totalVehicles: number
    maintenanceAlerts: number
    fuelEfficiency: number
    fuelTrend: "up" | "down" | "stable"
    compliance: number
  }
}

export function AdminDashboardSummary({ summary }: DashboardSummaryProps) {
  const activePercentage = (summary.activeVehicles / summary.totalVehicles) * 100

  return (
    <div className="grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
      <Card className={activePercentage >= 80 ? "border-green-500" : ""}>
        <CardContent className="flex items-center p-6">
          <div className="mr-4 rounded-full bg-blue-100 p-2">
            <Car className="h-6 w-6 text-blue-700" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Active Vehicles</p>
            <h3 className="text-2xl font-bold">
              {summary.activeVehicles}/{summary.totalVehicles}
            </h3>
            <p className="text-xs text-muted-foreground">{activePercentage.toFixed(0)}% active</p>
          </div>
        </CardContent>
      </Card>

      <Card className={summary.maintenanceAlerts > 0 ? "border-red-500" : ""}>
        <CardContent className="flex items-center p-6">
          <div className="mr-4 rounded-full bg-red-100 p-2">
            <AlertTriangle className="h-6 w-6 text-red-700" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Maintenance Alerts</p>
            <h3 className="text-2xl font-bold">{summary.maintenanceAlerts} Pending</h3>
            <p className="text-xs text-muted-foreground">Requires attention</p>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardContent className="flex items-center p-6">
          <div className="mr-4 rounded-full bg-green-100 p-2">
            <Fuel className="h-6 w-6 text-green-700" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Fuel Efficiency</p>
            <h3 className="text-2xl font-bold">Avg. {summary.fuelEfficiency}L/100km</h3>
            <p className="flex items-center text-xs">
              {summary.fuelTrend === "up" ? (
                <>
                  <ArrowUp className="mr-1 h-3 w-3 text-red-500" />
                  <span className="text-red-500">Increased from last month</span>
                </>
              ) : (
                <>
                  <ArrowDown className="mr-1 h-3 w-3 text-green-500" />
                  <span className="text-green-500">Decreased from last month</span>
                </>
              )}
            </p>
          </div>
        </CardContent>
      </Card>

      <Card className={summary.compliance >= 90 ? "border-green-500" : ""}>
        <CardContent className="flex items-center p-6">
          <div className="mr-4 rounded-full bg-purple-100 p-2">
            <CheckCircle className="h-6 w-6 text-purple-700" />
          </div>
          <div>
            <p className="text-sm font-medium text-muted-foreground">Compliance %</p>
            <h3 className="text-2xl font-bold">{summary.compliance}%</h3>
            <p className="text-xs text-muted-foreground">Valid documents & inspections</p>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
