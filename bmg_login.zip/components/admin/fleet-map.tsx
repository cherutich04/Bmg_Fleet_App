"use client"

import { useState } from "react"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"

// Mock data for the map
const vehicles = [
  {
    id: "1",
    plateNumber: "KDG 442X",
    driver: "John Doe",
    status: "active",
    location: { lat: -1.286389, lng: 36.817223 }, // Nairobi
    destination: "Mombasa",
  },
  {
    id: "2",
    plateNumber: "KCG 123Y",
    driver: "Jane Smith",
    status: "idle",
    location: { lat: -1.292066, lng: 36.821945 }, // Nairobi area
  },
  {
    id: "3",
    plateNumber: "KBZ 789Z",
    driver: "Bob Johnson",
    status: "maintenance",
    location: { lat: -1.28479, lng: 36.823875 }, // Nairobi area
  },
]

export function AdminFleetMap() {
  const [selectedVehicle, setSelectedVehicle] = useState<string | null>(null)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500 text-white"
      case "idle":
        return "bg-yellow-500 text-white"
      case "maintenance":
        return "bg-red-500 text-white"
      default:
        return "bg-gray-500 text-white"
    }
  }

  const getStatusEmoji = (status: string) => {
    switch (status) {
      case "active":
        return "🟢"
      case "idle":
        return "🟡"
      case "maintenance":
        return "🔴"
      default:
        return "⚪"
    }
  }

  return (
    <Card>
      <CardHeader>
        <CardTitle>Live Fleet Map</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="relative h-[400px] w-full rounded-md bg-gray-200">
          {/* This would be replaced with an actual map component */}
          <div className="flex h-full items-center justify-center">
            <p className="text-muted-foreground">Google Maps would be integrated here</p>
          </div>

          {/* Vehicle markers simulation */}
          <div className="absolute bottom-4 left-4 right-4 rounded-md bg-white p-4 shadow-md">
            <div className="mb-2 flex items-center gap-4">
              <div className="flex items-center gap-1">
                <span>🟢</span>
                <span className="text-xs">Active</span>
              </div>
              <div className="flex items-center gap-1">
                <span>🟡</span>
                <span className="text-xs">Idle</span>
              </div>
              <div className="flex items-center gap-1">
                <span>🔴</span>
                <span className="text-xs">Maintenance</span>
              </div>
            </div>

            <div className="space-y-2">
              {vehicles.map((vehicle) => (
                <div
                  key={vehicle.id}
                  className={`cursor-pointer rounded-md border p-2 transition-colors ${
                    selectedVehicle === vehicle.id ? "border-primary bg-muted" : ""
                  }`}
                  onClick={() => setSelectedVehicle(vehicle.id)}
                >
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <span>{getStatusEmoji(vehicle.status)}</span>
                      <span className="font-medium">{vehicle.plateNumber}</span>
                    </div>
                    <Badge className={getStatusColor(vehicle.status)}>
                      {vehicle.status.charAt(0).toUpperCase() + vehicle.status.slice(1)}
                    </Badge>
                  </div>
                  <div className="mt-1 text-xs text-muted-foreground">
                    Driver: {vehicle.driver}
                    {vehicle.destination && <span> | Destination: {vehicle.destination}</span>}
                  </div>
                </div>
              ))}
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
