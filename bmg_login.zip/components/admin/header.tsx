"use client"

import Image from "next/image"
import { Frame } from "lucide-react"
import type { User } from "@/lib/auth"

interface HeaderProps {
  user: User
}

export function AdminHeader({ user }: HeaderProps) {
  return (
    <header className="flex flex-col border-b bg-white p-4 md:flex-row md:items-center md:justify-between">
      <div className="mb-4 flex items-center md:mb-0">
        <Frame className="mr-2 h-6 w-6" />
        <h1 className="text-xl font-bold">BMG FLEET MANAGEMENT</h1>
      </div>

      <div className="flex items-center gap-4">
        <span className="text-sm font-medium">
          Admin: {user.firstName} {user.lastName}
        </span>
        <div className="h-10 w-10 overflow-hidden rounded-full bg-muted">
          <Image
            src="/placeholder.svg?height=40&width=40"
            alt="Profile"
            width={40}
            height={40}
            className="h-full w-full object-cover"
          />
        </div>
      </div>
    </header>
  )
}
