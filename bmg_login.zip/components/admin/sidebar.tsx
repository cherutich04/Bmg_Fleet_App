"use client"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import {
  ChevronLeft,
  ChevronRight,
  LayoutDashboard,
  Car,
  FolderPlus,
  UserPlus,
  ClipboardCheck,
  MessageSquare,
  LogOut,
} from "lucide-react"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"

export function AdminSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  const navItems = [
    {
      name: "Dashboard",
      href: "/admin/dashboard",
      icon: LayoutDashboard,
    },
    {
      name: "Assign Vehicle & Target",
      href: "/admin/assign",
      icon: Car,
    },
    {
      name: "Projects",
      href: "/admin/projects",
      icon: FolderPlus,
    },
    {
      name: "Drivers",
      href: "/admin/drivers",
      icon: UserPlus,
    },
    {
      name: "Review Expenses",
      href: "/admin/review",
      icon: ClipboardCheck,
    },
    {
      name: "Messages",
      href: "/admin/messages",
      icon: MessageSquare,
    },
    {
      name: "Logout",
      href: "/admin/logout",
      icon: LogOut,
    },
  ]

  return (
    <div
      className={cn(
        "flex h-screen flex-col border-r bg-gradient-to-b from-blue-50 to-indigo-50 transition-all duration-300",
        collapsed ? "w-16" : "w-64",
      )}
    >
      <div className="flex h-16 items-center justify-between border-b px-4">
        {!collapsed && <span className="text-lg font-semibold">BMG Admin</span>}
        <Button variant="ghost" size="icon" onClick={() => setCollapsed(!collapsed)} className="ml-auto">
          {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>

      <nav className="flex-1 space-y-1 p-2">
        {navItems.map((item) => {
          const isActive = pathname === item.href

          return (
            <Link
              key={item.href}
              href={item.href}
              className={cn(
                "flex items-center rounded-md px-3 py-2 text-sm font-medium transition-colors",
                isActive
                  ? "bg-gradient-to-r from-blue-100 to-indigo-100 text-primary"
                  : "text-muted-foreground hover:bg-muted hover:text-primary",
              )}
            >
              <item.icon className={cn("h-5 w-5", collapsed ? "mx-auto" : "mr-3")} />
              {!collapsed && <span>{item.name}</span>}
            </Link>
          )
        })}
      </nav>
    </div>
  )
}
