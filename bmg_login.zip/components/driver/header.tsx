"use client"

import { useState } from "react"
import Image from "next/image"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import type { User } from "@/lib/auth"

interface HeaderProps {
  user: User
  vehicleInfo?: {
    plateNumber: string
  }
}

export function DriverHeader({ user, vehicleInfo }: HeaderProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [time, setTime] = useState<string>(format(new Date(), "HH:mm:ss"))

  // Update time every second
  useState(() => {
    const timer = setInterval(() => {
      setTime(format(new Date(), "HH:mm:ss"))
    }, 1000)

    return () => clearInterval(timer)
  })

  return (
    <header className="flex flex-col border-b bg-white p-4 md:flex-row md:items-center md:justify-between">
      <div className="mb-4 text-center md:mb-0 md:text-left">
        <h1 className="text-xl font-bold">BMG FLEET MANAGEMENT APP</h1>
      </div>

      <div className="flex flex-col items-center gap-4 md:flex-row">
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center">
            <div className="h-12 w-12 overflow-hidden rounded-full bg-muted">
              <Image
                src="/placeholder.svg?height=48&width=48"
                alt="Profile"
                width={48}
                height={48}
                className="h-full w-full object-cover"
              />
            </div>
            <span className="mt-1 text-sm">
              Driver: {user.lastName} {user.firstName}
            </span>
          </div>
        </div>

        {vehicleInfo && (
          <div className="text-center md:text-right">
            <p className="text-sm">
              Driver: {user.lastName} - {vehicleInfo.plateNumber}
            </p>
          </div>
        )}

        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium">{time}</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="h-8 w-8 p-0">
                  <CalendarIcon className="h-4 w-4" />
                  <span className="sr-only">Open calendar</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
              </PopoverContent>
            </Popover>
          </div>
          <span className="mt-1 text-xs">{date ? format(date, "PPP") : "Select a date"}</span>
        </div>
      </div>
    </header>
  )
}
