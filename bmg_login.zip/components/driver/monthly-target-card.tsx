import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface MonthlyTargetCardProps {
  targetData: {
    month: string
    targetPercentage: number
    amountRealized: number
    targetAmount: number
    tripsCompleted: number
    safetyScore?: number
    location?: {
      lastUpdated: string
      destination?: string
    }
  }
}

export function MonthlyTargetCard({ targetData }: MonthlyTargetCardProps) {
  const getProgressColor = (percentage: number) => {
    if (percentage <= 25) return "bg-red-500"
    if (percentage <= 50) return "bg-orange-500"
    if (percentage <= 75) return "bg-emerald-500"
    return "bg-green-700"
  }

  return (
    <Card className="bg-teal-50">
      <CardHeader>
        <CardTitle>MONTHLY TARGET</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-semibold">Month: {targetData.month}</h3>
          <div className="mt-2 space-y-3">
            <div>
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium">Target Achieved: {targetData.targetPercentage}%</span>
              </div>
              <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-gray-200">
                <div
                  className={cn("h-full", getProgressColor(targetData.targetPercentage))}
                  style={{ width: `${targetData.targetPercentage}%` }}
                />
              </div>
            </div>

            <div className="flex items-center justify-between">
              <div className="text-sm">
                <span className="font-medium">Amount Realized:</span>{" "}
                <span className="text-amber-700">Ksh. {targetData.amountRealized.toLocaleString()}</span>
              </div>
              <div className="text-sm">
                <span className="font-medium">Set Monthly Target:</span>{" "}
                <span className="text-amber-700">Ksh. {targetData.targetAmount.toLocaleString()}</span>
              </div>
            </div>

            <div className="text-sm">
              <span className="font-medium">Trips Completed:</span> {targetData.tripsCompleted} Trips
            </div>

            {targetData.safetyScore !== undefined && (
              <div className="text-sm">
                <span className="font-medium">Safety Score:</span> {targetData.safetyScore}
              </div>
            )}
          </div>
        </div>

        <div>
          <h3 className="font-semibold">Map snippet</h3>
          <div className="mt-2 space-y-2">
            <div className="h-32 w-full rounded bg-gray-200">
              {/* Map placeholder */}
              <div className="flex h-full items-center justify-center text-sm text-gray-500">Location Map</div>
            </div>

            {targetData.location && (
              <div className="space-y-1 text-sm">
                <div>
                  <span className="font-medium">Last updated:</span> {targetData.location.lastUpdated}
                </div>
                {targetData.location.destination && (
                  <div>
                    <span className="font-medium">Enroute to:</span> {targetData.location.destination}
                  </div>
                )}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
