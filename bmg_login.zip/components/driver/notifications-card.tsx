import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Alert {
  id: string
  message: string
  type: "maintenance" | "other"
  severity: "high" | "medium" | "low"
}

interface Notification {
  id: string
  message: string
  timestamp: string
}

interface NotificationsCardProps {
  alerts: Alert[]
  notifications: Notification[]
}

export function NotificationsCard({ alerts, notifications }: NotificationsCardProps) {
  const getAlertColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-red-600"
      case "medium":
        return "text-orange-600"
      case "low":
        return "text-green-600"
      default:
        return "text-gray-600"
    }
  }

  return (
    <Card className="bg-cyan-50">
      <CardHeader>
        <CardTitle>NOTIFICATIONS AND ALERTS</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="font-semibold">Alerts:</h3>
          <div className="mt-2 space-y-2">
            <div>
              <h4 className="text-sm font-medium">Maintenance Alerts</h4>
              <ul className="mt-1 space-y-1">
                {alerts
                  .filter((alert) => alert.type === "maintenance")
                  .map((alert) => (
                    <li key={alert.id} className={cn("text-sm", getAlertColor(alert.severity))}>
                      {alert.message}
                    </li>
                  ))}
                {alerts.filter((alert) => alert.type === "maintenance").length === 0 && (
                  <li className="text-sm text-gray-500">No maintenance alerts</li>
                )}
              </ul>
            </div>

            <div>
              <h4 className="text-sm font-medium">Other Alerts</h4>
              <ul className="mt-1 space-y-1">
                {alerts
                  .filter((alert) => alert.type === "other")
                  .map((alert) => (
                    <li key={alert.id} className={cn("text-sm", getAlertColor(alert.severity))}>
                      {alert.message}
                    </li>
                  ))}
                {alerts.filter((alert) => alert.type === "other").length === 0 && (
                  <li className="text-sm text-gray-500">No other alerts</li>
                )}
              </ul>
            </div>
          </div>
        </div>

        <div>
          <h3 className="font-semibold">Notifications:</h3>
          <div className="mt-2">
            <h4 className="text-sm font-medium">Recent Activities</h4>
            <ul className="mt-1 space-y-1">
              {notifications.map((notification) => (
                <li key={notification.id} className="text-sm">
                  {notification.message}
                  <span className="ml-1 text-xs text-gray-500">({notification.timestamp})</span>
                </li>
              ))}
              {notifications.length === 0 && <li className="text-sm text-gray-500">No recent activities</li>}
            </ul>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
