import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { format } from "date-fns"

interface RejectedExpense {
  id: string
  name: string
  amount: number
  date: string
  category: string
  paymentMethod: string
  notes: string
  adminComments: string
}

interface RejectedExpensesProps {
  rejectedExpenses: RejectedExpense[]
}

export function RejectedExpenses({ rejectedExpenses }: RejectedExpensesProps) {
  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd MMM yyyy")
    } catch (error) {
      return dateString
    }
  }

  const formatPaymentMethod = (method: string) => {
    switch (method) {
      case "mpesa":
        return "M-Pesa"
      case "bank":
        return "Bank Transfer"
      default:
        return method.charAt(0).toUpperCase() + method.slice(1)
    }
  }

  return (
    <Card className="bg-red-50">
      <CardHeader>
        <CardTitle>Rejected Expenses</CardTitle>
      </CardHeader>
      <CardContent>
        {rejectedExpenses.length > 0 ? (
          <div className="rounded-md border">
            <Table>
              <TableHeader>
                <TableRow>
                  <TableHead>Expense Name</TableHead>
                  <TableHead>Date</TableHead>
                  <TableHead>Amount (Kshs)</TableHead>
                  <TableHead>Category</TableHead>
                  <TableHead>Payment Method</TableHead>
                  <TableHead>Notes</TableHead>
                  <TableHead>Admin Comments</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {rejectedExpenses.map((item) => (
                  <TableRow key={item.id}>
                    <TableCell className="font-medium">{item.name}</TableCell>
                    <TableCell>{formatDate(item.date)}</TableCell>
                    <TableCell>{item.amount.toLocaleString()}</TableCell>
                    <TableCell>{item.category}</TableCell>
                    <TableCell>{formatPaymentMethod(item.paymentMethod)}</TableCell>
                    <TableCell>{item.notes || "-"}</TableCell>
                    <TableCell className="text-red-600">{item.adminComments}</TableCell>
                  </TableRow>
                ))}
              </TableBody>
            </Table>
          </div>
        ) : (
          <div className="py-4 text-center text-sm text-muted-foreground">No rejected expenses found.</div>
        )}
      </CardContent>
    </Card>
  )
}
