"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface TargetData {
  month: string
  targetPercentage: number
  amountRealized: number
  targetAmount: number
  tripsCompleted: number
}

interface AnalyticsData {
  categories: Record<string, number>
  monthly: Array<{ month: string; amount: number }>
}

interface ReportsChartsProps {
  targetData: TargetData
  analyticsData: AnalyticsData
}

export function ReportsCharts({ targetData, analyticsData }: ReportsChartsProps) {
  const getProgressColor = (percentage: number) => {
    if (percentage <= 25) return "bg-red-500"
    if (percentage <= 50) return "bg-orange-500"
    if (percentage <= 75) return "bg-emerald-500"
    return "bg-green-700"
  }

  // Calculate total for pie chart
  const totalExpenses = Object.values(analyticsData.categories).reduce((sum, amount) => sum + amount, 0)

  // Find max value for bar chart scaling
  const maxMonthlyAmount = Math.max(...analyticsData.monthly.map((item) => item.amount))

  return (
    <div className="grid gap-6 md:grid-cols-2">
      <Card className="bg-teal-50">
        <CardHeader>
          <CardTitle>Monthly Target</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div>
            <h3 className="font-semibold">Month: {targetData.month}</h3>
            <div className="mt-2 space-y-3">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Target Achieved: {targetData.targetPercentage}%</span>
                </div>
                <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-gray-200">
                  <div
                    className={cn("h-full", getProgressColor(targetData.targetPercentage))}
                    style={{ width: `${targetData.targetPercentage}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-medium">Amount Realized:</span>{" "}
                  <span className="text-amber-700">Ksh. {targetData.amountRealized.toLocaleString()}</span>
                </div>
                <div className="text-sm">
                  <span className="font-medium">Set Monthly Target:</span>{" "}
                  <span className="text-amber-700">Ksh. {targetData.targetAmount.toLocaleString()}</span>
                </div>
              </div>

              <div className="text-sm">
                <span className="font-medium">Trips Completed:</span> {targetData.tripsCompleted} Trips
              </div>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Expense Analytics</CardTitle>
        </CardHeader>
        <CardContent>
          <div className="space-y-6">
            <div>
              <h3 className="mb-3 font-semibold">Expenses by Category</h3>
              <div className="space-y-2">
                {Object.entries(analyticsData.categories).map(([category, amount]) => {
                  const percentage = totalExpenses > 0 ? (amount / totalExpenses) * 100 : 0
                  return (
                    <div key={category} className="space-y-1">
                      <div className="flex items-center justify-between text-sm">
                        <span>{category}</span>
                        <span>
                          Ksh. {amount.toLocaleString()} ({percentage.toFixed(1)}%)
                        </span>
                      </div>
                      <div className="h-2 w-full overflow-hidden rounded-full bg-gray-200">
                        <div className="h-full bg-blue-500" style={{ width: `${percentage}%` }} />
                      </div>
                    </div>
                  )
                })}
              </div>
            </div>

            <div>
              <h3 className="mb-3 font-semibold">Monthly Expense Trend</h3>
              <div className="flex h-40 items-end gap-2">
                {analyticsData.monthly.map((item) => {
                  const height = maxMonthlyAmount > 0 ? (item.amount / maxMonthlyAmount) * 100 : 0
                  return (
                    <div key={item.month} className="flex flex-1 flex-col items-center">
                      <div className="w-full rounded-t bg-blue-500" style={{ height: `${height}%` }} />
                      <div className="mt-2 text-xs">{item.month.substring(0, 3)}</div>
                    </div>
                  )
                })}
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
