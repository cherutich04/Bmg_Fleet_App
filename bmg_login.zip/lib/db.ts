// This is a placeholder for your database connection
// You'll replace this with your actual PostgreSQL connection logic

import { Pool } from "pg"

// This will be configured by the user locally
let pool: Pool | null = null

export function getDb() {
  if (!pool) {
    // These values should be replaced with environment variables
    pool = new Pool({
      host: process.env.POSTGRES_HOST || "localhost",
      port: Number.parseInt(process.env.POSTGRES_PORT || "5432"),
      database: process.env.POSTGRES_DATABASE || "fleet_management",
      user: process.env.POSTGRES_USER || "postgres",
      password: process.env.POSTGRES_PASSWORD || "postgres",
    })
  }

  return pool
}

export async function query(text: string, params?: any[]) {
  const db = getDb()
  try {
    const result = await db.query(text, params)
    return result
  } catch (error) {
    console.error("Database query error:", error)
    throw error
  }
}
