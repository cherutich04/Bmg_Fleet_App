"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Checkbox } from "@/components/ui/checkbox"

// Vehicle assignment form schema
const assignVehicleSchema = z.object({
  driverId: z.string({
    required_error: "Please select a driver",
  }),
  vehicleId: z.string({
    required_error: "Please select a vehicle",
  }),
  startDate: z.date({
    required_error: "Please select a start date",
  }),
  endDate: z.date().optional(),
})

// Monthly target form schema
const monthlyTargetSchema = z.object({
  driverId: z.string({
    required_error: "Please select a driver",
  }),
  month: z.string({
    required_error: "Please select a month",
  }),
  year: z.string({
    required_error: "Please select a year",
  }),
  amount: z.coerce.number().positive({
    message: "Amount must be positive",
  }),
})

// Task assignment form schema
const taskAssignmentSchema = z.object({
  driverIds: z.array(z.string()).nonempty({
    message: "Please select at least one driver",
  }),
  description: z.string().min(5, {
    message: "Description must be at least 5 characters",
  }),
  startDate: z.date({
    required_error: "Please select a start date",
  }),
  endDate: z.date({
    required_error: "Please select an end date",
  }),
  priority: z.enum(["HIGH", "MEDIUM", "LOW"], {
    required_error: "Please select a priority",
  }),
})

// Mock data for drivers
const driversData = [
  { id: "1", name: "John Doe" },
  { id: "2", name: "Jane Smith" },
  { id: "3", name: "Robert Johnson" },
]

// Mock data for vehicles
const vehiclesData = [
  { id: "1", plateNumber: "KDG 442X", model: "Land Cruiser (LC-79)", status: "ACTIVE" },
  { id: "2", plateNumber: "KCG 123Y", model: "Toyota Hilux", status: "ACTIVE" },
  { id: "3", plateNumber: "KBZ 789Z", model: "Isuzu D-Max", status: "MAINTENANCE" },
]

// Mock data for assignments
const assignmentsData = [
  {
    id: "1",
    driver: "John Doe",
    vehicle: "KDG 442X",
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    status: "ACTIVE",
  },
  {
    id: "2",
    driver: "Jane Smith",
    vehicle: "KCG 123Y",
    startDate: "2023-02-15",
    endDate: null,
    status: "ACTIVE",
  },
]

// Mock data for targets
const targetsData = [
  {
    id: "1",
    driver: "John Doe",
    month: "April",
    year: "2023",
    amount: 200000,
    achieved: 35000,
    percentage: 17.5,
  },
  {
    id: "2",
    driver: "Jane Smith",
    month: "April",
    year: "2023",
    amount: 150000,
    achieved: 75000,
    percentage: 50,
  },
]

// Mock data for tasks
const tasksData = [
  {
    id: "1",
    description: "Deliver construction materials to Kaberewo site",
    drivers: ["John Doe"],
    startDate: "2023-04-15",
    endDate: "2023-04-16",
    priority: "HIGH",
    status: "IN_PROGRESS",
  },
  {
    id: "2",
    description: "Transport medical supplies to MTRH",
    drivers: ["Jane Smith", "Robert Johnson"],
    startDate: "2023-04-20",
    endDate: "2023-04-21",
    priority: "MEDIUM",
    status: "PENDING",
  },
]

export default function AssignPage() {
  const [activeTab, setActiveTab] = useState("vehicle")

  // Vehicle assignment form
  const assignVehicleForm = useForm<z.infer<typeof assignVehicleSchema>>({
    resolver: zodResolver(assignVehicleSchema),
    defaultValues: {
      startDate: new Date(),
    },
  })

  // Monthly target form
  const monthlyTargetForm = useForm<z.infer<typeof monthlyTargetSchema>>({
    resolver: zodResolver(monthlyTargetSchema),
    defaultValues: {
      month: new Date().getMonth().toString(),
      year: new Date().getFullYear().toString(),
    },
  })

  // Task assignment form
  const taskAssignmentForm = useForm<z.infer<typeof taskAssignmentSchema>>({
    resolver: zodResolver(taskAssignmentSchema),
    defaultValues: {
      driverIds: [],
      startDate: new Date(),
      endDate: new Date(new Date().setDate(new Date().getDate() + 1)),
      priority: "MEDIUM",
    },
  })

  // Submit vehicle assignment form
  const onAssignVehicleSubmit = (data: z.infer<typeof assignVehicleSchema>) => {
    console.log("Vehicle assignment submitted:", data)
    // In a real app, you would send this data to your API
    assignVehicleForm.reset()
  }

  // Submit monthly target form
  const onMonthlyTargetSubmit = (data: z.infer<typeof monthlyTargetSchema>) => {
    console.log("Monthly target submitted:", data)
    // In a real app, you would send this data to your API
    monthlyTargetForm.reset()
  }

  // Submit task assignment form
  const onTaskAssignmentSubmit = (data: z.infer<typeof taskAssignmentSchema>) => {
    console.log("Task assignment submitted:", data)
    // In a real app, you would send this data to your API
    taskAssignmentForm.reset()
  }

  // Generate month options
  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  // Generate year options (current year and next 5 years)
  const currentYear = new Date().getFullYear()
  const years = Array.from({ length: 6 }, (_, i) => (currentYear + i).toString())

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Assign Vehicle & Target</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="vehicle">Assign Vehicle</TabsTrigger>
          <TabsTrigger value="target">Set Monthly Target</TabsTrigger>
          <TabsTrigger value="task">Assign Task</TabsTrigger>
        </TabsList>

        <TabsContent value="vehicle" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Assign Vehicle to Driver</CardTitle>
              <CardDescription>Assign a vehicle to a driver for a specific period</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...assignVehicleForm}>
                <form onSubmit={assignVehicleForm.handleSubmit(onAssignVehicleSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={assignVehicleForm.control}
                      name="driverId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Driver</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select driver" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {driversData.map((driver) => (
                                <SelectItem key={driver.id} value={driver.id}>
                                  {driver.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={assignVehicleForm.control}
                      name="vehicleId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Vehicle</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select vehicle" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {vehiclesData.map((vehicle) => (
                                <SelectItem
                                  key={vehicle.id}
                                  value={vehicle.id}
                                  disabled={vehicle.status === "MAINTENANCE"}
                                >
                                  {vehicle.plateNumber} - {vehicle.model}
                                  {vehicle.status === "MAINTENANCE" && " (Under Maintenance)"}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={assignVehicleForm.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Assignment Start Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={assignVehicleForm.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Assignment End Date (Optional)</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormDescription>Leave empty for indefinite assignment</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button type="submit">Assign Vehicle</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Current Assignments</CardTitle>
              <CardDescription>List of current vehicle assignments</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {assignmentsData.map((assignment) => (
                    <TableRow key={assignment.id}>
                      <TableCell>{assignment.driver}</TableCell>
                      <TableCell>{assignment.vehicle}</TableCell>
                      <TableCell>{assignment.startDate}</TableCell>
                      <TableCell>{assignment.endDate || "Indefinite"}</TableCell>
                      <TableCell>
                        <Badge className="bg-green-100 text-green-800">{assignment.status}</Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="target" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Set Monthly Target</CardTitle>
              <CardDescription>Set a monthly target amount for a driver</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...monthlyTargetForm}>
                <form onSubmit={monthlyTargetForm.handleSubmit(onMonthlyTargetSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={monthlyTargetForm.control}
                      name="driverId"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Driver</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select driver" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {driversData.map((driver) => (
                                <SelectItem key={driver.id} value={driver.id}>
                                  {driver.name}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={monthlyTargetForm.control}
                      name="month"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Month</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select month" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {months.map((month, index) => (
                                <SelectItem key={index} value={index.toString()}>
                                  {month}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={monthlyTargetForm.control}
                      name="year"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Year</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select year" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              {years.map((year) => (
                                <SelectItem key={year} value={year}>
                                  {year}
                                </SelectItem>
                              ))}
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={monthlyTargetForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Target Amount (Kshs)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="Enter target amount" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button type="submit">Save Target</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Current Targets</CardTitle>
              <CardDescription>List of current monthly targets</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>Month</TableHead>
                    <TableHead>Year</TableHead>
                    <TableHead>Target Amount (Kshs)</TableHead>
                    <TableHead>Achieved (Kshs)</TableHead>
                    <TableHead>Progress</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {targetsData.map((target) => (
                    <TableRow key={target.id}>
                      <TableCell>{target.driver}</TableCell>
                      <TableCell>{target.month}</TableCell>
                      <TableCell>{target.year}</TableCell>
                      <TableCell>{target.amount.toLocaleString()}</TableCell>
                      <TableCell>{target.achieved.toLocaleString()}</TableCell>
                      <TableCell>
                        <div className="w-full bg-gray-200 rounded-full h-2.5">
                          <div
                            className={cn(
                              "h-2.5 rounded-full",
                              target.percentage <= 25
                                ? "bg-red-500"
                                : target.percentage <= 50
                                  ? "bg-orange-500"
                                  : target.percentage <= 75
                                    ? "bg-emerald-500"
                                    : "bg-green-700",
                            )}
                            style={{ width: `${target.percentage}%` }}
                          ></div>
                        </div>
                        <span className="text-xs">{target.percentage}%</span>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="task" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Assign Task</CardTitle>
              <CardDescription>Assign a task to one or more drivers</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...taskAssignmentForm}>
                <form onSubmit={taskAssignmentForm.handleSubmit(onTaskAssignmentSubmit)} className="space-y-4">
                  <FormField
                    control={taskAssignmentForm.control}
                    name="driverIds"
                    render={() => (
                      <FormItem>
                        <div className="mb-4">
                          <FormLabel className="text-base">Drivers</FormLabel>
                          <FormDescription>Select the drivers to assign this task to</FormDescription>
                        </div>
                        <div className="space-y-2">
                          {driversData.map((driver) => (
                            <FormField
                              key={driver.id}
                              control={taskAssignmentForm.control}
                              name="driverIds"
                              render={({ field }) => {
                                return (
                                  <FormItem
                                    key={driver.id}
                                    className="flex flex-row items-start space-x-3 space-y-0 rounded-md border p-4"
                                  >
                                    <FormControl>
                                      <Checkbox
                                        checked={field.value?.includes(driver.id)}
                                        onCheckedChange={(checked) => {
                                          return checked
                                            ? field.onChange([...field.value, driver.id])
                                            : field.onChange(field.value?.filter((value) => value !== driver.id))
                                        }}
                                      />
                                    </FormControl>
                                    <div className="space-y-1 leading-none">
                                      <FormLabel className="cursor-pointer">{driver.name}</FormLabel>
                                    </div>
                                  </FormItem>
                                )
                              }}
                            />
                          ))}
                        </div>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <FormField
                    control={taskAssignmentForm.control}
                    name="description"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Task Description</FormLabel>
                        <FormControl>
                          <Input placeholder="Enter task description" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={taskAssignmentForm.control}
                      name="startDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Start Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={taskAssignmentForm.control}
                      name="endDate"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>End Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={taskAssignmentForm.control}
                      name="priority"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Priority</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select priority" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="HIGH">High</SelectItem>
                              <SelectItem value="MEDIUM">Medium</SelectItem>
                              <SelectItem value="LOW">Low</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <Button type="submit">Assign Task</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Current Tasks</CardTitle>
              <CardDescription>List of current assigned tasks</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Description</TableHead>
                    <TableHead>Assigned To</TableHead>
                    <TableHead>Start Date</TableHead>
                    <TableHead>End Date</TableHead>
                    <TableHead>Priority</TableHead>
                    <TableHead>Status</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {tasksData.map((task) => (
                    <TableRow key={task.id}>
                      <TableCell>{task.description}</TableCell>
                      <TableCell>{task.drivers.join(", ")}</TableCell>
                      <TableCell>{task.startDate}</TableCell>
                      <TableCell>{task.endDate}</TableCell>
                      <TableCell>
                        <Badge
                          className={cn(
                            task.priority === "HIGH"
                              ? "bg-red-100 text-red-800"
                              : task.priority === "MEDIUM"
                                ? "bg-yellow-100 text-yellow-800"
                                : "bg-blue-100 text-blue-800",
                          )}
                        >
                          {task.priority}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Badge
                          className={cn(
                            task.status === "IN_PROGRESS"
                              ? "bg-green-100 text-green-800"
                              : task.status === "PENDING"
                                ? "bg-yellow-100 text-yellow-800"
                                : task.status === "COMPLETED"
                                  ? "bg-blue-100 text-blue-800"
                                  : "bg-gray-100 text-gray-800",
                          )}
                        >
                          {task.status.replace("_", " ")}
                        </Badge>
                      </TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
