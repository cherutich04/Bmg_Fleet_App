"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { Badge } from "@/components/ui/badge"
import { Car, AlertTriangle, Droplet, FileCheck, MoreHorizontal, MapPin } from "lucide-react"

// Mock data for the dashboard
const summaryData = {
  activeVehicles: 24,
  totalVehicles: 30,
  maintenanceAlerts: 3,
  fuelEfficiency: 8.5,
  fuelTrend: "up",
  compliancePercentage: 92,
}

const alertsData = [
  {
    id: "1",
    priority: "critical",
    message: "KDG 442X - Engine Fault (Check Now)",
    timestamp: "10 minutes ago",
  },
  {
    id: "2",
    priority: "warning",
    message: "M-Pesa Payment Failed - Ksh 15,000 (Retry)",
    timestamp: "2 hours ago",
  },
  {
    id: "3",
    priority: "low",
    message: "Insurance Renewal Due in 7 Days",
    timestamp: "1 day ago",
  },
]

const vehiclesData = [
  {
    id: "1",
    plateNumber: "KDG 442X",
    driver: "John Doe",
    status: "active",
    location: { lat: -1.286389, lng: 36.817223 },
    destination: "Kaberewo",
  },
  {
    id: "2",
    plateNumber: "KCG 123Y",
    driver: "Jane Smith",
    status: "idle",
    location: { lat: -1.296389, lng: 36.827223 },
    destination: null,
  },
  {
    id: "3",
    plateNumber: "KBZ 789Z",
    driver: "Robert Johnson",
    status: "maintenance",
    location: { lat: -1.276389, lng: 36.807223 },
    destination: null,
  },
]

export default function AdminDashboard() {
  const [activeTab, setActiveTab] = useState("overview")

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Admin Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Vehicles</CardTitle>
            <CardDescription className="text-3xl font-bold">
              {summaryData.activeVehicles}/{summaryData.totalVehicles}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Badge className="bg-green-100 text-green-800 hover:bg-green-200">
                {Math.round((summaryData.activeVehicles / summaryData.totalVehicles) * 100)}% Active
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Maintenance Alerts</CardTitle>
            <CardDescription className="text-3xl font-bold">{summaryData.maintenanceAlerts} Pending</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Badge className="bg-red-100 text-red-800 hover:bg-red-200">
                <AlertTriangle className="h-3 w-3 mr-1" />
                Requires Attention
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Fuel Efficiency</CardTitle>
            <CardDescription className="text-3xl font-bold">Avg. {summaryData.fuelEfficiency}L/100km</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Badge
                className={
                  summaryData.fuelTrend === "down" ? "bg-green-100 text-green-800" : "bg-yellow-100 text-yellow-800"
                }
              >
                <Droplet className="h-3 w-3 mr-1" />
                {summaryData.fuelTrend === "down" ? "Improving" : "Increasing"}
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Compliance %</CardTitle>
            <CardDescription className="text-3xl font-bold">{summaryData.compliancePercentage}%</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Badge className="bg-blue-100 text-blue-800 hover:bg-blue-200">
                <FileCheck className="h-3 w-3 mr-1" />
                Documents Valid
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Live Fleet Map</CardTitle>
              <CardDescription>Real-time location of all vehicles</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-[400px] bg-gray-100 rounded-md flex items-center justify-center">
                <div className="text-center text-gray-500">
                  <MapPin className="h-8 w-8 mx-auto mb-2" />
                  <p>Map placeholder - Google Maps would be integrated here</p>
                </div>
              </div>

              <div className="mt-4 flex flex-wrap gap-4">
                <div className="flex items-center">
                  <span className="h-3 w-3 rounded-full bg-green-500 mr-2"></span>
                  <span className="text-sm">Active/In Transit</span>
                </div>
                <div className="flex items-center">
                  <span className="h-3 w-3 rounded-full bg-yellow-500 mr-2"></span>
                  <span className="text-sm">Idle</span>
                </div>
                <div className="flex items-center">
                  <span className="h-3 w-3 rounded-full bg-red-500 mr-2"></span>
                  <span className="text-sm">Maintenance</span>
                </div>
              </div>

              <div className="mt-4 space-y-2">
                <h3 className="text-sm font-medium">Vehicle Status</h3>
                <div className="space-y-2">
                  {vehiclesData.map((vehicle) => (
                    <div key={vehicle.id} className="flex items-center justify-between p-2 bg-gray-50 rounded-md">
                      <div className="flex items-center">
                        <span
                          className={`h-3 w-3 rounded-full mr-2 ${
                            vehicle.status === "active"
                              ? "bg-green-500"
                              : vehicle.status === "idle"
                                ? "bg-yellow-500"
                                : "bg-red-500"
                          }`}
                        ></span>
                        <div>
                          <p className="font-medium">{vehicle.plateNumber}</p>
                          <p className="text-xs text-gray-500">Driver: {vehicle.driver}</p>
                        </div>
                      </div>
                      <div className="text-right text-sm">
                        {vehicle.destination && <p className="text-xs">To: {vehicle.destination}</p>}
                        <div className="flex items-center">
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <MoreHorizontal className="h-4 w-4" />
                          </Button>
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            </CardContent>
          </Card>
        </div>

        <div>
          <Card>
            <CardHeader>
              <CardTitle>Alerts Panel</CardTitle>
              <CardDescription>Prioritized alerts requiring attention</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {alertsData.map((alert) => (
                  <Alert
                    key={alert.id}
                    variant={
                      alert.priority === "critical"
                        ? "destructive"
                        : alert.priority === "warning"
                          ? "warning"
                          : "default"
                    }
                  >
                    <AlertTriangle className="h-4 w-4" />
                    <AlertTitle>
                      {alert.priority === "critical"
                        ? "Critical Alert"
                        : alert.priority === "warning"
                          ? "Warning"
                          : "Information"}
                    </AlertTitle>
                    <AlertDescription>
                      <div className="flex flex-col">
                        <span>{alert.message}</span>
                        <span className="text-xs opacity-70">{alert.timestamp}</span>
                      </div>
                    </AlertDescription>
                  </Alert>
                ))}
              </div>
            </CardContent>
          </Card>

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Analytics</CardTitle>
              <CardDescription>Performance metrics</CardDescription>
            </CardHeader>
            <CardContent>
              <Tabs defaultValue="mileage">
                <TabsList className="grid w-full grid-cols-2">
                  <TabsTrigger value="mileage">Mileage vs Cost</TabsTrigger>
                  <TabsTrigger value="efficiency">Driver Efficiency</TabsTrigger>
                </TabsList>
                <TabsContent value="mileage" className="mt-4">
                  <div className="h-[200px] bg-gray-100 rounded-md flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <p>Bar chart placeholder</p>
                      <p className="text-xs">Mileage vs Fuel Cost (Last 30 Days)</p>
                    </div>
                  </div>
                </TabsContent>
                <TabsContent value="efficiency" className="mt-4">
                  <div className="h-[200px] bg-gray-100 rounded-md flex items-center justify-center">
                    <div className="text-center text-gray-500">
                      <p>Heatmap placeholder</p>
                      <p className="text-xs">Driver Efficiency Across Regions</p>
                    </div>
                  </div>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>

          <div className="mt-6 grid grid-cols-2 gap-4">
            <Button className="bg-emerald-600 hover:bg-emerald-700">
              <Car className="mr-2 h-4 w-4" />
              Assign Vehicle
            </Button>
            <Button className="bg-blue-600 hover:bg-blue-700">
              <FileCheck className="mr-2 h-4 w-4" />
              Add Project
            </Button>
          </div>
        </div>
      </div>
    </div>
  )
}
