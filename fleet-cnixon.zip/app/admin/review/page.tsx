"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Check, X, FileText, CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"

// Mock data for expenses
const expensesData = [
  {
    id: "1",
    driver: "John Doe",
    vehicle: "KDG 442X",
    name: "Fuel at Total Eldoret",
    date: "2023-04-12",
    amount: 5000,
    category: "FUEL",
    paymentMethod: "MPESA",
    receipt: true,
    notes: "Full tank refill at Total Eldoret",
    status: "PENDING",
  },
  {
    id: "2",
    driver: "Jane Smith",
    vehicle: "KCG 123Y",
    name: "Tire repair at Kapsoya",
    date: "2023-04-14",
    amount: 1500,
    category: "MAINTENANCE",
    paymentMethod: "CASH",
    receipt: true,
    notes: "Puncture repair at Kapsoya garage",
    status: "PENDING",
  },
  {
    id: "3",
    driver: "John Doe",
    vehicle: "KDG 442X",
    name: "Car wash at Pioneer",
    date: "2023-04-16",
    amount: 500,
    category: "MISCELLANEOUS",
    paymentMethod: "CASH",
    receipt: false,
    notes: "Car wash at Pioneer",
    status: "PENDING",
  },
  {
    id: "4",
    driver: "Robert Johnson",
    vehicle: "KBZ 789Z",
    name: "Lunch at Poa Place",
    date: "2023-04-15",
    amount: 350,
    category: "MISCELLANEOUS",
    paymentMethod: "CASH",
    receipt: false,
    notes: "Lunch during long trip to Nauyapong",
    status: "PENDING",
  },
  {
    id: "5",
    driver: "Jane Smith",
    vehicle: "KCG 123Y",
    name: "Toll fees at Nakuru",
    date: "2023-04-17",
    amount: 200,
    category: "MISCELLANEOUS",
    paymentMethod: "MPESA",
    receipt: true,
    notes: "Highway toll fees",
    status: "APPROVED",
  },
  {
    id: "6",
    driver: "John Doe",
    vehicle: "KDG 442X",
    name: "Oil change at Shell Eldoret",
    date: "2023-04-10",
    amount: 3500,
    category: "MAINTENANCE",
    paymentMethod: "MPESA",
    receipt: true,
    notes: "Regular maintenance",
    status: "APPROVED",
  },
  {
    id: "7",
    driver: "Robert Johnson",
    vehicle: "KBZ 789Z",
    name: "Parking at MTRH",
    date: "2023-04-13",
    amount: 100,
    category: "MISCELLANEOUS",
    paymentMethod: "CASH",
    receipt: false,
    notes: "Hospital delivery parking",
    status: "REJECTED",
    rejectionReason: "Receipt required for all parking expenses",
  },
]

export default function ReviewExpensesPage() {
  const [expenses, setExpenses] = useState(expensesData)
  const [activeTab, setActiveTab] = useState("pending")
  const [searchQuery, setSearchQuery] = useState("")
  const [categoryFilter, setCategoryFilter] = useState("")
  const [startDate, setStartDate] = useState<Date>()
  const [endDate, setEndDate] = useState<Date>()
  const [selectedExpense, setSelectedExpense] = useState<any>(null)
  const [rejectionReason, setRejectionReason] = useState("")
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)
  const [isViewReceiptDialogOpen, setIsViewReceiptDialogOpen] = useState(false)

  // Filter expenses based on search query, category, date range, and status
  const filteredExpenses = expenses.filter((expense) => {
    // Filter by search query
    const matchesSearch =
      expense.driver.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.vehicle.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
      expense.category.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by category
    const matchesCategory = categoryFilter ? expense.category === categoryFilter : true

    // Filter by date range
    const expenseDate = new Date(expense.date)
    const matchesStartDate = startDate ? expenseDate >= startDate : true
    const matchesEndDate = endDate ? expenseDate <= endDate : true

    // Filter by status
    const matchesStatus = activeTab === "all" ? true : expense.status.toLowerCase() === activeTab.toLowerCase()

    return matchesSearch && matchesCategory && matchesStartDate && matchesEndDate && matchesStatus
  })

  // Approve expense
  const handleApprove = (id: string) => {
    setExpenses(expenses.map((expense) => (expense.id === id ? { ...expense, status: "APPROVED" } : expense)))
  }

  // Open reject dialog
  const handleOpenRejectDialog = (expense: any) => {
    setSelectedExpense(expense)
    setRejectionReason("")
    setIsRejectDialogOpen(true)
  }

  // Reject expense
  const handleReject = () => {
    if (selectedExpense && rejectionReason) {
      setExpenses(
        expenses.map((expense) =>
          expense.id === selectedExpense.id ? { ...expense, status: "REJECTED", rejectionReason } : expense,
        ),
      )
      setIsRejectDialogOpen(false)
    }
  }

  // View receipt
  const handleViewReceipt = (expense: any) => {
    setSelectedExpense(expense)
    setIsViewReceiptDialogOpen(true)
  }

  // Reset filters
  const resetFilters = () => {
    setSearchQuery("")
    setCategoryFilter("")
    setStartDate(undefined)
    setEndDate(undefined)
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Review Expenses</h1>

      <Card>
        <CardHeader>
          <CardTitle>Expense Review</CardTitle>
          <CardDescription>Review and approve/reject driver expenses</CardDescription>
        </CardHeader>
        <CardContent className="space-y-6">
          <div className="flex flex-col md:flex-row gap-4">
            <div className="grid grid-cols-1 md:grid-cols-4 gap-4 flex-1">
              <Input
                placeholder="Search expenses..."
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
                className="md:col-span-2"
              />

              <Select value={categoryFilter} onValueChange={setCategoryFilter}>
                <SelectTrigger>
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  <SelectItem value="FUEL">Fuel</SelectItem>
                  <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
                  <SelectItem value="PERMITS">Permits</SelectItem>
                  <SelectItem value="INSURANCE">Insurance</SelectItem>
                  <SelectItem value="MISCELLANEOUS">Miscellaneous</SelectItem>
                </SelectContent>
              </Select>

              <div className="flex gap-2">
                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn(
                        "w-full justify-start text-left font-normal",
                        !startDate && "text-muted-foreground",
                      )}
                    >
                      {startDate ? format(startDate, "MMM d") : <span>Start</span>}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                  </PopoverContent>
                </Popover>

                <Popover>
                  <PopoverTrigger asChild>
                    <Button
                      variant={"outline"}
                      className={cn("w-full justify-start text-left font-normal", !endDate && "text-muted-foreground")}
                    >
                      {endDate ? format(endDate, "MMM d") : <span>End</span>}
                      <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                    </Button>
                  </PopoverTrigger>
                  <PopoverContent className="w-auto p-0" align="start">
                    <Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus />
                  </PopoverContent>
                </Popover>
              </div>
            </div>

            <Button variant="outline" onClick={resetFilters}>
              Reset Filters
            </Button>
          </div>

          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="pending">Pending</TabsTrigger>
              <TabsTrigger value="approved">Approved</TabsTrigger>
              <TabsTrigger value="rejected">Rejected</TabsTrigger>
            </TabsList>

            <TabsContent value="pending" className="mt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Expense</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.length > 0 ? (
                    filteredExpenses.map((expense) => (
                      <TableRow key={expense.id}>
                        <TableCell>{expense.driver}</TableCell>
                        <TableCell>{expense.vehicle}</TableCell>
                        <TableCell>{expense.name}</TableCell>
                        <TableCell>{format(new Date(expense.date), "MMM d, yyyy")}</TableCell>
                        <TableCell>{expense.amount.toLocaleString()}</TableCell>
                        <TableCell>{expense.category}</TableCell>
                        <TableCell>
                          {expense.receipt ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-blue-600 hover:text-blue-800"
                              onClick={() => handleViewReceipt(expense)}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          ) : (
                            "No"
                          )}
                        </TableCell>
                        <TableCell>
                          <div className="flex gap-2">
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-green-50 text-green-600 hover:bg-green-100 hover:text-green-700 border-green-200"
                              onClick={() => handleApprove(expense.id)}
                            >
                              <Check className="h-4 w-4 mr-1" />
                              Approve
                            </Button>
                            <Button
                              size="sm"
                              variant="outline"
                              className="bg-red-50 text-red-600 hover:bg-red-100 hover:text-red-700 border-red-200"
                              onClick={() => handleOpenRejectDialog(expense)}
                            >
                              <X className="h-4 w-4 mr-1" />
                              Reject
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        No pending expenses found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="approved" className="mt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Expense</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Notes</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.length > 0 ? (
                    filteredExpenses.map((expense) => (
                      <TableRow key={expense.id}>
                        <TableCell>{expense.driver}</TableCell>
                        <TableCell>{expense.vehicle}</TableCell>
                        <TableCell>{expense.name}</TableCell>
                        <TableCell>{format(new Date(expense.date), "MMM d, yyyy")}</TableCell>
                        <TableCell>{expense.amount.toLocaleString()}</TableCell>
                        <TableCell>{expense.category}</TableCell>
                        <TableCell>
                          {expense.receipt ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-blue-600 hover:text-blue-800"
                              onClick={() => handleViewReceipt(expense)}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          ) : (
                            "No"
                          )}
                        </TableCell>
                        <TableCell>{expense.notes}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        No approved expenses found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>

            <TabsContent value="rejected" className="mt-4">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Driver</TableHead>
                    <TableHead>Vehicle</TableHead>
                    <TableHead>Expense</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Rejection Reason</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {filteredExpenses.length > 0 ? (
                    filteredExpenses.map((expense) => (
                      <TableRow key={expense.id}>
                        <TableCell>{expense.driver}</TableCell>
                        <TableCell>{expense.vehicle}</TableCell>
                        <TableCell>{expense.name}</TableCell>
                        <TableCell>{format(new Date(expense.date), "MMM d, yyyy")}</TableCell>
                        <TableCell>{expense.amount.toLocaleString()}</TableCell>
                        <TableCell>{expense.category}</TableCell>
                        <TableCell>
                          {expense.receipt ? (
                            <Button
                              variant="ghost"
                              size="sm"
                              className="text-blue-600 hover:text-blue-800"
                              onClick={() => handleViewReceipt(expense)}
                            >
                              <FileText className="h-4 w-4 mr-1" />
                              View
                            </Button>
                          ) : (
                            "No"
                          )}
                        </TableCell>
                        <TableCell className="text-red-600">{expense.rejectionReason}</TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="text-center py-8 text-muted-foreground">
                        No rejected expenses found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* Reject Dialog */}
      <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Reject Expense</DialogTitle>
            <DialogDescription>
              Please provide a reason for rejecting this expense. This will be visible to the driver.
            </DialogDescription>
          </DialogHeader>
          <div className="space-y-4 py-4">
            <div className="grid grid-cols-4 gap-2 text-sm">
              <div className="text-muted-foreground">Driver:</div>
              <div className="col-span-3 font-medium">{selectedExpense?.driver}</div>

              <div className="text-muted-foreground">Expense:</div>
              <div className="col-span-3 font-medium">{selectedExpense?.name}</div>

              <div className="text-muted-foreground">Amount:</div>
              <div className="col-span-3 font-medium">Ksh {selectedExpense?.amount?.toLocaleString()}</div>
            </div>

            <div className="space-y-2">
              <label htmlFor="reason" className="text-sm font-medium">
                Rejection Reason
              </label>
              <Textarea
                id="reason"
                placeholder="Enter reason for rejection"
                value={rejectionReason}
                onChange={(e) => setRejectionReason(e.target.value)}
              />
            </div>
          </div>
          <DialogFooter>
            <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
              Cancel
            </Button>
            <Button variant="destructive" onClick={handleReject} disabled={!rejectionReason}>
              Reject Expense
            </Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>

      {/* View Receipt Dialog */}
      <Dialog open={isViewReceiptDialogOpen} onOpenChange={setIsViewReceiptDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>Expense Receipt</DialogTitle>
            <DialogDescription>
              Receipt for {selectedExpense?.name} - Ksh {selectedExpense?.amount?.toLocaleString()}
            </DialogDescription>
          </DialogHeader>
          <div className="flex items-center justify-center p-4 bg-gray-100 rounded-md">
            <div className="text-center">
              <FileText className="h-16 w-16 mx-auto text-gray-400 mb-2" />
              <p className="text-muted-foreground">Receipt image placeholder</p>
              <p className="text-xs text-muted-foreground mt-1">
                In a real application, the actual receipt image would be displayed here
              </p>
            </div>
          </div>
          <DialogFooter>
            <Button onClick={() => setIsViewReceiptDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
