"use client"
import { useRouter } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft } from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"

// Vehicle form schema
const vehicleFormSchema = z.object({
  plateNumber: z.string().min(6, {
    message: "Plate number must be at least 6 characters.",
  }),
  model: z.string().min(2, {
    message: "Model must be at least 2 characters.",
  }),
  type: z.string().min(2, {
    message: "Type must be at least 2 characters.",
  }),
  status: z.enum(["ACTIVE", "INACTIVE", "MAINTENANCE"], {
    required_error: "Please select a status.",
  }),
  odometer: z.coerce.number().nonnegative({
    message: "Odometer must be a positive number.",
  }),
  fuelEfficiency: z.coerce.number().positive({
    message: "Fuel efficiency must be a positive number.",
  }),
})

export default function AddVehiclePage() {
  const router = useRouter()

  // Vehicle form
  const form = useForm<z.infer<typeof vehicleFormSchema>>({
    resolver: zodResolver(vehicleFormSchema),
    defaultValues: {
      plateNumber: "",
      model: "",
      type: "",
      status: "ACTIVE",
      odometer: 0,
      fuelEfficiency: 10,
    },
  })

  // Submit form
  const onSubmit = (data: z.infer<typeof vehicleFormSchema>) => {
    // In a real app, you would send this data to your API
    console.log("Vehicle data submitted:", data)
    router.push("/admin/vehicles")
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Link href="/admin/vehicles" className="mr-4">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Add New Vehicle</h1>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Vehicle Information</CardTitle>
          <CardDescription>Enter the details for the new vehicle</CardDescription>
        </CardHeader>
        <CardContent>
          <Form {...form}>
            <form onSubmit={form.handleSubmit(onSubmit)} className="space-y-6">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <FormField
                  control={form.control}
                  name="plateNumber"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Plate Number</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. KDG 442X" {...field} />
                      </FormControl>
                      <FormDescription>Enter the vehicle's license plate number</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="model"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Model</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Toyota Hilux" {...field} />
                      </FormControl>
                      <FormDescription>Enter the vehicle's make and model</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="type"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Type</FormLabel>
                      <FormControl>
                        <Input placeholder="e.g. Pickup Truck" {...field} />
                      </FormControl>
                      <FormDescription>Enter the vehicle type</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="status"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Status</FormLabel>
                      <Select onValueChange={field.onChange} defaultValue={field.value}>
                        <FormControl>
                          <SelectTrigger>
                            <SelectValue placeholder="Select status" />
                          </SelectTrigger>
                        </FormControl>
                        <SelectContent>
                          <SelectItem value="ACTIVE">Active</SelectItem>
                          <SelectItem value="INACTIVE">Inactive</SelectItem>
                          <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
                        </SelectContent>
                      </Select>
                      <FormDescription>Select the initial status of the vehicle</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="odometer"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Odometer (km)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="e.g. 10000" {...field} />
                      </FormControl>
                      <FormDescription>Enter the current odometer reading in kilometers</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />

                <FormField
                  control={form.control}
                  name="fuelEfficiency"
                  render={({ field }) => (
                    <FormItem>
                      <FormLabel>Fuel Efficiency (L/100km)</FormLabel>
                      <FormControl>
                        <Input type="number" placeholder="e.g. 10" {...field} />
                      </FormControl>
                      <FormDescription>Enter the average fuel consumption in liters per 100km</FormDescription>
                      <FormMessage />
                    </FormItem>
                  )}
                />
              </div>

              <div className="flex justify-end">
                <Button type="submit">Add Vehicle</Button>
              </div>
            </form>
          </Form>
        </CardContent>
      </Card>
    </div>
  )
}
