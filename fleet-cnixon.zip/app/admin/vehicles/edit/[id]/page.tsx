"use client"

import type React from "react"

import { useState, useEffect } from "react"
import { useRouter, useParams } from "next/navigation"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { ArrowLeft, Trash2, CalendarIcon } from "lucide-react"
import Link from "next/link"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Textarea } from "@/components/ui/textarea"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Calendar } from "@/components/ui/calendar"
import { cn } from "@/lib/utils"

// Mock data for vehicles
const vehiclesData = [
  {
    id: "1",
    plateNumber: "KDG 442X",
    model: "Land Cruiser (LC-79)",
    type: "Pickup Truck",
    status: "ACTIVE",
    odometer: 181771.6,
    fuelEfficiency: 10,
    assignedDriver: "John Doe",
    lastMaintenance: "2023-03-15",
    nextMaintenance: "2023-05-15",
    alerts: [
      {
        id: "1",
        type: "maintenance",
        message: "Oil change due in 500km",
        priority: "medium",
      },
    ],
    maintenanceHistory: [
      {
        id: "1",
        date: "2023-03-15",
        description: "Regular service at Eldoret Motors",
        cost: 15000,
        odometer: 180000,
      },
      {
        id: "2",
        date: "2023-01-10",
        description: "Brake pad replacement at Kapsoya Garage",
        cost: 8000,
        odometer: 175000,
      },
    ],
  },
  {
    id: "2",
    plateNumber: "KCG 123Y",
    model: "Toyota Hilux",
    type: "Pickup Truck",
    status: "ACTIVE",
    odometer: 95420.3,
    fuelEfficiency: 12,
    assignedDriver: "Jane Smith",
    lastMaintenance: "2023-04-01",
    nextMaintenance: "2023-06-01",
    alerts: [],
    maintenanceHistory: [
      {
        id: "3",
        date: "2023-04-01",
        description: "Regular service at Eldoret Toyota",
        cost: 12000,
        odometer: 95000,
      },
    ],
  },
  {
    id: "3",
    plateNumber: "KBZ 789Z",
    model: "Isuzu D-Max",
    type: "Pickup Truck",
    status: "MAINTENANCE",
    odometer: 210568.7,
    fuelEfficiency: 11,
    assignedDriver: "Robert Johnson",
    lastMaintenance: "2023-04-10",
    nextMaintenance: "2023-04-20",
    alerts: [
      {
        id: "2",
        type: "maintenance",
        message: "Engine check required",
        priority: "high",
      },
      {
        id: "3",
        type: "maintenance",
        message: "Brake pads need replacement",
        priority: "high",
      },
    ],
    maintenanceHistory: [
      {
        id: "4",
        date: "2023-04-10",
        description: "Engine diagnostics at Langas Garage",
        cost: 5000,
        odometer: 210000,
      },
    ],
  },
]

// Mock data for drivers
const driversData = [
  { id: "1", name: "John Doe" },
  { id: "2", name: "Jane Smith" },
  { id: "3", name: "Robert Johnson" },
  { id: "4", name: "Unassigned", value: "" },
]

export default function EditVehiclePage() {
  const router = useRouter()
  const params = useParams()
  const vehicleId = params.id as string
  const [isLoading, setIsLoading] = useState(true)
  const [activeTab, setActiveTab] = useState("details")
  const [vehicle, setVehicle] = useState<any>(null)
  const [formData, setFormData] = useState({
    plateNumber: "",
    model: "",
    type: "",
    status: "",
    odometer: 0,
    fuelEfficiency: 0,
    assignedDriver: "",
  })
  const [newAlert, setNewAlert] = useState({
    message: "",
    priority: "medium",
  })
  const [newMaintenance, setNewMaintenance] = useState({
    date: new Date(),
    description: "",
    cost: 0,
    odometer: 0,
  })

  // Load vehicle data
  useEffect(() => {
    // In a real app, you would fetch this data from your API
    const vehicleData = vehiclesData.find((v) => v.id === vehicleId)

    if (vehicleData) {
      setVehicle(vehicleData)
      setFormData({
        plateNumber: vehicleData.plateNumber,
        model: vehicleData.model,
        type: vehicleData.type,
        status: vehicleData.status,
        odometer: vehicleData.odometer,
        fuelEfficiency: vehicleData.fuelEfficiency,
        assignedDriver: vehicleData.assignedDriver || "",
      })
      setNewMaintenance({
        ...newMaintenance,
        odometer: vehicleData.odometer,
      })
    }

    setIsLoading(false)
  }, [vehicleId])

  // Handle form input change
  const handleInputChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const { name, value } = e.target
    setFormData({
      ...formData,
      [name]: name === "odometer" || name === "fuelEfficiency" ? Number.parseFloat(value) : value,
    })
  }

  // Handle select change
  const handleSelectChange = (name: string, value: string) => {
    setFormData({
      ...formData,
      [name]: value,
    })
  }

  // Handle alert input change
  const handleAlertInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewAlert({
      ...newAlert,
      [name]: value,
    })
  }

  // Handle maintenance input change
  const handleMaintenanceInputChange = (e: React.ChangeEvent<HTMLInputElement | HTMLTextAreaElement>) => {
    const { name, value } = e.target
    setNewMaintenance({
      ...newMaintenance,
      [name]: name === "cost" || name === "odometer" ? Number.parseFloat(value) : value,
    })
  }

  // Add new alert
  const handleAddAlert = () => {
    if (newAlert.message) {
      const updatedVehicle = {
        ...vehicle,
        alerts: [
          ...vehicle.alerts,
          {
            id: (vehicle.alerts.length + 1).toString(),
            type: "maintenance",
            message: newAlert.message,
            priority: newAlert.priority,
          },
        ],
      }
      setVehicle(updatedVehicle)
      setNewAlert({
        message: "",
        priority: "medium",
      })
    }
  }

  // Add new maintenance record
  const handleAddMaintenance = () => {
    if (newMaintenance.description && newMaintenance.cost > 0) {
      const updatedVehicle = {
        ...vehicle,
        maintenanceHistory: [
          {
            id: (vehicle.maintenanceHistory.length + 1).toString(),
            date: format(newMaintenance.date, "yyyy-MM-dd"),
            description: newMaintenance.description,
            cost: newMaintenance.cost,
            odometer: newMaintenance.odometer,
          },
          ...vehicle.maintenanceHistory,
        ],
        lastMaintenance: format(newMaintenance.date, "yyyy-MM-dd"),
      }
      setVehicle(updatedVehicle)
      setNewMaintenance({
        date: new Date(),
        description: "",
        cost: 0,
        odometer: vehicle.odometer,
      })
    }
  }

  // Delete alert
  const handleDeleteAlert = (alertId: string) => {
    const updatedVehicle = {
      ...vehicle,
      alerts: vehicle.alerts.filter((alert: any) => alert.id !== alertId),
    }
    setVehicle(updatedVehicle)
  }

  // Save vehicle changes
  const handleSaveVehicle = () => {
    // In a real app, you would send this data to your API
    console.log("Vehicle data saved:", formData)
    router.push("/admin/vehicles")
  }

  // Get alert priority badge color
  const getAlertPriorityBadgeColor = (priority: string) => {
    switch (priority) {
      case "critical":
        return "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300"
      case "high":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
      case "medium":
        return "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300"
      case "low":
        return "bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  if (isLoading || !vehicle) {
    return (
      <div className="flex items-center justify-center h-full">
        <p>Loading vehicle data...</p>
      </div>
    )
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center">
        <Link href="/admin/vehicles" className="mr-4">
          <Button variant="ghost" size="icon">
            <ArrowLeft className="h-4 w-4" />
            <span className="sr-only">Back</span>
          </Button>
        </Link>
        <h1 className="text-2xl font-bold">Edit Vehicle</h1>
      </div>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="details">Vehicle Details</TabsTrigger>
          <TabsTrigger value="alerts">Alerts</TabsTrigger>
          <TabsTrigger value="maintenance">Maintenance History</TabsTrigger>
        </TabsList>

        <TabsContent value="details" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Vehicle Information</CardTitle>
              <CardDescription>Edit the vehicle's details</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <label htmlFor="plateNumber" className="text-sm font-medium">
                    Plate Number
                  </label>
                  <Input
                    id="plateNumber"
                    name="plateNumber"
                    value={formData.plateNumber}
                    onChange={handleInputChange}
                    placeholder="e.g. KDG 442X"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="model" className="text-sm font-medium">
                    Model
                  </label>
                  <Input
                    id="model"
                    name="model"
                    value={formData.model}
                    onChange={handleInputChange}
                    placeholder="e.g. Toyota Hilux"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="type" className="text-sm font-medium">
                    Type
                  </label>
                  <Input
                    id="type"
                    name="type"
                    value={formData.type}
                    onChange={handleInputChange}
                    placeholder="e.g. Pickup Truck"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="status" className="text-sm font-medium">
                    Status
                  </label>
                  <Select value={formData.status} onValueChange={(value) => handleSelectChange("status", value)}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select status" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="ACTIVE">Active</SelectItem>
                      <SelectItem value="INACTIVE">Inactive</SelectItem>
                      <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <div className="space-y-2">
                  <label htmlFor="odometer" className="text-sm font-medium">
                    Odometer (km)
                  </label>
                  <Input
                    id="odometer"
                    name="odometer"
                    type="number"
                    value={formData.odometer}
                    onChange={handleInputChange}
                    placeholder="e.g. 10000"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="fuelEfficiency" className="text-sm font-medium">
                    Fuel Efficiency (L/100km)
                  </label>
                  <Input
                    id="fuelEfficiency"
                    name="fuelEfficiency"
                    type="number"
                    value={formData.fuelEfficiency}
                    onChange={handleInputChange}
                    placeholder="e.g. 10"
                  />
                </div>

                <div className="space-y-2">
                  <label htmlFor="assignedDriver" className="text-sm font-medium">
                    Assigned Driver
                  </label>
                  <Select
                    value={formData.assignedDriver}
                    onValueChange={(value) => handleSelectChange("assignedDriver", value)}
                  >
                    <SelectTrigger>
                      <SelectValue placeholder="Select driver" />
                    </SelectTrigger>
                    <SelectContent>
                      {driversData.map((driver) => (
                        <SelectItem key={driver.id} value={driver.value || driver.name}>
                          {driver.name}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
              </div>

              <div className="flex justify-end mt-6">
                <Button onClick={handleSaveVehicle}>Save Changes</Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="alerts" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Vehicle Alerts</CardTitle>
              <CardDescription>Manage alerts for this vehicle</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Current Alerts</h3>
                  {vehicle.alerts.length > 0 ? (
                    <div className="space-y-4">
                      {vehicle.alerts.map((alert: any) => (
                        <div
                          key={alert.id}
                          className={`p-4 rounded-md flex justify-between items-start ${
                            alert.priority === "critical"
                              ? "bg-red-50 dark:bg-red-900/20"
                              : alert.priority === "high"
                                ? "bg-orange-50 dark:bg-orange-900/20"
                                : "bg-yellow-50 dark:bg-yellow-900/20"
                          }`}
                        >
                          <div>
                            <p className="font-medium">{alert.message}</p>
                            <p className="text-sm text-muted-foreground">
                              Priority:{" "}
                              <Badge className={getAlertPriorityBadgeColor(alert.priority)}>
                                {alert.priority.charAt(0).toUpperCase() + alert.priority.slice(1)}
                              </Badge>
                            </p>
                          </div>
                          <Button
                            variant="ghost"
                            size="icon"
                            className="text-red-500"
                            onClick={() => handleDeleteAlert(alert.id)}
                          >
                            <Trash2 className="h-4 w-4" />
                            <span className="sr-only">Delete</span>
                          </Button>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No alerts for this vehicle.</p>
                  )}
                </div>

                <div className="border-t pt-6">
                  <h3 className="text-lg font-medium mb-4">Add New Alert</h3>
                  <div className="space-y-4">
                    <div className="space-y-2">
                      <label htmlFor="message" className="text-sm font-medium">
                        Alert Message
                      </label>
                      <Textarea
                        id="message"
                        name="message"
                        value={newAlert.message}
                        onChange={handleAlertInputChange}
                        placeholder="Enter alert message"
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="priority" className="text-sm font-medium">
                        Priority
                      </label>
                      <Select
                        value={newAlert.priority}
                        onValueChange={(value) => setNewAlert({ ...newAlert, priority: value })}
                      >
                        <SelectTrigger>
                          <SelectValue placeholder="Select priority" />
                        </SelectTrigger>
                        <SelectContent>
                          <SelectItem value="critical">Critical</SelectItem>
                          <SelectItem value="high">High</SelectItem>
                          <SelectItem value="medium">Medium</SelectItem>
                          <SelectItem value="low">Low</SelectItem>
                        </SelectContent>
                      </Select>
                    </div>

                    <Button onClick={handleAddAlert}>Add Alert</Button>
                  </div>
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="maintenance" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Maintenance History</CardTitle>
              <CardDescription>View and add maintenance records</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="space-y-6">
                <div className="space-y-4">
                  <h3 className="text-lg font-medium">Add New Maintenance Record</h3>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <label htmlFor="date" className="text-sm font-medium">
                        Date
                      </label>
                      <Popover>
                        <PopoverTrigger asChild>
                          <Button
                            variant={"outline"}
                            className={cn(
                              "w-full justify-start text-left font-normal",
                              !newMaintenance.date && "text-muted-foreground",
                            )}
                          >
                            {newMaintenance.date ? format(newMaintenance.date, "PPP") : <span>Pick a date</span>}
                            <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                          </Button>
                        </PopoverTrigger>
                        <PopoverContent className="w-auto p-0" align="start">
                          <Calendar
                            mode="single"
                            selected={newMaintenance.date}
                            onSelect={(date) => setNewMaintenance({ ...newMaintenance, date: date || new Date() })}
                            initialFocus
                          />
                        </PopoverContent>
                      </Popover>
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="odometer" className="text-sm font-medium">
                        Odometer (km)
                      </label>
                      <Input
                        id="odometer"
                        name="odometer"
                        type="number"
                        value={newMaintenance.odometer}
                        onChange={handleMaintenanceInputChange}
                        placeholder="e.g. 10000"
                      />
                    </div>

                    <div className="space-y-2 md:col-span-2">
                      <label htmlFor="description" className="text-sm font-medium">
                        Description
                      </label>
                      <Textarea
                        id="description"
                        name="description"
                        value={newMaintenance.description}
                        onChange={handleMaintenanceInputChange}
                        placeholder="Enter maintenance description"
                      />
                    </div>

                    <div className="space-y-2">
                      <label htmlFor="cost" className="text-sm font-medium">
                        Cost (Kshs)
                      </label>
                      <Input
                        id="cost"
                        name="cost"
                        type="number"
                        value={newMaintenance.cost}
                        onChange={handleMaintenanceInputChange}
                        placeholder="e.g. 5000"
                      />
                    </div>
                  </div>

                  <Button onClick={handleAddMaintenance}>Add Maintenance Record</Button>
                </div>

                <div className="border-t pt-6">
                  <h3 className="text-lg font-medium mb-4">Maintenance History</h3>
                  {vehicle.maintenanceHistory.length > 0 ? (
                    <div className="space-y-4">
                      {vehicle.maintenanceHistory.map((record: any) => (
                        <div key={record.id} className="p-4 rounded-md bg-muted">
                          <div className="flex justify-between">
                            <p className="font-medium">{record.description}</p>
                            <p className="text-sm">
                              <span className="text-muted-foreground">Date:</span> {record.date}
                            </p>
                          </div>
                          <div className="flex justify-between mt-2">
                            <p className="text-sm">
                              <span className="text-muted-foreground">Odometer:</span>{" "}
                              {record.odometer.toLocaleString()} km
                            </p>
                            <p className="text-sm">
                              <span className="text-muted-foreground">Cost:</span> Ksh {record.cost.toLocaleString()}
                            </p>
                          </div>
                        </div>
                      ))}
                    </div>
                  ) : (
                    <p className="text-muted-foreground">No maintenance records for this vehicle.</p>
                  )}
                </div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
