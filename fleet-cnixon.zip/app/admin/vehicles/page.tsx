"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Pencil, Trash2, Plus, Car } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import Link from "next/link"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"

// Mock data for vehicles
const vehiclesData = [
  {
    id: "1",
    plateNumber: "KDG 442X",
    model: "Land Cruiser (LC-79)",
    type: "Pickup Truck",
    status: "ACTIVE",
    driver: "John Doe",
    odometer: 181771.6,
    fuelEfficiency: 10,
    lastMaintenance: "2023-03-15",
  },
  {
    id: "2",
    plateNumber: "KCG 123Y",
    model: "Toyota Hilux",
    type: "Pickup Truck",
    status: "ACTIVE",
    driver: "Jane Smith",
    odometer: 95420.3,
    fuelEfficiency: 12,
    lastMaintenance: "2023-04-01",
  },
  {
    id: "3",
    plateNumber: "KBZ 789Z",
    model: "Isuzu D-Max",
    type: "Pickup Truck",
    status: "MAINTENANCE",
    driver: "Robert Johnson",
    odometer: 210568.7,
    fuelEfficiency: 11,
    lastMaintenance: "2023-04-10",
  },
  {
    id: "4",
    plateNumber: "KDJ 567A",
    model: "Toyota Land Cruiser Prado",
    type: "SUV",
    status: "ACTIVE",
    driver: "Samuel Wanjiru",
    odometer: 45230.5,
    fuelEfficiency: 13,
    lastMaintenance: "2023-03-22",
  },
  {
    id: "5",
    plateNumber: "KCE 321B",
    model: "Mitsubishi L200",
    type: "Pickup Truck",
    status: "INACTIVE",
    driver: null,
    odometer: 156789.2,
    fuelEfficiency: 11.5,
    lastMaintenance: "2023-02-18",
  },
]

export default function VehiclesPage() {
  const [vehicles, setVehicles] = useState(vehiclesData)
  const [searchQuery, setSearchQuery] = useState("")
  const [statusFilter, setStatusFilter] = useState("")

  // Filter vehicles based on search query and status
  const filteredVehicles = vehicles.filter((vehicle) => {
    // Filter by search query
    const matchesSearch =
      vehicle.plateNumber.toLowerCase().includes(searchQuery.toLowerCase()) ||
      vehicle.model.toLowerCase().includes(searchQuery.toLowerCase()) ||
      (vehicle.driver && vehicle.driver.toLowerCase().includes(searchQuery.toLowerCase()))

    // Filter by status
    const matchesStatus = statusFilter ? vehicle.status === statusFilter : true

    return matchesSearch && matchesStatus
  })

  // Handle delete vehicle
  const handleDelete = (id: string) => {
    setVehicles(vehicles.filter((vehicle) => vehicle.id !== id))
  }

  // Get status badge color
  const getStatusBadgeColor = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300"
      case "INACTIVE":
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
      case "MAINTENANCE":
        return "bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300"
      default:
        return "bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300"
    }
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-2xl font-bold">Vehicles</h1>
        <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
          <div className="flex gap-4 w-full md:w-auto">
            <Input
              placeholder="Search vehicles..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="md:w-64"
            />
            <Select value={statusFilter} onValueChange={setStatusFilter}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="All statuses" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="ALL">All statuses</SelectItem>
                <SelectItem value="ACTIVE">Active</SelectItem>
                <SelectItem value="INACTIVE">Inactive</SelectItem>
                <SelectItem value="MAINTENANCE">Maintenance</SelectItem>
              </SelectContent>
            </Select>
          </div>
          <Link href="/admin/vehicles/add">
            <Button>
              <Plus className="mr-2 h-4 w-4" />
              Add Vehicle
            </Button>
          </Link>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Vehicle List</CardTitle>
          <CardDescription>Manage your fleet vehicles</CardDescription>
        </CardHeader>
        <CardContent>
          <Table>
            <TableHeader>
              <TableRow>
                <TableHead>Plate Number</TableHead>
                <TableHead>Model</TableHead>
                <TableHead>Type</TableHead>
                <TableHead>Driver</TableHead>
                <TableHead>Odometer (km)</TableHead>
                <TableHead>Fuel Efficiency (L/100km)</TableHead>
                <TableHead>Status</TableHead>
                <TableHead>Last Maintenance</TableHead>
                <TableHead className="text-right">Actions</TableHead>
              </TableRow>
            </TableHeader>
            <TableBody>
              {filteredVehicles.length > 0 ? (
                filteredVehicles.map((vehicle) => (
                  <TableRow key={vehicle.id}>
                    <TableCell className="font-medium">{vehicle.plateNumber}</TableCell>
                    <TableCell>{vehicle.model}</TableCell>
                    <TableCell>{vehicle.type}</TableCell>
                    <TableCell>{vehicle.driver || "Unassigned"}</TableCell>
                    <TableCell>{vehicle.odometer.toLocaleString()}</TableCell>
                    <TableCell>{vehicle.fuelEfficiency}</TableCell>
                    <TableCell>
                      <Badge className={getStatusBadgeColor(vehicle.status)}>{vehicle.status}</Badge>
                    </TableCell>
                    <TableCell>{vehicle.lastMaintenance}</TableCell>
                    <TableCell className="text-right">
                      <div className="flex justify-end gap-2">
                        <Link href={`/admin/vehicles/edit/${vehicle.id}`}>
                          <Button variant="ghost" size="icon">
                            <Pencil className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                        </Link>

                        <AlertDialog>
                          <AlertDialogTrigger asChild>
                            <Button variant="ghost" size="icon" className="text-red-500">
                              <Trash2 className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </AlertDialogTrigger>
                          <AlertDialogContent>
                            <AlertDialogHeader>
                              <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                              <AlertDialogDescription>
                                This will permanently delete the vehicle "{vehicle.plateNumber} - {vehicle.model}". This
                                action cannot be undone.
                              </AlertDialogDescription>
                            </AlertDialogHeader>
                            <AlertDialogFooter>
                              <AlertDialogCancel>Cancel</AlertDialogCancel>
                              <AlertDialogAction
                                onClick={() => handleDelete(vehicle.id)}
                                className="bg-red-500 hover:bg-red-600"
                              >
                                Delete
                              </AlertDialogAction>
                            </AlertDialogFooter>
                          </AlertDialogContent>
                        </AlertDialog>
                      </div>
                    </TableCell>
                  </TableRow>
                ))
              ) : (
                <TableRow>
                  <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                    No vehicles found matching your search.
                  </TableCell>
                </TableRow>
              )}
            </TableBody>
          </Table>
        </CardContent>
      </Card>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Total Vehicles</CardTitle>
            <CardDescription className="text-3xl font-bold">{vehicles.length}</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Car className="h-4 w-4 mr-2 text-muted-foreground" />
              <span className="text-sm text-muted-foreground">Fleet size</span>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Active Vehicles</CardTitle>
            <CardDescription className="text-3xl font-bold">
              {vehicles.filter((v) => v.status === "ACTIVE").length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">
                {Math.round((vehicles.filter((v) => v.status === "ACTIVE").length / vehicles.length) * 100)}% Active
              </Badge>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-sm font-medium text-muted-foreground">Under Maintenance</CardTitle>
            <CardDescription className="text-3xl font-bold">
              {vehicles.filter((v) => v.status === "MAINTENANCE").length}
            </CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center">
              <Badge className="bg-orange-100 text-orange-800 dark:bg-orange-900 dark:text-orange-300">
                {Math.round((vehicles.filter((v) => v.status === "MAINTENANCE").length / vehicles.length) * 100)}% In
                Maintenance
              </Badge>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
