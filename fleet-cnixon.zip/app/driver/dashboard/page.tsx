"use client"

import { useState } from "react"
import { StatusCard } from "@/components/status-card"
import { MonthlyTargetCard } from "@/components/monthly-target-card"
import { NotificationsCard } from "@/components/notifications-card"

// Mock data - in a real app, this would come from your API
const vehicleData = {
  assignedFrom: "2023-01-01",
  assignedTo: "2023-12-31",
  model: "Land Cruiser (LC-79)",
  plate: "KDG 442X",
  type: "Pickup Truck",
  status: "ACTIVE" as const,
  odometer: 181771.6,
  fuelEfficiency: 10,
}

const targetData = {
  month: "April",
  targetPercentage: 15,
  amountRealized: 35000,
  targetAmount: 200000,
  tripsCompleted: 4,
  lastUpdated: "15 min ago",
  currentDestination: "Kaberewo",
}

const alertsData = [
  {
    id: "1",
    type: "maintenance" as const,
    severity: "critical" as const,
    message: "Oil Change Due in 500km",
  },
]

const notificationsData = [
  {
    id: "1",
    message: "Fuel expense approved",
    timestamp: "2 hours ago",
  },
  {
    id: "2",
    message: "New message from dispatcher",
    timestamp: "Yesterday",
  },
  {
    id: "3",
    message: "Route change notification",
    timestamp: "2 days ago",
  },
]

export default function DriverDashboard() {
  const [vehicle, setVehicle] = useState(vehicleData)
  const [target, setTarget] = useState(targetData)
  const [alerts, setAlerts] = useState(alertsData)
  const [notifications, setNotifications] = useState(notificationsData)

  const handleOdometerUpdate = (newValue: number) => {
    setVehicle({
      ...vehicle,
      odometer: newValue,
    })
    // In a real app, you would send this update to your API
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Dashboard</h1>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <StatusCard {...vehicle} onOdometerUpdate={handleOdometerUpdate} />

        <MonthlyTargetCard {...target} />

        <NotificationsCard alerts={alerts} notifications={notifications} />
      </div>
    </div>
  )
}
