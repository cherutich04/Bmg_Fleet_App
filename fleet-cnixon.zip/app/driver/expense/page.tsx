"use client"

import { useState } from "react"
import { zodResolver } from "@hookform/resolvers/zod"
import { useForm } from "react-hook-form"
import { z } from "zod"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Form, FormControl, FormDescription, FormField, FormItem, FormLabel, FormMessage } from "@/components/ui/form"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, Upload } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Income form schema
const incomeFormSchema = z.object({
  hireType: z.enum(["PRIVATE", "PUBLIC"]),
  project: z.string().optional(),
  name: z.string().min(2, { message: "Delivery name must be at least 2 characters." }),
  date: z.date(),
  amount: z.coerce.number().positive({ message: "Amount must be positive." }),
  paymentMethod: z.enum(["CASH", "MPESA", "BANK", "CREDIT", "CHEQUE"]),
  paidBy: z.string().min(2, { message: "Paid by must be at least 2 characters." }),
  paidTo: z.string().min(2, { message: "Paid to must be at least 2 characters." }),
  receipt: z.any().optional(),
  notes: z.string().optional(),
})

// Expense form schema
const expenseFormSchema = z.object({
  name: z.string().min(2, { message: "Expense name must be at least 2 characters." }),
  date: z.date(),
  amount: z.coerce.number().positive({ message: "Amount must be positive." }),
  category: z.enum(["FUEL", "LABOR", "MAINTENANCE", "PERMITS", "INSURANCE", "MISCELLANEOUS"]),
  paymentMethod: z.enum(["CASH", "MPESA", "BANK", "CREDIT", "CHEQUE"]),
  paidBy: z.string().min(2, { message: "Paid by must be at least 2 characters." }),
  receipt: z.any().optional(),
  notes: z.string().optional(),
})

// Mock data for the tables
const mockIncomes = [
  {
    id: "1",
    name: "Delivery to Kaberewo",
    amount: 25000,
    date: "2023-04-10",
    paidBy: "John Doe",
    paymentMethod: "MPESA",
    hasReceipt: true,
    notes: "Regular delivery",
  },
  {
    id: "2",
    name: "Transport services",
    amount: 10000,
    date: "2023-04-15",
    paidBy: "Jane Smith",
    paymentMethod: "CASH",
    hasReceipt: false,
    notes: "",
  },
]

const mockExpenses = [
  {
    id: "1",
    name: "Fuel",
    amount: 5000,
    date: "2023-04-12",
    category: "FUEL",
    paymentMethod: "MPESA",
    paidBy: "Driver",
    hasReceipt: true,
    notes: "Full tank",
  },
  {
    id: "2",
    name: "Tire repair",
    amount: 1500,
    date: "2023-04-14",
    category: "MAINTENANCE",
    paymentMethod: "CASH",
    paidBy: "Driver",
    hasReceipt: true,
    notes: "Puncture repair",
  },
]

export default function ExpensePage() {
  const [activeTab, setActiveTab] = useState("income")
  const [showProjectField, setShowProjectField] = useState(false)
  const [incomes, setIncomes] = useState(mockIncomes)
  const [expenses, setExpenses] = useState(mockExpenses)

  // Income form
  const incomeForm = useForm<z.infer<typeof incomeFormSchema>>({
    resolver: zodResolver(incomeFormSchema),
    defaultValues: {
      hireType: "PRIVATE",
      name: "",
      date: new Date(),
      amount: undefined,
      paymentMethod: "CASH",
      paidBy: "",
      paidTo: "",
      notes: "",
    },
  })

  // Expense form
  const expenseForm = useForm<z.infer<typeof expenseFormSchema>>({
    resolver: zodResolver(expenseFormSchema),
    defaultValues: {
      name: "",
      date: new Date(),
      amount: undefined,
      category: "FUEL",
      paymentMethod: "CASH",
      paidBy: "",
      notes: "",
    },
  })

  // Handle hire type change to show/hide project field
  const handleHireTypeChange = (value: string) => {
    setShowProjectField(value === "PRIVATE")
  }

  // Submit income form
  const onIncomeSubmit = (data: z.infer<typeof incomeFormSchema>) => {
    console.log("Income form submitted:", data)

    // In a real app, you would send this data to your API
    // For now, we'll just add it to our mock data
    const newIncome = {
      id: (incomes.length + 1).toString(),
      name: data.name,
      amount: data.amount,
      date: format(data.date, "yyyy-MM-dd"),
      paidBy: data.paidBy,
      paymentMethod: data.paymentMethod,
      hasReceipt: !!data.receipt,
      notes: data.notes || "",
    }

    setIncomes([newIncome, ...incomes])
    incomeForm.reset()
  }

  // Submit expense form
  const onExpenseSubmit = (data: z.infer<typeof expenseFormSchema>) => {
    console.log("Expense form submitted:", data)

    // In a real app, you would send this data to your API
    // For now, we'll just add it to our mock data
    const newExpense = {
      id: (expenses.length + 1).toString(),
      name: data.name,
      amount: data.amount,
      date: format(data.date, "yyyy-MM-dd"),
      category: data.category,
      paymentMethod: data.paymentMethod,
      paidBy: data.paidBy,
      hasReceipt: !!data.receipt,
      notes: data.notes || "",
    }

    setExpenses([newExpense, ...expenses])
    expenseForm.reset()
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Expense Log</h1>

      <Tabs value={activeTab} onValueChange={setActiveTab}>
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="income">Money In (Income)</TabsTrigger>
          <TabsTrigger value="expense">Money Out (Expense)</TabsTrigger>
        </TabsList>

        <TabsContent value="income" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Log Income</CardTitle>
              <CardDescription>Record money received from deliveries or services</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...incomeForm}>
                <form onSubmit={incomeForm.handleSubmit(onIncomeSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={incomeForm.control}
                      name="hireType"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Hire Type</FormLabel>
                          <Select
                            onValueChange={(value) => {
                              field.onChange(value)
                              handleHireTypeChange(value)
                            }}
                            defaultValue={field.value}
                          >
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select hire type" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="PRIVATE">Private</SelectItem>
                              <SelectItem value="PUBLIC">Public (Hire)</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    {showProjectField && (
                      <FormField
                        control={incomeForm.control}
                        name="project"
                        render={({ field }) => (
                          <FormItem>
                            <FormLabel>Project</FormLabel>
                            <Select onValueChange={field.onChange} defaultValue={field.value}>
                              <FormControl>
                                <SelectTrigger>
                                  <SelectValue placeholder="Select project" />
                                </SelectTrigger>
                              </FormControl>
                              <SelectContent>
                                <SelectItem value="kaberewo">Kaberewo</SelectItem>
                                <SelectItem value="mtrh">MTRH</SelectItem>
                                <SelectItem value="nauyapong">Nauyapong</SelectItem>
                                <SelectItem value="kaptarkok">Kaptarkok</SelectItem>
                                <SelectItem value="other">Others</SelectItem>
                              </SelectContent>
                            </Select>
                            <FormMessage />
                          </FormItem>
                        )}
                      />
                    )}

                    <FormField
                      control={incomeForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Delivery Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter delivery name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={incomeForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={incomeForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount (Kshs)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="Enter amount" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={incomeForm.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select payment method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="CASH">Cash</SelectItem>
                              <SelectItem value="MPESA">M-Pesa</SelectItem>
                              <SelectItem value="BANK">Bank Transfer</SelectItem>
                              <SelectItem value="CREDIT">Credit</SelectItem>
                              <SelectItem value="CHEQUE">Cheque</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={incomeForm.control}
                      name="paidBy"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Paid By</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter payer name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={incomeForm.control}
                      name="paidTo"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Paid To</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter recipient name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={incomeForm.control}
                      name="receipt"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Receipt Upload (Optional)</FormLabel>
                          <FormControl>
                            <div className="flex items-center gap-2">
                              <Input
                                type="file"
                                accept="image/*,.pdf"
                                onChange={(e) => field.onChange(e.target.files?.[0])}
                                className="flex-1"
                              />
                              <Button type="button" size="icon" variant="outline">
                                <Upload className="h-4 w-4" />
                              </Button>
                            </div>
                          </FormControl>
                          <FormDescription>Upload a receipt image or PDF (max 5MB)</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={incomeForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes (Optional)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Add any additional notes here" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit">Submit Income</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Income Summary</CardTitle>
              <CardDescription>Recent income entries</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Delivery Name</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Paid By</TableHead>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {incomes.map((income) => (
                    <TableRow key={income.id}>
                      <TableCell>{income.name}</TableCell>
                      <TableCell>{income.amount.toLocaleString()}</TableCell>
                      <TableCell>{income.date}</TableCell>
                      <TableCell>{income.paidBy}</TableCell>
                      <TableCell>{income.paymentMethod}</TableCell>
                      <TableCell>{income.hasReceipt ? "Yes" : "No"}</TableCell>
                      <TableCell>{income.notes}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="expense" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Log Expense</CardTitle>
              <CardDescription>Record money spent on vehicle operations</CardDescription>
            </CardHeader>
            <CardContent>
              <Form {...expenseForm}>
                <form onSubmit={expenseForm.handleSubmit(onExpenseSubmit)} className="space-y-4">
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4">
                    <FormField
                      control={expenseForm.control}
                      name="name"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Expense Name</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter expense name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={expenseForm.control}
                      name="date"
                      render={({ field }) => (
                        <FormItem className="flex flex-col">
                          <FormLabel>Expense Date</FormLabel>
                          <Popover>
                            <PopoverTrigger asChild>
                              <FormControl>
                                <Button
                                  variant={"outline"}
                                  className={cn(
                                    "w-full pl-3 text-left font-normal",
                                    !field.value && "text-muted-foreground",
                                  )}
                                >
                                  {field.value ? format(field.value, "PPP") : <span>Pick a date</span>}
                                  <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                                </Button>
                              </FormControl>
                            </PopoverTrigger>
                            <PopoverContent className="w-auto p-0" align="start">
                              <Calendar mode="single" selected={field.value} onSelect={field.onChange} initialFocus />
                            </PopoverContent>
                          </Popover>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={expenseForm.control}
                      name="amount"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Amount (Kshs)</FormLabel>
                          <FormControl>
                            <Input type="number" placeholder="Enter amount" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={expenseForm.control}
                      name="category"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Category</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select category" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="FUEL">Fuel Costs</SelectItem>
                              <SelectItem value="LABOR">Labor & Wages</SelectItem>
                              <SelectItem value="MAINTENANCE">Service & Maintenance</SelectItem>
                              <SelectItem value="PERMITS">Permits & Licenses</SelectItem>
                              <SelectItem value="INSURANCE">Insurance</SelectItem>
                              <SelectItem value="MISCELLANEOUS">Miscellaneous</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={expenseForm.control}
                      name="paymentMethod"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Payment Method</FormLabel>
                          <Select onValueChange={field.onChange} defaultValue={field.value}>
                            <FormControl>
                              <SelectTrigger>
                                <SelectValue placeholder="Select payment method" />
                              </SelectTrigger>
                            </FormControl>
                            <SelectContent>
                              <SelectItem value="CASH">Cash</SelectItem>
                              <SelectItem value="MPESA">M-Pesa</SelectItem>
                              <SelectItem value="BANK">Bank Transfer</SelectItem>
                              <SelectItem value="CREDIT">Credit</SelectItem>
                              <SelectItem value="CHEQUE">Cheque</SelectItem>
                            </SelectContent>
                          </Select>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={expenseForm.control}
                      name="paidBy"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Paid By</FormLabel>
                          <FormControl>
                            <Input placeholder="Enter payer name" {...field} />
                          </FormControl>
                          <FormMessage />
                        </FormItem>
                      )}
                    />

                    <FormField
                      control={expenseForm.control}
                      name="receipt"
                      render={({ field }) => (
                        <FormItem>
                          <FormLabel>Receipt Upload (Optional)</FormLabel>
                          <FormControl>
                            <div className="flex items-center gap-2">
                              <Input
                                type="file"
                                accept="image/*,.pdf"
                                onChange={(e) => field.onChange(e.target.files?.[0])}
                                className="flex-1"
                              />
                              <Button type="button" size="icon" variant="outline">
                                <Upload className="h-4 w-4" />
                              </Button>
                            </div>
                          </FormControl>
                          <FormDescription>Upload a receipt image or PDF (max 5MB)</FormDescription>
                          <FormMessage />
                        </FormItem>
                      )}
                    />
                  </div>

                  <FormField
                    control={expenseForm.control}
                    name="notes"
                    render={({ field }) => (
                      <FormItem>
                        <FormLabel>Notes (Optional)</FormLabel>
                        <FormControl>
                          <Textarea placeholder="Add any additional notes here" {...field} />
                        </FormControl>
                        <FormMessage />
                      </FormItem>
                    )}
                  />

                  <Button type="submit">Add Expense</Button>
                </form>
              </Form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Expense Summary</CardTitle>
              <CardDescription>Recent expense entries</CardDescription>
            </CardHeader>
            <CardContent>
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Expense Name</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Paid By</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead>Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expenses.map((expense) => (
                    <TableRow key={expense.id}>
                      <TableCell>{expense.name}</TableCell>
                      <TableCell>{expense.amount.toLocaleString()}</TableCell>
                      <TableCell>{expense.date}</TableCell>
                      <TableCell>{expense.category}</TableCell>
                      <TableCell>{expense.paymentMethod}</TableCell>
                      <TableCell>{expense.paidBy}</TableCell>
                      <TableCell>{expense.hasReceipt ? "Yes" : "No"}</TableCell>
                      <TableCell>{expense.notes}</TableCell>
                      <TableCell>
                        <Button variant="ghost" size="sm">
                          Edit
                        </Button>
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  )
}
