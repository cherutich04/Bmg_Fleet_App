"use client"

import type React from "react"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Textarea } from "@/components/ui/textarea"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Badge } from "@/components/ui/badge"
import { format } from "date-fns"
import { Search, Send, MessageSquare, Trash2 } from "lucide-react"
import {
  AlertDialog,
  AlertDialogAction,
  AlertDialogCancel,
  AlertDialogContent,
  AlertDialogDescription,
  AlertDialogFooter,
  AlertDialogHeader,
  AlertDialogTitle,
  AlertDialogTrigger,
} from "@/components/ui/alert-dialog"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
  DialogTrigger,
} from "@/components/ui/dialog"
import { useSession } from "next-auth/react"

// Mock data for messages
const messagesData = [
  {
    id: "1",
    sender: "Admin",
    receiver: "John Doe",
    receiverId: "1",
    content: "Please submit your fuel receipts for the Kaberewo trip by tomorrow.",
    timestamp: "2023-04-15T10:30:00",
    isRead: true,
  },
  {
    id: "2",
    sender: "Admin",
    receiver: "John Doe",
    receiverId: "1",
    content: "Your vehicle KDG 442X is scheduled for maintenance next week at Eldoret Motors.",
    timestamp: "2023-04-16T09:15:00",
    isRead: false,
  },
  {
    id: "3",
    sender: "John Doe",
    senderId: "1",
    receiver: "Admin",
    content: "I've submitted all receipts for the Kaberewo trip in the expense system.",
    timestamp: "2023-04-16T11:45:00",
    isRead: true,
  },
  {
    id: "4",
    sender: "Admin",
    receiver: "All Drivers",
    content: "Reminder: Monthly meeting this Friday at 2 PM at the Eldoret office.",
    timestamp: "2023-04-17T08:00:00",
    isRead: false,
  },
]

export default function DriverMessagesPage() {
  const { data: session } = useSession()
  const driverName = session?.user ? `${session.user.surname} ${session.user.name}` : "John Doe"

  const [activeTab, setActiveTab] = useState("inbox")
  const [searchQuery, setSearchQuery] = useState("")
  const [messages, setMessages] = useState(messagesData)
  const [newMessage, setNewMessage] = useState({
    content: "",
  })
  const [selectedMessage, setSelectedMessage] = useState<any>(null)
  const [isComposeDialogOpen, setIsComposeDialogOpen] = useState(false)
  const [isViewDialogOpen, setIsViewDialogOpen] = useState(false)

  // Filter messages based on search query and tab
  const filteredMessages = messages.filter((message) => {
    // Filter by search query
    const matchesSearch = message.content.toLowerCase().includes(searchQuery.toLowerCase())

    // Filter by tab and driver
    const matchesTab =
      activeTab === "inbox"
        ? message.receiver === driverName || message.receiver === "All Drivers"
        : activeTab === "sent"
          ? message.sender === driverName
          : activeTab === "unread"
            ? !message.isRead && (message.receiver === driverName || message.receiver === "All Drivers")
            : true

    return matchesSearch && matchesTab
  })

  // Handle new message input change
  const handleNewMessageChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setNewMessage({
      content: e.target.value,
    })
  }

  // Send message
  const handleSendMessage = () => {
    if (newMessage.content) {
      const newMessageObj = {
        id: (messages.length + 1).toString(),
        sender: driverName,
        senderId: "1", // In a real app, this would be the actual driver ID
        receiver: "Admin",
        content: newMessage.content,
        timestamp: new Date().toISOString(),
        isRead: false,
      }

      setMessages([...messages, newMessageObj])
      setNewMessage({
        content: "",
      })
      setIsComposeDialogOpen(false)
    }
  }

  // View message
  const handleViewMessage = (message: any) => {
    setSelectedMessage(message)
    setIsViewDialogOpen(true)

    // Mark as read if it's an inbox message
    if ((message.receiver === driverName || message.receiver === "All Drivers") && !message.isRead) {
      setMessages(messages.map((m) => (m.id === message.id ? { ...m, isRead: true } : m)))
    }
  }

  // Delete message
  const handleDeleteMessage = (id: string) => {
    setMessages(messages.filter((message) => message.id !== id))
    if (selectedMessage?.id === id) {
      setIsViewDialogOpen(false)
    }
  }

  // Format timestamp
  const formatTimestamp = (timestamp: string) => {
    return format(new Date(timestamp), "MMM d, yyyy h:mm a")
  }

  return (
    <div className="space-y-6">
      <div className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
        <h1 className="text-2xl font-bold">Messages</h1>
        <div className="flex flex-col md:flex-row gap-4 w-full md:w-auto">
          <div className="relative w-full md:w-64">
            <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
            <Input
              placeholder="Search messages..."
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              className="pl-8"
            />
          </div>
          <Dialog open={isComposeDialogOpen} onOpenChange={setIsComposeDialogOpen}>
            <DialogTrigger asChild>
              <Button>
                <MessageSquare className="mr-2 h-4 w-4" />
                Message Admin
              </Button>
            </DialogTrigger>
            <DialogContent>
              <DialogHeader>
                <DialogTitle>New Message</DialogTitle>
                <DialogDescription>Send a message to the admin</DialogDescription>
              </DialogHeader>
              <div className="grid gap-4 py-4">
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="receiver" className="text-right text-sm font-medium">
                    To
                  </label>
                  <div className="col-span-3">
                    <Input value="Admin" disabled />
                  </div>
                </div>
                <div className="grid grid-cols-4 items-center gap-4">
                  <label htmlFor="content" className="text-right text-sm font-medium">
                    Message
                  </label>
                  <Textarea
                    id="content"
                    value={newMessage.content}
                    onChange={handleNewMessageChange}
                    className="col-span-3"
                    placeholder="Type your message here"
                    rows={5}
                  />
                </div>
              </div>
              <DialogFooter>
                <Button type="button" variant="outline" onClick={() => setIsComposeDialogOpen(false)}>
                  Cancel
                </Button>
                <Button type="button" onClick={handleSendMessage} disabled={!newMessage.content}>
                  <Send className="mr-2 h-4 w-4" />
                  Send Message
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </div>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Messages</CardTitle>
          <CardDescription>Your communications with admin</CardDescription>
        </CardHeader>
        <CardContent>
          <Tabs value={activeTab} onValueChange={setActiveTab}>
            <TabsList className="grid w-full grid-cols-3">
              <TabsTrigger value="inbox">Inbox</TabsTrigger>
              <TabsTrigger value="sent">Sent</TabsTrigger>
              <TabsTrigger value="unread">Unread</TabsTrigger>
            </TabsList>

            <TabsContent value={activeTab} className="mt-4">
              <div className="space-y-2">
                {filteredMessages.length > 0 ? (
                  filteredMessages.map((message) => (
                    <div
                      key={message.id}
                      className={`p-4 rounded-md border cursor-pointer hover:bg-muted transition-colors ${
                        !message.isRead && (message.receiver === driverName || message.receiver === "All Drivers")
                          ? "bg-blue-50 dark:bg-blue-900/20"
                          : ""
                      }`}
                      onClick={() => handleViewMessage(message)}
                    >
                      <div className="flex justify-between items-start">
                        <div>
                          <p className="font-medium">
                            {message.receiver === "Admin" ? "To: Admin" : `From: ${message.sender}`}
                          </p>
                          <p className="text-sm text-muted-foreground line-clamp-1">{message.content}</p>
                        </div>
                        <div className="flex flex-col items-end">
                          <p className="text-xs text-muted-foreground">{formatTimestamp(message.timestamp)}</p>
                          {!message.isRead &&
                            (message.receiver === driverName || message.receiver === "All Drivers") && (
                              <Badge className="mt-1 bg-blue-100 text-blue-800 dark:bg-blue-900 dark:text-blue-300">
                                New
                              </Badge>
                            )}
                        </div>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <MessageSquare className="h-12 w-12 mx-auto text-muted-foreground opacity-50" />
                    <p className="mt-2 text-muted-foreground">No messages found</p>
                  </div>
                )}
              </div>
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>

      {/* View Message Dialog */}
      <Dialog open={isViewDialogOpen} onOpenChange={setIsViewDialogOpen}>
        <DialogContent>
          <DialogHeader>
            <DialogTitle>
              {selectedMessage?.receiver === "Admin" ? "To: Admin" : `From: ${selectedMessage?.sender}`}
            </DialogTitle>
            <DialogDescription>{formatTimestamp(selectedMessage?.timestamp || "")}</DialogDescription>
          </DialogHeader>
          <div className="py-4">
            <p className="whitespace-pre-wrap">{selectedMessage?.content}</p>
          </div>
          <DialogFooter>
            <AlertDialog>
              <AlertDialogTrigger asChild>
                <Button variant="outline" className="text-red-500">
                  <Trash2 className="mr-2 h-4 w-4" />
                  Delete
                </Button>
              </AlertDialogTrigger>
              <AlertDialogContent>
                <AlertDialogHeader>
                  <AlertDialogTitle>Are you sure?</AlertDialogTitle>
                  <AlertDialogDescription>
                    This will permanently delete this message. This action cannot be undone.
                  </AlertDialogDescription>
                </AlertDialogHeader>
                <AlertDialogFooter>
                  <AlertDialogCancel>Cancel</AlertDialogCancel>
                  <AlertDialogAction
                    onClick={() => handleDeleteMessage(selectedMessage?.id)}
                    className="bg-red-500 hover:bg-red-600"
                  >
                    Delete
                  </AlertDialogAction>
                </AlertDialogFooter>
              </AlertDialogContent>
            </AlertDialog>
            <Button onClick={() => setIsViewDialogOpen(false)}>Close</Button>
          </DialogFooter>
        </DialogContent>
      </Dialog>
    </div>
  )
}
