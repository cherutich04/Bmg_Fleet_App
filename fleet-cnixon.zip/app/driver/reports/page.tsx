"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { CalendarIcon, FileDown } from "lucide-react"
import { format } from "date-fns"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { cn } from "@/lib/utils"
import { MonthlyTargetCard } from "@/components/monthly-target-card"

// Mock data for expenses
const mockExpenses = [
  {
    id: "1",
    name: "Fuel at Total Eldoret",
    date: "2023-04-12",
    amount: 5000,
    category: "FUEL",
    paymentMethod: "MPESA",
    receipt: true,
    notes: "Full tank refill at Total Eldoret",
    status: "APPROVED",
  },
  {
    id: "2",
    name: "Tire repair at Kapsoya",
    date: "2023-04-14",
    amount: 1500,
    category: "MAINTENANCE",
    paymentMethod: "CASH",
    receipt: true,
    notes: "Puncture repair at Kapsoya garage",
    status: "APPROVED",
  },
  {
    id: "3",
    name: "Car wash at Pioneer",
    date: "2023-04-16",
    amount: 500,
    category: "MISCELLANEOUS",
    paymentMethod: "CASH",
    receipt: false,
    notes: "Car wash at Pioneer",
    status: "PENDING",
  },
  {
    id: "4",
    name: "Lunch at Poa Place",
    date: "2023-04-15",
    amount: 350,
    category: "MISCELLANEOUS",
    paymentMethod: "CASH",
    receipt: false,
    notes: "During long trip to Nauyapong",
    status: "REJECTED",
    rejectionReason: "Personal expenses are not covered",
  },
]

// Mock data for monthly target
const targetData = {
  month: "April",
  targetPercentage: 15,
  amountRealized: 35000,
  targetAmount: 200000,
  tripsCompleted: 4,
  lastUpdated: "15 min ago",
  currentDestination: "Kaberewo",
}

export default function ReportsPage() {
  const [startDate, setStartDate] = useState<Date>()
  const [endDate, setEndDate] = useState<Date>()
  const [category, setCategory] = useState<string>("")
  const [paymentMethod, setPaymentMethod] = useState<string>("")
  const [filteredExpenses, setFilteredExpenses] = useState(mockExpenses)
  const [activeTab, setActiveTab] = useState("all")

  // Filter expenses based on selected criteria
  const applyFilters = () => {
    let filtered = [...mockExpenses]

    if (startDate) {
      filtered = filtered.filter((expense) => new Date(expense.date) >= startDate)
    }

    if (endDate) {
      filtered = filtered.filter((expense) => new Date(expense.date) <= endDate)
    }

    if (category) {
      filtered = filtered.filter((expense) => expense.category === category)
    }

    if (paymentMethod) {
      filtered = filtered.filter((expense) => expense.paymentMethod === paymentMethod)
    }

    if (activeTab !== "all") {
      filtered = filtered.filter((expense) => expense.status.toLowerCase() === activeTab)
    }

    setFilteredExpenses(filtered)
  }

  // Reset all filters
  const resetFilters = () => {
    setStartDate(undefined)
    setEndDate(undefined)
    setCategory("")
    setPaymentMethod("")
    setFilteredExpenses(mockExpenses)
  }

  // Download report as PDF
  const downloadPDF = () => {
    // In a real app, this would generate and download a PDF
    console.log("Downloading PDF report")
  }

  return (
    <div className="space-y-6">
      <h1 className="text-2xl font-bold">Reports & Analytics</h1>

      <div className="grid grid-cols-1 lg:grid-cols-3 gap-6">
        <div className="lg:col-span-2">
          <Card>
            <CardHeader>
              <CardTitle>Expense History</CardTitle>
              <CardDescription>View and filter your expense records</CardDescription>
            </CardHeader>
            <CardContent className="space-y-4">
              <div className="flex flex-col md:flex-row gap-4">
                <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1">
                  <div className="space-y-2">
                    <label className="text-sm font-medium">Start Date</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !startDate && "text-muted-foreground",
                          )}
                        >
                          {startDate ? format(startDate, "PPP") : <span>Pick a date</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">End Date</label>
                    <Popover>
                      <PopoverTrigger asChild>
                        <Button
                          variant={"outline"}
                          className={cn(
                            "w-full justify-start text-left font-normal",
                            !endDate && "text-muted-foreground",
                          )}
                        >
                          {endDate ? format(endDate, "PPP") : <span>Pick a date</span>}
                          <CalendarIcon className="ml-auto h-4 w-4 opacity-50" />
                        </Button>
                      </PopoverTrigger>
                      <PopoverContent className="w-auto p-0" align="start">
                        <Calendar mode="single" selected={endDate} onSelect={setEndDate} initialFocus />
                      </PopoverContent>
                    </Popover>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Category</label>
                    <Select value={category} onValueChange={setCategory}>
                      <SelectTrigger>
                        <SelectValue placeholder="All categories" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All categories</SelectItem>
                        <SelectItem value="FUEL">Fuel Costs</SelectItem>
                        <SelectItem value="LABOR">Labor & Wages</SelectItem>
                        <SelectItem value="MAINTENANCE">Service & Maintenance</SelectItem>
                        <SelectItem value="PERMITS">Permits & Licenses</SelectItem>
                        <SelectItem value="INSURANCE">Insurance</SelectItem>
                        <SelectItem value="MISCELLANEOUS">Miscellaneous</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <label className="text-sm font-medium">Payment Method</label>
                    <Select value={paymentMethod} onValueChange={setPaymentMethod}>
                      <SelectTrigger>
                        <SelectValue placeholder="All payment methods" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="">All payment methods</SelectItem>
                        <SelectItem value="CASH">Cash</SelectItem>
                        <SelectItem value="MPESA">M-Pesa</SelectItem>
                        <SelectItem value="BANK">Bank Transfer</SelectItem>
                        <SelectItem value="CREDIT">Credit</SelectItem>
                        <SelectItem value="CHEQUE">Cheque</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <div className="flex flex-col justify-end gap-2">
                  <Button onClick={applyFilters}>Apply Filters</Button>
                  <Button variant="outline" onClick={resetFilters}>
                    Reset
                  </Button>
                  <Button variant="outline" onClick={downloadPDF}>
                    <FileDown className="mr-2 h-4 w-4" />
                    Download PDF
                  </Button>
                </div>
              </div>

              <Tabs value={activeTab} onValueChange={setActiveTab} className="w-full">
                <TabsList className="grid grid-cols-4">
                  <TabsTrigger value="all">All</TabsTrigger>
                  <TabsTrigger value="approved">Approved</TabsTrigger>
                  <TabsTrigger value="pending">Pending</TabsTrigger>
                  <TabsTrigger value="rejected">Rejected</TabsTrigger>
                </TabsList>

                <TabsContent value="all" className="mt-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Expense Name</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount (Kshs)</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Payment Method</TableHead>
                        <TableHead>Receipt</TableHead>
                        <TableHead>Status</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredExpenses.map((expense) => (
                        <TableRow key={expense.id}>
                          <TableCell>{expense.name}</TableCell>
                          <TableCell>{expense.date}</TableCell>
                          <TableCell>{expense.amount.toLocaleString()}</TableCell>
                          <TableCell>{expense.category}</TableCell>
                          <TableCell>{expense.paymentMethod}</TableCell>
                          <TableCell>{expense.receipt ? "Yes" : "No"}</TableCell>
                          <TableCell>
                            <span
                              className={cn(
                                "px-2 py-1 rounded-full text-xs font-medium",
                                expense.status === "APPROVED" &&
                                  "bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300",
                                expense.status === "PENDING" &&
                                  "bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300",
                                expense.status === "REJECTED" &&
                                  "bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300",
                              )}
                            >
                              {expense.status}
                            </span>
                          </TableCell>
                          <TableCell>
                            {expense.status === "REJECTED" && expense.rejectionReason ? (
                              <span className="text-red-600 dark:text-red-400">{expense.rejectionReason}</span>
                            ) : (
                              expense.notes
                            )}
                          </TableCell>
                        </TableRow>
                      ))}
                    </TableBody>
                  </Table>
                </TabsContent>

                <TabsContent value="approved" className="mt-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Expense Name</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount (Kshs)</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Payment Method</TableHead>
                        <TableHead>Receipt</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredExpenses
                        .filter((e) => e.status === "APPROVED")
                        .map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell>{expense.name}</TableCell>
                            <TableCell>{expense.date}</TableCell>
                            <TableCell>{expense.amount.toLocaleString()}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell>{expense.paymentMethod}</TableCell>
                            <TableCell>{expense.receipt ? "Yes" : "No"}</TableCell>
                            <TableCell>{expense.notes}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TabsContent>

                <TabsContent value="pending" className="mt-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Expense Name</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount (Kshs)</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Payment Method</TableHead>
                        <TableHead>Receipt</TableHead>
                        <TableHead>Notes</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredExpenses
                        .filter((e) => e.status === "PENDING")
                        .map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell>{expense.name}</TableCell>
                            <TableCell>{expense.date}</TableCell>
                            <TableCell>{expense.amount.toLocaleString()}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell>{expense.paymentMethod}</TableCell>
                            <TableCell>{expense.receipt ? "Yes" : "No"}</TableCell>
                            <TableCell>{expense.notes}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TabsContent>

                <TabsContent value="rejected" className="mt-4">
                  <Table>
                    <TableHeader>
                      <TableRow>
                        <TableHead>Expense Name</TableHead>
                        <TableHead>Date</TableHead>
                        <TableHead>Amount (Kshs)</TableHead>
                        <TableHead>Category</TableHead>
                        <TableHead>Payment Method</TableHead>
                        <TableHead>Receipt</TableHead>
                        <TableHead>Rejection Reason</TableHead>
                      </TableRow>
                    </TableHeader>
                    <TableBody>
                      {filteredExpenses
                        .filter((e) => e.status === "REJECTED")
                        .map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell>{expense.name}</TableCell>
                            <TableCell>{expense.date}</TableCell>
                            <TableCell>{expense.amount.toLocaleString()}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell>{expense.paymentMethod}</TableCell>
                            <TableCell>{expense.receipt ? "Yes" : "No"}</TableCell>
                            <TableCell className="text-red-600 dark:text-red-400">{expense.rejectionReason}</TableCell>
                          </TableRow>
                        ))}
                    </TableBody>
                  </Table>
                </TabsContent>
              </Tabs>
            </CardContent>
          </Card>
        </div>

        <div>
          <MonthlyTargetCard {...targetData} />

          <Card className="mt-6">
            <CardHeader>
              <CardTitle>Expense Analytics</CardTitle>
              <CardDescription>Breakdown of your expenses</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="h-64 bg-muted rounded flex items-center justify-center text-muted-foreground mb-4">
                Pie chart placeholder
              </div>
              <div className="h-64 bg-muted rounded flex items-center justify-center text-muted-foreground">
                Bar chart placeholder
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </div>
  )
}
