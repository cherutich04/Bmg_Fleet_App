import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-blue-100 p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="text-center">
          <h1 className="text-4xl font-bold tracking-tight text-gray-900">BMG Fleet Management</h1>
          <p className="mt-2 text-gray-600">Manage your fleet efficiently</p>
        </div>

        <Card>
          <CardHeader>
            <CardTitle>Welcome</CardTitle>
            <CardDescription>Please select your role to continue</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="flex flex-col space-y-2">
              <Link href="/driver/login" className="w-full">
                <Button className="w-full bg-blue-600 hover:bg-blue-700">Login as Driver</Button>
              </Link>
              <Link href="/admin/login" className="w-full">
                <Button className="w-full bg-emerald-600 hover:bg-emerald-700">Login as Admin</Button>
              </Link>
            </div>
          </CardContent>
          <CardFooter className="text-center text-sm text-gray-500">© 2025 BMG Fleet Management App</CardFooter>
        </Card>
      </div>
    </div>
  )
}
