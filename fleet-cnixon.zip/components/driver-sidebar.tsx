"use client"

import Link from "next/link"
import { usePathname } from "next/navigation"
import { cn } from "@/lib/utils"
import { Button } from "@/components/ui/button"
import { ChevronLeft, ChevronRight, LayoutDashboard, DollarSign, BarChart, LogOut } from "lucide-react"
import { useState } from "react"
import { signOut } from "next-auth/react"

export function DriverSidebar() {
  const pathname = usePathname()
  const [collapsed, setCollapsed] = useState(false)

  const toggleSidebar = () => {
    setCollapsed(!collapsed)
  }

  const handleLogout = async () => {
    await signOut({ callbackUrl: "/" })
  }

  const navItems = [
    {
      name: "Dashboard",
      href: "/driver/dashboard",
      icon: <LayoutDashboard className="h-5 w-5" />,
    },
    {
      name: "Expense",
      href: "/driver/expense",
      icon: <DollarSign className="h-5 w-5" />,
    },
    {
      name: "Reports & Analytics",
      href: "/driver/reports",
      icon: <BarChart className="h-5 w-5" />,
    },
  ]

  return (
    <div
      className={cn("flex flex-col h-full bg-white border-r transition-all duration-300", collapsed ? "w-16" : "w-64")}
    >
      <div className="flex items-center justify-end p-4">
        <Button
          variant="ghost"
          size="icon"
          onClick={toggleSidebar}
          aria-label={collapsed ? "Expand sidebar" : "Collapse sidebar"}
        >
          {collapsed ? <ChevronRight className="h-5 w-5" /> : <ChevronLeft className="h-5 w-5" />}
        </Button>
      </div>

      <nav className="flex-1 space-y-1 px-2">
        {navItems.map((item) => (
          <Link
            key={item.href}
            href={item.href}
            className={cn(
              "flex items-center px-3 py-3 text-sm font-medium rounded-md transition-colors",
              pathname === item.href
                ? "bg-gradient-to-r from-blue-100 to-blue-50 text-blue-700"
                : "text-gray-700 hover:bg-gray-100",
            )}
          >
            <span className="mr-3">{item.icon}</span>
            {!collapsed && <span>{item.name}</span>}
          </Link>
        ))}
      </nav>

      <div className="p-2 mt-auto">
        <Button
          variant="ghost"
          className={cn(
            "flex items-center w-full px-3 py-3 text-sm font-medium rounded-md text-red-600 hover:bg-red-50",
          )}
          onClick={handleLogout}
        >
          <LogOut className="h-5 w-5 mr-3" />
          {!collapsed && <span>Logout</span>}
        </Button>
      </div>
    </div>
  )
}
