export function Footer() {
  return (
    <footer className="p-4 text-center text-sm text-muted-foreground border-t bg-background">
      © 2025 BMG Fleet Management App
    </footer>
  )
}
