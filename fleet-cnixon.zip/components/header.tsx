"use client"

import { useSession } from "next-auth/react"
import Image from "next/image"
import { Frame } from "lucide-react"
import { useState, useEffect } from "react"
import { ThemeToggle } from "@/components/theme-toggle"

export function Header({ vehiclePlate = "" }: { vehiclePlate?: string }) {
  const { data: session } = useSession()
  const [currentTime, setCurrentTime] = useState(new Date())
  const [currentDate, setCurrentDate] = useState(new Date())

  useEffect(() => {
    const timer = setInterval(() => {
      setCurrentTime(new Date())
    }, 1000)

    return () => {
      clearInterval(timer)
    }
  }, [])

  const formatTime = (date: Date) => {
    return date.toLocaleTimeString("en-US", {
      hour: "2-digit",
      minute: "2-digit",
      second: "2-digit",
      hour12: true,
    })
  }

  const formatDate = (date: Date) => {
    return date.toLocaleDateString("en-US", {
      weekday: "short",
      year: "numeric",
      month: "short",
      day: "numeric",
    })
  }

  return (
    <header className="flex flex-col md:flex-row items-center justify-between p-4 bg-background border-b">
      <div className="flex items-center mb-4 md:mb-0">
        <Frame className="h-8 w-8 mr-2 text-blue-600 dark:text-blue-400" />
        <h1 className="text-xl font-bold text-center">BMG FLEET MANAGEMENT APP</h1>
      </div>

      <div className="flex flex-col md:flex-row items-center space-y-2 md:space-y-0 md:space-x-6">
        {session?.user && (
          <div className="flex items-center">
            <div className="relative h-10 w-10 rounded-full overflow-hidden border-2 border-blue-500 mr-3">
              <Image
                src="/placeholder.svg?height=40&width=40"
                alt="Profile"
                width={40}
                height={40}
                className="object-cover"
              />
            </div>
            <div>
              <p className="text-sm font-medium">
                Driver: {session.user.surname} {session.user.name}
              </p>
              {vehiclePlate && <p className="text-xs text-muted-foreground">Vehicle: {vehiclePlate}</p>}
            </div>
          </div>
        )}

        <div className="text-right">
          <p className="text-sm font-medium">{formatTime(currentTime)}</p>
          <p className="text-xs text-muted-foreground">{formatDate(currentDate)}</p>
        </div>

        <ThemeToggle />
      </div>
    </header>
  )
}
