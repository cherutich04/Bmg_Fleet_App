import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"

interface MonthlyTargetCardProps {
  month: string
  targetPercentage: number
  amountRealized: number
  targetAmount: number
  tripsCompleted: number
  safetyScore?: number
  lastUpdated: string
  currentDestination?: string
}

export function MonthlyTargetCard({
  month,
  targetPercentage,
  amountRealized,
  targetAmount,
  tripsCompleted,
  safetyScore,
  lastUpdated,
  currentDestination,
}: MonthlyTargetCardProps) {
  const getProgressColor = (percentage: number) => {
    if (percentage <= 25) return "bg-red-500"
    if (percentage <= 50) return "bg-orange-500"
    if (percentage <= 75) return "bg-emerald-500"
    return "bg-green-700"
  }

  return (
    <Card className="bg-emerald-50 border-emerald-200">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-emerald-900">MONTHLY TARGET</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-sm font-medium text-emerald-800 mb-2">Month: {month}</h3>
          <div className="space-y-3 text-sm">
            <div>
              <div className="flex justify-between mb-1">
                <span className="text-gray-500">Target Achieved:</span>
                <span className="font-medium">{targetPercentage}%</span>
              </div>
              <Progress
                value={targetPercentage}
                className="h-2"
                indicatorClassName={getProgressColor(targetPercentage)}
              />
            </div>

            <div className="flex justify-between">
              <div>
                <span className="text-gray-500">Amount Realized:</span>
                <div className="text-amber-600 font-medium">Ksh. {amountRealized.toLocaleString()}</div>
              </div>
              <div className="text-right">
                <span className="text-gray-500">Set Monthly Target:</span>
                <div className="text-amber-600 font-medium">Ksh. {targetAmount.toLocaleString()}</div>
              </div>
            </div>

            <div>
              <span className="text-gray-500">Trips Completed:</span> {tripsCompleted} Trips
            </div>

            {safetyScore !== undefined && (
              <div>
                <span className="text-gray-500">Safety Score:</span> {safetyScore}
              </div>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-emerald-800 mb-2">Map snippet</h3>
          <div className="space-y-2 text-sm">
            <div className="h-24 bg-gray-200 rounded flex items-center justify-center text-gray-500">
              Map placeholder
            </div>
            <div>
              <span className="text-gray-500">Last updated:</span> {lastUpdated}
            </div>
            {currentDestination && (
              <div>
                <span className="text-gray-500">Enroute to:</span> {currentDestination}
              </div>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
