import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Bell, AlertTriangle, CheckCircle } from "lucide-react"

interface AlertItem {
  id: string
  type: "maintenance" | "other"
  severity: "critical" | "warning" | "info"
  message: string
}

interface NotificationItem {
  id: string
  message: string
  timestamp: string
}

interface NotificationsCardProps {
  alerts: AlertItem[]
  notifications: NotificationItem[]
}

export function NotificationsCard({ alerts, notifications }: NotificationsCardProps) {
  const getAlertVariant = (severity: string) => {
    switch (severity) {
      case "critical":
        return "destructive"
      case "warning":
        return "warning"
      default:
        return "default"
    }
  }

  const getAlertIcon = (severity: string) => {
    switch (severity) {
      case "critical":
        return <AlertTriangle className="h-4 w-4" />
      case "warning":
        return <AlertTriangle className="h-4 w-4" />
      default:
        return <CheckCircle className="h-4 w-4" />
    }
  }

  return (
    <Card className="bg-cyan-50 border-cyan-200">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-cyan-900">NOTIFICATIONS AND ALERTS</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-sm font-medium text-cyan-800 mb-2">Alerts:</h3>
          <div className="space-y-2">
            {alerts.length > 0 ? (
              alerts.map((alert) => (
                <Alert key={alert.id} variant={getAlertVariant(alert.severity)}>
                  {getAlertIcon(alert.severity)}
                  <AlertTitle>{alert.type === "maintenance" ? "Maintenance Alert" : "Alert"}</AlertTitle>
                  <AlertDescription>{alert.message}</AlertDescription>
                </Alert>
              ))
            ) : (
              <p className="text-sm text-gray-500">No alerts at this time.</p>
            )}
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-cyan-800 mb-2">Notifications:</h3>
          <div className="space-y-2">
            {notifications.length > 0 ? (
              notifications.map((notification) => (
                <div key={notification.id} className="flex items-start space-x-2 p-2 bg-white rounded-md">
                  <Bell className="h-4 w-4 text-cyan-600 mt-0.5" />
                  <div>
                    <p className="text-sm">{notification.message}</p>
                    <p className="text-xs text-gray-500">{notification.timestamp}</p>
                  </div>
                </div>
              ))
            ) : (
              <p className="text-sm text-gray-500">No notifications at this time.</p>
            )}
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
