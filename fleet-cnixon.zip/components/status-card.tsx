"use client"

import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Badge } from "@/components/ui/badge"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { useState } from "react"

interface StatusCardProps {
  assignedFrom: string
  assignedTo: string
  model: string
  plate: string
  type: string
  status: "ACTIVE" | "INACTIVE" | "MAINTENANCE"
  odometer: number
  fuelEfficiency: number
  onOdometerUpdate?: (value: number) => void
}

export function StatusCard({
  assignedFrom,
  assignedTo,
  model,
  plate,
  type,
  status,
  odometer,
  fuelEfficiency,
  onOdometerUpdate,
}: StatusCardProps) {
  const [newOdometer, setNewOdometer] = useState(odometer.toString())

  const getStatusColor = (status: string) => {
    switch (status) {
      case "ACTIVE":
        return "bg-green-100 text-green-800 hover:bg-green-200"
      case "INACTIVE":
        return "bg-gray-100 text-gray-800 hover:bg-gray-200"
      case "MAINTENANCE":
        return "bg-orange-100 text-orange-800 hover:bg-orange-200"
      default:
        return "bg-gray-100 text-gray-800 hover:bg-gray-200"
    }
  }

  const handleOdometerUpdate = () => {
    if (onOdometerUpdate) {
      onOdometerUpdate(Number.parseFloat(newOdometer))
    }
  }

  return (
    <Card className="bg-cyan-50 border-cyan-200">
      <CardHeader className="pb-2">
        <CardTitle className="text-lg text-cyan-900">STATUS</CardTitle>
      </CardHeader>
      <CardContent className="space-y-4">
        <div>
          <h3 className="text-sm font-medium text-cyan-800 mb-2">Vehicle Basics</h3>
          <div className="space-y-2 text-sm">
            <div>
              <span className="text-gray-500">Assigned From:</span> {assignedFrom}{" "}
              <span className="text-gray-500">To:</span> {assignedTo}
            </div>
            <div className="flex items-center justify-between">
              <div>
                <span className="text-gray-500">Model:</span>
                <span className="ml-1 px-2 py-0.5 bg-white rounded">{model}</span>
              </div>
              <Badge className={getStatusColor(status)}>{status}</Badge>
            </div>
            <div>
              <span className="text-gray-500">Plate:</span>
              <span className="ml-1 px-2 py-0.5 bg-yellow-100 text-black rounded">{plate}</span>
            </div>
            <div>
              <span className="text-gray-500">Type:</span> {type}
            </div>
          </div>
        </div>

        <div>
          <h3 className="text-sm font-medium text-cyan-800 mb-2">Performance</h3>
          <div className="space-y-3 text-sm">
            <div>
              <span className="text-gray-500">Odometer:</span> {odometer.toLocaleString()} km
              <div className="flex mt-1 space-x-2">
                <Input
                  type="number"
                  value={newOdometer}
                  onChange={(e) => setNewOdometer(e.target.value)}
                  className="h-8 text-xs"
                  placeholder="Update odometer"
                />
                <Button size="sm" onClick={handleOdometerUpdate} className="h-8 text-xs">
                  Save
                </Button>
              </div>
            </div>
            <div>
              <span className="text-gray-500">Fuel:</span>
              <span className="ml-1 px-2 py-0.5 bg-yellow-100 text-black rounded">{fuelEfficiency}L per 100Km</span>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  )
}
