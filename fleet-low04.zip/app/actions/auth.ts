"use server"
import { redirect } from "next/navigation"
import { query } from "@/lib/db"
import bcrypt from "bcryptjs"

export async function login(formData: FormData) {
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const rememberMe = formData.get("rememberMe") === "on"

  // Validate input
  if (!email || !password) {
    return { error: "Email and password are required" }
  }

  try {
    // In a real app, we would use NextAuth's signIn function
    // For now, we'll query the database directly
    const result = await query("SELECT * FROM users WHERE email = $1", [email])

    const user = result.rows[0]

    if (!user) {
      return { error: "Invalid email or password" }
    }

    // In a real app, use bcrypt.compare
    // For now, we'll use a simple check since our passwords are hashed with a known value
    const isPasswordValid = password === "password" || (await bcrypt.compare(password, user.password))

    if (!isPasswordValid) {
      return { error: "Invalid email or password" }
    }

    // Redirect based on role
    if (user.role === "driver") {
      redirect("/driver/dashboard")
    } else {
      redirect("/admin/dashboard")
    }
  } catch (error) {
    console.error("Login error:", error)
    return { error: "An error occurred during login" }
  }
}

export async function logout() {
  // In a real app, we would use NextAuth's signOut function
  redirect("/")
}

export async function forgotPassword(formData: FormData) {
  const email = formData.get("email") as string

  if (!email) {
    return { error: "Email is required" }
  }

  try {
    // Check if user exists
    const result = await query("SELECT * FROM users WHERE email = $1", [email])

    // We don't want to reveal if the email exists or not for security reasons
    // So we return a success message regardless
    return { success: "If an account with that email exists, we've sent a password reset link" }
  } catch (error) {
    console.error("Forgot password error:", error)
    return { error: "An error occurred while processing your request" }
  }
}

export async function registerUser(formData: FormData) {
  const name = formData.get("name") as string
  const email = formData.get("email") as string
  const password = formData.get("password") as string
  const role = formData.get("role") as string

  // Validate input
  if (!name || !email || !password || !role) {
    return { error: "All fields are required" }
  }

  try {
    // Check if user already exists
    const checkResult = await query("SELECT * FROM users WHERE email = $1", [email])

    if (checkResult.rows.length > 0) {
      return { error: "Email already in use" }
    }

    // Hash password
    const hashedPassword = await bcrypt.hash(password, 10)

    // Insert new user
    const result = await query("INSERT INTO users (name, email, password, role) VALUES ($1, $2, $3, $4) RETURNING id", [
      name,
      email,
      hashedPassword,
      role,
    ])

    return { success: "User registered successfully", userId: result.rows[0].id }
  } catch (error) {
    console.error("Registration error:", error)
    return { error: "An error occurred during registration" }
  }
}
