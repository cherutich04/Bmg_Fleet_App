import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { requireAuth } from "@/lib/auth"
import { AlertCircle, AlertTriangle, Car, Fuel, Info, MapPin, Plus, Target, User, Wrench } from "lucide-react"

export default async function AdminDashboardPage() {
  const user = await requireAuth()

  // Mock data - in a real app, this would come from your database
  const summaryData = {
    activeVehicles: 24,
    maintenanceAlerts: 5,
    fuelEfficiency: "10.2 L/100km",
    compliancePercentage: 92,
  }

  const alerts = [
    {
      id: 1,
      severity: "critical",
      vehicle: "KBZ 123A",
      message: "Brake inspection required",
      time: "2 hours ago",
    },
    {
      id: 2,
      severity: "warning",
      vehicle: "KCA 456B",
      message: "Oil change due in 500km",
      time: "5 hours ago",
    },
    {
      id: 3,
      severity: "warning",
      vehicle: "KDG 789C",
      message: "Tire pressure low",
      time: "1 day ago",
    },
    {
      id: 4,
      severity: "low",
      vehicle: "KBZ 123A",
      message: "Service due in 2 weeks",
      time: "2 days ago",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Admin Dashboard</h2>
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground">
            Welcome back, <span className="font-medium text-foreground">{user.name}</span>
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-4">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Active Vehicles</CardTitle>
            <Car className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryData.activeVehicles}</div>
            <p className="text-xs text-muted-foreground">+2 since last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Maintenance Alerts</CardTitle>
            <Wrench className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryData.maintenanceAlerts}</div>
            <p className="text-xs text-muted-foreground">3 critical, 2 warnings</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Fuel Efficiency</CardTitle>
            <Fuel className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryData.fuelEfficiency}</div>
            <p className="text-xs text-muted-foreground">-0.5 L/100km from last month</p>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between pb-2">
            <CardTitle className="text-sm font-medium">Compliance</CardTitle>
            <Target className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="text-2xl font-bold">{summaryData.compliancePercentage}%</div>
            <p className="text-xs text-muted-foreground">+5% from last month</p>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Live Fleet Map</CardTitle>
            <CardDescription>Current location of all vehicles</CardDescription>
          </CardHeader>
          <CardContent className="p-0">
            <div className="aspect-video relative bg-muted rounded-md overflow-hidden">
              <div className="absolute inset-0 flex items-center justify-center">
                <MapPin className="h-8 w-8 text-primary animate-pulse" />
                <span className="sr-only">Map loading</span>
              </div>
              <div className="absolute bottom-4 right-4 bg-background rounded-md shadow p-2">
                <p className="text-xs font-medium">Google Maps integration will be available here</p>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="col-span-1">
          <CardHeader>
            <CardTitle>Alerts</CardTitle>
            <CardDescription>Prioritized list of alerts</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-4">
              {alerts.map((alert) => {
                let Icon = Info
                let bgColor = "bg-blue-50 dark:bg-blue-950"
                let textColor = "text-blue-700 dark:text-blue-300"
                let borderColor = "border-blue-200 dark:border-blue-800"

                if (alert.severity === "critical") {
                  Icon = AlertCircle
                  bgColor = "bg-red-50 dark:bg-red-950"
                  textColor = "text-red-700 dark:text-red-300"
                  borderColor = "border-red-200 dark:border-red-800"
                } else if (alert.severity === "warning") {
                  Icon = AlertTriangle
                  bgColor = "bg-yellow-50 dark:bg-yellow-950"
                  textColor = "text-yellow-700 dark:text-yellow-300"
                  borderColor = "border-yellow-200 dark:border-yellow-800"
                }

                return (
                  <div
                    key={alert.id}
                    className={`flex items-start gap-3 rounded-md border p-3 ${bgColor} ${borderColor}`}
                  >
                    <Icon className={`h-5 w-5 ${textColor}`} />
                    <div>
                      <div className="flex items-center gap-2">
                        <p className={`text-sm font-medium ${textColor}`}>{alert.vehicle}</p>
                        <span className="text-xs text-muted-foreground">{alert.time}</span>
                      </div>
                      <p className="text-sm">{alert.message}</p>
                    </div>
                  </div>
                )
              })}
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="col-span-2">
          <CardHeader>
            <CardTitle>Analytics</CardTitle>
            <CardDescription>Mileage vs. fuel cost and driver efficiency</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="aspect-[2/1] bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Charts will be displayed here</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Quick Actions</CardTitle>
            <CardDescription>Common tasks</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              <Button className="w-full justify-start gap-2" variant="outline">
                <Car className="h-4 w-4" />
                <span>Assign Vehicle</span>
              </Button>
              <Button className="w-full justify-start gap-2" variant="outline">
                <Plus className="h-4 w-4" />
                <span>Add Project</span>
              </Button>
              <Button className="w-full justify-start gap-2" variant="outline">
                <User className="h-4 w-4" />
                <span>Add Driver</span>
              </Button>
              <Button className="w-full justify-start gap-2" variant="outline">
                <Wrench className="h-4 w-4" />
                <span>Schedule Maintenance</span>
              </Button>
            </div>
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
