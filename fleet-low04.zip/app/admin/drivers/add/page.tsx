import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { requireAuth } from "@/lib/auth"
import { Calendar, Upload, User } from "lucide-react"

export default async function AdminAddDriverPage() {
  await requireAuth()

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Add New Driver</h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Driver Information</CardTitle>
          <CardDescription>Add a new driver to the fleet management system</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="first-name">First Name</Label>
                <Input id="first-name" placeholder="Enter first name" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="last-name">Last Name</Label>
                <Input id="last-name" placeholder="Enter last name" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" placeholder="Enter email address" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="phone">Phone Number</Label>
                <Input id="phone" placeholder="Enter phone number" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="id-number">ID Number</Label>
                <Input id="id-number" placeholder="Enter national ID number" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="license-number">Driver's License Number</Label>
                <Input id="license-number" placeholder="Enter driver's license number" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="license-expiry">License Expiry Date</Label>
                <div className="relative">
                  <Input id="license-expiry" type="date" />
                  <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="date-of-birth">Date of Birth</Label>
                <div className="relative">
                  <Input id="date-of-birth" type="date" />
                  <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="employment-date">Employment Date</Label>
                <div className="relative">
                  <Input id="employment-date" type="date" />
                  <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="driver-type">Driver Type</Label>
                <Select>
                  <SelectTrigger id="driver-type">
                    <SelectValue placeholder="Select driver type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="full-time">Full-time</SelectItem>
                    <SelectItem value="part-time">Part-time</SelectItem>
                    <SelectItem value="contract">Contract</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="address">Address</Label>
              <Textarea id="address" placeholder="Enter physical address" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergency-contact">Emergency Contact</Label>
              <div className="grid gap-4 md:grid-cols-2">
                <Input id="emergency-contact-name" placeholder="Contact name" />
                <Input id="emergency-contact-phone" placeholder="Contact phone" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="profile-picture">Profile Picture</Label>
              <div className="flex items-center gap-2">
                <Button type="button" variant="outline" className="w-full gap-2">
                  <Upload className="h-4 w-4" />
                  Upload Picture
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="license-document">License Document</Label>
              <div className="flex items-center gap-2">
                <Button type="button" variant="outline" className="w-full gap-2">
                  <Upload className="h-4 w-4" />
                  Upload License
                </Button>
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="notes">Additional Notes</Label>
              <Textarea id="notes" placeholder="Enter any additional information" />
            </div>

            <div className="border-t pt-6">
              <h3 className="text-lg font-medium mb-4">Account Setup</h3>
              <div className="grid gap-4 md:grid-cols-2">
                <div className="space-y-2">
                  <Label htmlFor="username">Username</Label>
                  <Input id="username" placeholder="Enter username" />
                </div>

                <div className="space-y-2">
                  <Label htmlFor="password">Temporary Password</Label>
                  <Input id="password" type="password" placeholder="Enter temporary password" />
                </div>
              </div>
            </div>

            <Button type="submit" className="gap-2">
              <User className="h-4 w-4" />
              Add Driver
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
