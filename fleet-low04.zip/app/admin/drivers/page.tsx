import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { requireAuth } from "@/lib/auth"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Edit, FileText, Plus, Search, Trash } from "lucide-react"
import Link from "next/link"

export default async function AdminDriversPage() {
  await requireAuth()

  // Mock data - in a real app, this would come from your database
  const drivers = [
    {
      id: 1,
      name: "John Kipchoge",
      email: "driver@example.com",
      phone: "+254712345678",
      idNumber: "12345678",
      licenseNumber: "DL12345",
      licenseExpiry: "2025-12-31",
      driverType: "full-time",
      status: "active",
      vehicle: "Toyota Hilux (KBZ 123A)",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 2,
      name: "David Kimutai",
      email: "driver2@example.com",
      phone: "+254734567890",
      idNumber: "34567890",
      licenseNumber: "DL23456",
      licenseExpiry: "2024-10-15",
      driverType: "full-time",
      status: "active",
      vehicle: "Isuzu D-Max (KCA 456B)",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 3,
      name: "Peter Kosgei",
      email: "driver3@example.com",
      phone: "+254756789012",
      idNumber: "56789012",
      licenseNumber: "DL34567",
      licenseExpiry: "2024-08-22",
      driverType: "part-time",
      status: "inactive",
      vehicle: "Unassigned",
      image: "/placeholder.svg?height=40&width=40",
    },
    {
      id: 4,
      name: "Samuel Kiptoo",
      email: "driver4@example.com",
      phone: "+254778901234",
      idNumber: "78901234",
      licenseNumber: "DL45678",
      licenseExpiry: "2025-03-18",
      driverType: "contract",
      status: "active",
      vehicle: "Toyota Land Cruiser (KBN 234D)",
      image: "/placeholder.svg?height=40&width=40",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Driver Management</h2>
        <Link href="/admin/drivers/add">
          <Button className="gap-2">
            <Plus className="h-4 w-4" />
            Add Driver
          </Button>
        </Link>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Driver Search</CardTitle>
          <CardDescription>Search for drivers by name, license, or status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="search" placeholder="Search by name or ID..." className="pl-8" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="driver-type">Driver Type</Label>
              <Select>
                <SelectTrigger id="driver-type">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  <SelectItem value="full-time">Full-time</SelectItem>
                  <SelectItem value="part-time">Part-time</SelectItem>
                  <SelectItem value="contract">Contract</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select>
                <SelectTrigger id="status">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button className="w-full gap-2">
                <Search className="h-4 w-4" />
                Search
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Driver List</CardTitle>
          <CardDescription>Manage your drivers</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-7 gap-2 p-4 font-medium border-b">
              <div className="col-span-2">Driver</div>
              <div>License</div>
              <div>Type</div>
              <div>Status</div>
              <div>Vehicle</div>
              <div>Actions</div>
            </div>
            {drivers.map((driver) => (
              <div key={driver.id} className="grid grid-cols-7 gap-2 p-4 border-b last:border-0">
                <div className="col-span-2 flex items-center gap-3">
                  <Avatar>
                    <AvatarImage src={driver.image || "/placeholder.svg"} alt={driver.name} />
                    <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div>
                    <div className="font-medium">{driver.name}</div>
                    <div className="text-sm text-muted-foreground">{driver.phone}</div>
                  </div>
                </div>
                <div>
                  <div>{driver.licenseNumber}</div>
                  <div className="text-sm text-muted-foreground">
                    Expires: {new Date(driver.licenseExpiry).toLocaleDateString()}
                  </div>
                </div>
                <div>{driver.driverType}</div>
                <div>
                  {driver.status === "active" ? (
                    <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900 dark:text-green-300">
                      Active
                    </span>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 dark:bg-gray-800 dark:text-gray-300">
                      Inactive
                    </span>
                  )}
                </div>
                <div>{driver.vehicle}</div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Edit</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <FileText className="h-4 w-4" />
                    <span className="sr-only">View Details</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                    <Trash className="h-4 w-4" />
                    <span className="sr-only">Delete</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
