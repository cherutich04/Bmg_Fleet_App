import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { requireAuth } from "@/lib/auth"
import { Car, Edit, FileText, Plus, Search, Trash } from "lucide-react"

export default async function AdminFleetPage() {
  await requireAuth()

  // Mock data - in a real app, this would come from your database
  const vehicles = [
    {
      id: 1,
      name: "Toyota Hilux",
      plate: "KBZ 123A",
      type: "Pickup Truck",
      status: "active",
      odometer: 45678,
      fuelConsumption: "12.5 L/100km",
      assignedTo: "John Kipchoge",
      purchaseDate: "2020-05-15",
      insuranceExpiry: "2023-12-31",
    },
    {
      id: 2,
      name: "Isuzu D-Max",
      plate: "KCA 456B",
      type: "Pickup Truck",
      status: "active",
      odometer: 32456,
      fuelConsumption: "13.2 L/100km",
      assignedTo: "David Kimutai",
      purchaseDate: "2021-03-10",
      insuranceExpiry: "2023-10-15",
    },
    {
      id: 3,
      name: "Ford Ranger",
      plate: "KDG 789C",
      type: "Pickup Truck",
      status: "maintenance",
      odometer: 67890,
      fuelConsumption: "14.0 L/100km",
      assignedTo: "Unassigned",
      purchaseDate: "2019-11-22",
      insuranceExpiry: "2023-08-30",
    },
    {
      id: 4,
      name: "Toyota Land Cruiser",
      plate: "KBN 234D",
      type: "SUV",
      status: "active",
      odometer: 23456,
      fuelConsumption: "15.5 L/100km",
      assignedTo: "John Kipchoge",
      purchaseDate: "2022-01-05",
      insuranceExpiry: "2024-02-28",
    },
    {
      id: 5,
      name: "Mitsubishi Fuso",
      plate: "KCT 567E",
      type: "Truck",
      status: "active",
      odometer: 78901,
      fuelConsumption: "18.0 L/100km",
      assignedTo: "Unassigned",
      purchaseDate: "2018-07-12",
      insuranceExpiry: "2023-09-15",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Fleet Management</h2>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Add Vehicle
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Vehicle Search</CardTitle>
          <CardDescription>Search for vehicles by plate number, type, or status</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="search">Search</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="search" placeholder="Search by name or plate..." className="pl-8" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Vehicle Type</Label>
              <Select>
                <SelectTrigger id="type">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  <SelectItem value="pickup">Pickup Truck</SelectItem>
                  <SelectItem value="suv">SUV</SelectItem>
                  <SelectItem value="truck">Truck</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="status">Status</Label>
              <Select>
                <SelectTrigger id="status">
                  <SelectValue placeholder="All statuses" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All statuses</SelectItem>
                  <SelectItem value="active">Active</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="inactive">Inactive</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="flex items-end">
              <Button className="w-full gap-2">
                <Search className="h-4 w-4" />
                Search
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Vehicle List</CardTitle>
          <CardDescription>Manage your fleet vehicles</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-7 gap-2 p-4 font-medium border-b">
              <div className="col-span-2">Vehicle</div>
              <div>Type</div>
              <div>Status</div>
              <div>Assigned To</div>
              <div>Insurance Expiry</div>
              <div>Actions</div>
            </div>
            {vehicles.map((vehicle) => (
              <div key={vehicle.id} className="grid grid-cols-7 gap-2 p-4 border-b last:border-0">
                <div className="col-span-2">
                  <div className="font-medium">{vehicle.name}</div>
                  <div className="text-sm text-muted-foreground">{vehicle.plate}</div>
                </div>
                <div>{vehicle.type}</div>
                <div>
                  {vehicle.status === "active" ? (
                    <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900 dark:text-green-300">
                      Active
                    </span>
                  ) : vehicle.status === "maintenance" ? (
                    <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
                      Maintenance
                    </span>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 dark:bg-gray-800 dark:text-gray-300">
                      Inactive
                    </span>
                  )}
                </div>
                <div>{vehicle.assignedTo}</div>
                <div>{new Date(vehicle.insuranceExpiry).toLocaleDateString()}</div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Edit</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <FileText className="h-4 w-4" />
                    <span className="sr-only">View Details</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                    <Trash className="h-4 w-4" />
                    <span className="sr-only">Delete</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Add New Vehicle</CardTitle>
          <CardDescription>Add a new vehicle to the fleet</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="vehicle-name">Vehicle Name</Label>
                <Input id="vehicle-name" placeholder="Enter vehicle name" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="plate-number">Plate Number</Label>
                <Input id="plate-number" placeholder="Enter plate number" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="vehicle-type">Vehicle Type</Label>
                <Select>
                  <SelectTrigger id="vehicle-type">
                    <SelectValue placeholder="Select vehicle type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="pickup">Pickup Truck</SelectItem>
                    <SelectItem value="suv">SUV</SelectItem>
                    <SelectItem value="truck">Truck</SelectItem>
                    <SelectItem value="sedan">Sedan</SelectItem>
                    <SelectItem value="van">Van</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="status">Status</Label>
                <Select>
                  <SelectTrigger id="status">
                    <SelectValue placeholder="Select status" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="active">Active</SelectItem>
                    <SelectItem value="maintenance">Maintenance</SelectItem>
                    <SelectItem value="inactive">Inactive</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="odometer">Odometer (km)</Label>
                <Input id="odometer" type="number" placeholder="Enter current odometer reading" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="fuel-consumption">Fuel Consumption (L/100km)</Label>
                <Input id="fuel-consumption" type="number" step="0.1" placeholder="Enter fuel consumption" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="purchase-date">Purchase Date</Label>
                <Input id="purchase-date" type="date" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="insurance-expiry">Insurance Expiry</Label>
                <Input id="insurance-expiry" type="date" />
              </div>
            </div>

            <Button type="submit" className="gap-2">
              <Car className="h-4 w-4" />
              Add Vehicle
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
