import type { ReactNode } from "react"
import { redirect } from "next/navigation"
import { requireAuth } from "@/lib/auth"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"

export default async function AdminLayout({ children }: { children: ReactNode }) {
  const user = await requireAuth()

  if (user.role !== "admin" && user.role !== "finance" && user.role !== "dispatcher") {
    redirect("/")
  }

  return (
    <div className="flex min-h-screen flex-col">
      <AdminSidebar />
      <div className="md:ml-64 flex-1 flex flex-col">
        <AdminHeader user={user} notificationCount={3} />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
