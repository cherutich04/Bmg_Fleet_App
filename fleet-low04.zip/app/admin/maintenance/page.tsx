import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { requireAuth } from "@/lib/auth"
import { Calendar, Edit, FileText, Plus, Search, Trash, Wrench } from "lucide-react"

export default async function AdminMaintenancePage() {
  await requireAuth()

  // Mock data - in a real app, this would come from your database
  const maintenanceRecords = [
    {
      id: 1,
      vehicle: "Toyota Hilux (KBZ 123A)",
      type: "Routine",
      description: "Oil change and filter replacement",
      date: "2023-04-15",
      cost: 3500,
      odometer: 45000,
      performedBy: "Eldoret Main Garage",
    },
    {
      id: 2,
      vehicle: "Isuzu D-Max (KCA 456B)",
      type: "Repair",
      description: "Brake pad replacement",
      date: "2023-04-20",
      cost: 5000,
      odometer: 32000,
      performedBy: "Eldoret Main Garage",
    },
    {
      id: 3,
      vehicle: "Ford Ranger (KDG 789C)",
      type: "Major",
      description: "Engine overhaul",
      date: "2023-05-01",
      cost: 50000,
      odometer: 67500,
      performedBy: "Ford Service Center Eldoret",
    },
    {
      id: 4,
      vehicle: "Toyota Land Cruiser (KBN 234D)",
      type: "Routine",
      description: "Tire rotation and balancing",
      date: "2023-05-05",
      cost: 2000,
      odometer: 23000,
      performedBy: "Eldoret Tire Center",
    },
    {
      id: 5,
      vehicle: "Toyota Hilux (KBZ 123A)",
      type: "Repair",
      description: "Headlight replacement",
      date: "2023-05-10",
      cost: 3000,
      odometer: 45500,
      performedBy: "Eldoret Auto Parts",
    },
  ]

  // Mock vehicles data
  const vehicles = [
    { id: 1, name: "Toyota Hilux", plate: "KBZ 123A" },
    { id: 2, name: "Isuzu D-Max", plate: "KCA 456B" },
    { id: 3, name: "Ford Ranger", plate: "KDG 789C" },
    { id: 4, name: "Toyota Land Cruiser", plate: "KBN 234D" },
    { id: 5, name: "Mitsubishi Fuso", plate: "KCT 567E" },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Maintenance Management</h2>
        <Button className="gap-2">
          <Plus className="h-4 w-4" />
          Add Maintenance Record
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Maintenance Search</CardTitle>
          <CardDescription>Search for maintenance records by vehicle, type, or date</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="vehicle">Vehicle</Label>
              <Select>
                <SelectTrigger id="vehicle">
                  <SelectValue placeholder="All vehicles" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All vehicles</SelectItem>
                  {vehicles.map((vehicle) => (
                    <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                      {vehicle.name} ({vehicle.plate})
                    </SelectItem>
                  ))}
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="type">Maintenance Type</Label>
              <Select>
                <SelectTrigger id="type">
                  <SelectValue placeholder="All types" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All types</SelectItem>
                  <SelectItem value="routine">Routine</SelectItem>
                  <SelectItem value="repair">Repair</SelectItem>
                  <SelectItem value="major">Major</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date-from">From Date</Label>
              <div className="relative">
                <Input id="date-from" type="date" />
                <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
            </div>

            <div className="flex items-end">
              <Button className="w-full gap-2">
                <Search className="h-4 w-4" />
                Search
              </Button>
            </div>
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Maintenance Records</CardTitle>
          <CardDescription>View and manage maintenance records</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-7 gap-2 p-4 font-medium border-b">
              <div className="col-span-2">Vehicle</div>
              <div>Type</div>
              <div>Date</div>
              <div>Cost (KES)</div>
              <div>Performed By</div>
              <div>Actions</div>
            </div>
            {maintenanceRecords.map((record) => (
              <div key={record.id} className="grid grid-cols-7 gap-2 p-4 border-b last:border-0">
                <div className="col-span-2">
                  <div className="font-medium">{record.vehicle}</div>
                  <div className="text-sm text-muted-foreground">Odometer: {record.odometer} km</div>
                </div>
                <div>
                  {record.type === "Routine" ? (
                    <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900 dark:text-green-300">
                      Routine
                    </span>
                  ) : record.type === "Repair" ? (
                    <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
                      Repair
                    </span>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800 dark:bg-red-900 dark:text-red-300">
                      Major
                    </span>
                  )}
                </div>
                <div>{record.date}</div>
                <div>{record.cost.toLocaleString()}</div>
                <div>{record.performedBy}</div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Edit</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <FileText className="h-4 w-4" />
                    <span className="sr-only">View Details</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                    <Trash className="h-4 w-4" />
                    <span className="sr-only">Delete</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Add Maintenance Record</CardTitle>
          <CardDescription>Record a new maintenance activity</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="maintenance-vehicle">Vehicle</Label>
                <Select>
                  <SelectTrigger id="maintenance-vehicle">
                    <SelectValue placeholder="Select vehicle" />
                  </SelectTrigger>
                  <SelectContent>
                    {vehicles.map((vehicle) => (
                      <SelectItem key={vehicle.id} value={vehicle.id.toString()}>
                        {vehicle.name} ({vehicle.plate})
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-type">Maintenance Type</Label>
                <Select>
                  <SelectTrigger id="maintenance-type">
                    <SelectValue placeholder="Select type" />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="routine">Routine</SelectItem>
                    <SelectItem value="repair">Repair</SelectItem>
                    <SelectItem value="major">Major</SelectItem>
                  </SelectContent>
                </Select>
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-date">Date</Label>
                <div className="relative">
                  <Input id="maintenance-date" type="date" />
                  <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                </div>
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-cost">Cost (KES)</Label>
                <Input id="maintenance-cost" type="number" placeholder="Enter cost" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-odometer">Odometer (km)</Label>
                <Input id="maintenance-odometer" type="number" placeholder="Enter current odometer reading" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="maintenance-performed-by">Performed By</Label>
                <Input id="maintenance-performed-by" placeholder="Enter service provider" />
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="maintenance-description">Description</Label>
                <Textarea id="maintenance-description" placeholder="Enter maintenance details" />
              </div>
            </div>

            <Button type="submit" className="gap-2">
              <Wrench className="h-4 w-4" />
              Add Maintenance Record
            </Button>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
