import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { requireAuth } from "@/lib/auth"
import { Edit, FileText, Plus, Trash } from "lucide-react"

export default async function AdminProjectsPage() {
  await requireAuth()

  // Mock data - in a real app, this would come from your database
  const projects = [
    {
      id: "1",
      name: "Nairobi Deliveries",
      description: "Regular deliveries within Nairobi CBD and surrounding areas",
      createdAt: "2023-01-15",
      status: "active",
    },
    {
      id: "2",
      name: "Mombasa Route",
      description: "Long-distance deliveries between Nairobi and Mombasa",
      createdAt: "2023-02-20",
      status: "active",
    },
    {
      id: "3",
      name: "Construction Site Transport",
      description: "Transportation of materials to construction sites",
      createdAt: "2023-03-10",
      status: "inactive",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Projects</h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Add New Project</CardTitle>
          <CardDescription>Create a new project for the fleet management system</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="grid gap-4 md:grid-cols-2">
              <div className="space-y-2">
                <Label htmlFor="project-name">Project Name</Label>
                <Input id="project-name" placeholder="Enter project name" />
              </div>

              <div className="space-y-2">
                <Label htmlFor="project-status">Status</Label>
                <div className="flex items-center space-x-2">
                  <Input id="project-status" type="checkbox" className="h-4 w-4" />
                  <Label htmlFor="project-status" className="text-sm font-normal">
                    Active
                  </Label>
                </div>
              </div>

              <div className="space-y-2 md:col-span-2">
                <Label htmlFor="project-description">Description</Label>
                <Textarea id="project-description" placeholder="Enter project description" />
              </div>
            </div>

            <Button type="submit" className="gap-2">
              <Plus className="h-4 w-4" />
              Add Project
            </Button>
          </form>
        </CardContent>
      </Card>

      <Card>
        <CardHeader>
          <CardTitle>Project List</CardTitle>
          <CardDescription>Manage existing projects</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-5 gap-2 p-4 font-medium border-b">
              <div className="col-span-2">Name</div>
              <div>Created</div>
              <div>Status</div>
              <div>Actions</div>
            </div>
            {projects.map((project) => (
              <div key={project.id} className="grid grid-cols-5 gap-2 p-4 border-b last:border-0">
                <div className="col-span-2 font-medium">{project.name}</div>
                <div>{project.createdAt}</div>
                <div>
                  {project.status === "active" ? (
                    <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900 dark:text-green-300">
                      Active
                    </span>
                  ) : (
                    <span className="inline-flex items-center rounded-full bg-gray-100 px-2.5 py-0.5 text-xs font-medium text-gray-800 dark:bg-gray-800 dark:text-gray-300">
                      Inactive
                    </span>
                  )}
                </div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Edit</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <FileText className="h-4 w-4" />
                    <span className="sr-only">View Details</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                    <Trash className="h-4 w-4" />
                    <span className="sr-only">Delete</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
