import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { requireAuth } from "@/lib/auth"
import { BarChart3, Calendar, Download, FileText, PieChart, Settings, TrendingUp, User } from "lucide-react"

export default async function AdminReportsPage() {
  await requireAuth()

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Reports</h2>
      </div>

      <Tabs defaultValue="pre-built" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="pre-built" className="gap-2">
            <FileText className="h-4 w-4" />
            Pre-built Reports
          </TabsTrigger>
          <TabsTrigger value="custom" className="gap-2">
            <Settings className="h-4 w-4" />
            Custom Reports
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pre-built" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Available Reports</CardTitle>
              <CardDescription>Select a report to generate</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="grid gap-4 md:grid-cols-2 lg:grid-cols-3">
                <Card className="border-2 hover:border-primary cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Driver Performance</CardTitle>
                    <CardDescription>Performance metrics for all drivers</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between">
                      <User className="h-8 w-8 text-muted-foreground" />
                      <Button size="sm" className="gap-1">
                        <Download className="h-3 w-3" />
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-primary cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Expense Summary</CardTitle>
                    <CardDescription>Summary of all expenses by category</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between">
                      <PieChart className="h-8 w-8 text-muted-foreground" />
                      <Button size="sm" className="gap-1">
                        <Download className="h-3 w-3" />
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-primary cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Fuel Consumption</CardTitle>
                    <CardDescription>Fuel usage and efficiency analysis</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between">
                      <BarChart3 className="h-8 w-8 text-muted-foreground" />
                      <Button size="sm" className="gap-1">
                        <Download className="h-3 w-3" />
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-primary cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Vehicle Utilization</CardTitle>
                    <CardDescription>Usage statistics for all vehicles</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between">
                      <TrendingUp className="h-8 w-8 text-muted-foreground" />
                      <Button size="sm" className="gap-1">
                        <Download className="h-3 w-3" />
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-primary cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Maintenance History</CardTitle>
                    <CardDescription>Maintenance records and costs</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between">
                      <FileText className="h-8 w-8 text-muted-foreground" />
                      <Button size="sm" className="gap-1">
                        <Download className="h-3 w-3" />
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>

                <Card className="border-2 hover:border-primary cursor-pointer transition-colors">
                  <CardHeader className="pb-2">
                    <CardTitle className="text-lg">Project Profitability</CardTitle>
                    <CardDescription>Revenue and costs by project</CardDescription>
                  </CardHeader>
                  <CardContent className="pb-2">
                    <div className="flex items-center justify-between">
                      <BarChart3 className="h-8 w-8 text-muted-foreground" />
                      <Button size="sm" className="gap-1">
                        <Download className="h-3 w-3" />
                        Generate
                      </Button>
                    </div>
                  </CardContent>
                </Card>
              </div>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Report Settings</CardTitle>
              <CardDescription>Configure report parameters</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="space-y-2">
                    <Label htmlFor="date-from">From Date</Label>
                    <div className="relative">
                      <Input id="date-from" type="date" />
                      <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date-to">To Date</Label>
                    <div className="relative">
                      <Input id="date-to" type="date" />
                      <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="format">Format</Label>
                    <Select>
                      <SelectTrigger id="format">
                        <SelectValue placeholder="Select format" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="pdf">PDF</SelectItem>
                        <SelectItem value="csv">CSV</SelectItem>
                        <SelectItem value="excel">Excel</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>
                </div>

                <Button type="submit" className="gap-2">
                  <Download className="h-4 w-4" />
                  Generate Report
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="custom" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Custom Report Builder</CardTitle>
              <CardDescription>Create a custom report with selected fields</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="space-y-2">
                  <Label htmlFor="report-name">Report Name</Label>
                  <Input id="report-name" placeholder="Enter report name" />
                </div>

                <div className="space-y-2">
                  <Label>Data Sources</Label>
                  <div className="grid gap-2 md:grid-cols-3">
                    <div className="flex items-center space-x-2">
                      <Input id="drivers" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="drivers" className="text-sm font-normal">
                        Drivers
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="vehicles" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="vehicles" className="text-sm font-normal">
                        Vehicles
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="expenses" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="expenses" className="text-sm font-normal">
                        Expenses
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="maintenance" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="maintenance" className="text-sm font-normal">
                        Maintenance
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="projects" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="projects" className="text-sm font-normal">
                        Projects
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="targets" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="targets" className="text-sm font-normal">
                        Targets
                      </Label>
                    </div>
                  </div>
                </div>

                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="date-from">From Date</Label>
                    <div className="relative">
                      <Input id="date-from" type="date" />
                      <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date-to">To Date</Label>
                    <div className="relative">
                      <Input id="date-to" type="date" />
                      <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label>Visualization</Label>
                  <div className="grid gap-2 md:grid-cols-3">
                    <div className="flex items-center space-x-2">
                      <Input id="table" type="checkbox" className="h-4 w-4" checked disabled />
                      <Label htmlFor="table" className="text-sm font-normal">
                        Table
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="bar-chart" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="bar-chart" className="text-sm font-normal">
                        Bar Chart
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="pie-chart" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="pie-chart" className="text-sm font-normal">
                        Pie Chart
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="line-chart" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="line-chart" className="text-sm font-normal">
                        Line Chart
                      </Label>
                    </div>
                    <div className="flex items-center space-x-2">
                      <Input id="summary" type="checkbox" className="h-4 w-4" />
                      <Label htmlFor="summary" className="text-sm font-normal">
                        Summary Stats
                      </Label>
                    </div>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="format">Output Format</Label>
                  <Select>
                    <SelectTrigger id="format">
                      <SelectValue placeholder="Select format" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="pdf">PDF</SelectItem>
                      <SelectItem value="csv">CSV</SelectItem>
                      <SelectItem value="excel">Excel</SelectItem>
                    </SelectContent>
                  </Select>
                </div>

                <Button type="submit" className="gap-2">
                  <FileText className="h-4 w-4" />
                  Create Custom Report
                </Button>
              </form>
            </CardContent>
          </Card>

          <Card>
            <CardHeader>
              <CardTitle>Saved Custom Reports</CardTitle>
              <CardDescription>Your previously created custom reports</CardDescription>
            </CardHeader>
            <CardContent>
              <div className="rounded-md border">
                <div className="grid grid-cols-4 gap-2 p-4 font-medium border-b">
                  <div className="col-span-2">Report Name</div>
                  <div>Created</div>
                  <div>Actions</div>
                </div>
                <div className="p-4 text-center text-muted-foreground">No saved custom reports found.</div>
              </div>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Graphical Analytics</CardTitle>
          <CardDescription>Visual representation of fleet data</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="grid gap-6 md:grid-cols-2">
            <div className="aspect-[4/3] bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Expense by Category (Pie Chart)</p>
            </div>
            <div className="aspect-[4/3] bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Monthly Expenses (Bar Chart)</p>
            </div>
            <div className="aspect-[4/3] bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Driver Performance (Bar Chart)</p>
            </div>
            <div className="aspect-[4/3] bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Fuel Consumption Trend (Line Chart)</p>
            </div>
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
