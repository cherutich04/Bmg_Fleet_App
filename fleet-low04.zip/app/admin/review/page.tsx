import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { requireAuth } from "@/lib/auth"
import { CheckCircle, Clock, Download, FileText, Filter, Search, ThumbsDown, ThumbsUp, User } from "lucide-react"

export default async function AdminReviewPage() {
  await requireAuth()

  // Mock data - in a real app, this would come from your database
  const expenses = [
    {
      id: "1",
      driver: "John Driver",
      name: "Fuel",
      date: "2023-05-14",
      amount: 5000,
      category: "Fuel",
      paymentMethod: "M-Pesa",
      status: "pending",
      receipt: true,
    },
    {
      id: "2",
      driver: "Jane Smith",
      name: "Tire repair",
      date: "2023-05-12",
      amount: 1500,
      category: "Maintenance",
      paymentMethod: "Cash",
      status: "pending",
      receipt: false,
    },
    {
      id: "3",
      driver: "Michael Johnson",
      name: "Lunch",
      date: "2023-05-14",
      amount: 500,
      category: "Meals",
      paymentMethod: "Cash",
      status: "approved",
      receipt: true,
    },
    {
      id: "4",
      driver: "John Driver",
      name: "Parking",
      date: "2023-05-10",
      amount: 200,
      category: "Toll/Parking",
      paymentMethod: "Cash",
      status: "rejected",
      receipt: false,
      rejectionReason: "No receipt provided",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Expense Review</h2>
        <Button variant="outline" className="gap-2">
          <Download className="h-4 w-4" />
          Export Report
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter expenses by driver, date, and status</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="driver">Driver</Label>
              <div className="relative">
                <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
                <Input id="driver" placeholder="Search driver" className="pl-8" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date-from">From Date</Label>
              <Input id="date-from" type="date" />
            </div>

            <div className="space-y-2">
              <Label htmlFor="date-to">To Date</Label>
              <Input id="date-to" type="date" />
            </div>

            <div className="flex items-end">
              <Button type="submit" className="gap-2 w-full">
                <Filter className="h-4 w-4" />
                Apply Filters
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>

      <Tabs defaultValue="pending" className="space-y-6">
        <TabsList className="grid w-full grid-cols-3">
          <TabsTrigger value="pending" className="gap-2">
            <Clock className="h-4 w-4" />
            Pending
          </TabsTrigger>
          <TabsTrigger value="approved" className="gap-2">
            <ThumbsUp className="h-4 w-4" />
            Approved
          </TabsTrigger>
          <TabsTrigger value="rejected" className="gap-2">
            <ThumbsDown className="h-4 w-4" />
            Rejected
          </TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="space-y-6">
          {expenses
            .filter((e) => e.status === "pending")
            .map((expense) => (
              <Card key={expense.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{expense.driver}</span>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-yellow-100 px-2.5 py-0.5 text-xs font-medium text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
                      Pending
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <h3 className="text-lg font-medium">{expense.name}</h3>
                      <p className="text-sm text-muted-foreground">{expense.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">KES {expense.amount.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">
                        {expense.category} - {expense.paymentMethod}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{expense.receipt ? "Receipt attached" : "No receipt attached"}</span>
                  </div>
                </CardContent>
                <div className="border-t p-4 flex items-center justify-between">
                  <Button variant="outline" className="gap-2">
                    <FileText className="h-4 w-4" />
                    View Details
                  </Button>
                  <div className="flex items-center gap-2">
                    <Button
                      variant="outline"
                      className="gap-2 text-red-600 border-red-200 hover:bg-red-50 hover:text-red-700"
                    >
                      <ThumbsDown className="h-4 w-4" />
                      Reject
                    </Button>
                    <Button className="gap-2 bg-green-600 hover:bg-green-700">
                      <CheckCircle className="h-4 w-4" />
                      Approve
                    </Button>
                  </div>
                </div>
              </Card>
            ))}

          {expenses.filter((e) => e.status === "pending").length === 0 && (
            <div className="rounded-md border border-dashed p-8 text-center">
              <Clock className="mx-auto h-8 w-8 text-muted-foreground" />
              <h3 className="mt-2 text-lg font-medium">No Pending Expenses</h3>
              <p className="mt-1 text-sm text-muted-foreground">There are no expenses waiting for review.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="approved" className="space-y-6">
          {expenses
            .filter((e) => e.status === "approved")
            .map((expense) => (
              <Card key={expense.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{expense.driver}</span>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900 dark:text-green-300">
                      Approved
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <h3 className="text-lg font-medium">{expense.name}</h3>
                      <p className="text-sm text-muted-foreground">{expense.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">KES {expense.amount.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">
                        {expense.category} - {expense.paymentMethod}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4 flex items-center gap-2">
                    <FileText className="h-4 w-4 text-muted-foreground" />
                    <span className="text-sm">{expense.receipt ? "Receipt attached" : "No receipt attached"}</span>
                  </div>
                </CardContent>
                <div className="border-t p-4">
                  <Button variant="outline" className="gap-2">
                    <FileText className="h-4 w-4" />
                    View Details
                  </Button>
                </div>
              </Card>
            ))}

          {expenses.filter((e) => e.status === "approved").length === 0 && (
            <div className="rounded-md border border-dashed p-8 text-center">
              <ThumbsUp className="mx-auto h-8 w-8 text-muted-foreground" />
              <h3 className="mt-2 text-lg font-medium">No Approved Expenses</h3>
              <p className="mt-1 text-sm text-muted-foreground">There are no approved expenses yet.</p>
            </div>
          )}
        </TabsContent>

        <TabsContent value="rejected" className="space-y-6">
          {expenses
            .filter((e) => e.status === "rejected")
            .map((expense) => (
              <Card key={expense.id}>
                <CardHeader className="pb-2">
                  <div className="flex items-center justify-between">
                    <div className="flex items-center gap-2">
                      <User className="h-4 w-4 text-muted-foreground" />
                      <span className="font-medium">{expense.driver}</span>
                    </div>
                    <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800 dark:bg-red-900 dark:text-red-300">
                      Rejected
                    </span>
                  </div>
                </CardHeader>
                <CardContent className="pb-2">
                  <div className="grid gap-4 md:grid-cols-2">
                    <div>
                      <h3 className="text-lg font-medium">{expense.name}</h3>
                      <p className="text-sm text-muted-foreground">{expense.date}</p>
                    </div>
                    <div className="text-right">
                      <p className="text-lg font-bold">KES {expense.amount.toLocaleString()}</p>
                      <p className="text-sm text-muted-foreground">
                        {expense.category} - {expense.paymentMethod}
                      </p>
                    </div>
                  </div>
                  <div className="mt-4">
                    <p className="text-sm font-medium">Rejection Reason:</p>
                    <p className="text-sm text-muted-foreground">{expense.rejectionReason}</p>
                  </div>
                </CardContent>
                <div className="border-t p-4">
                  <Button variant="outline" className="gap-2">
                    <FileText className="h-4 w-4" />
                    View Details
                  </Button>
                </div>
              </Card>
            ))}

          {expenses.filter((e) => e.status === "rejected").length === 0 && (
            <div className="rounded-md border border-dashed p-8 text-center">
              <ThumbsDown className="mx-auto h-8 w-8 text-muted-foreground" />
              <h3 className="mt-2 text-lg font-medium">No Rejected Expenses</h3>
              <p className="mt-1 text-sm text-muted-foreground">There are no rejected expenses.</p>
            </div>
          )}
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader>
          <CardTitle>Reject Expense</CardTitle>
          <CardDescription>Provide a reason for rejecting an expense</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="space-y-6">
            <div className="space-y-2">
              <Label htmlFor="rejection-reason">Rejection Reason</Label>
              <Textarea id="rejection-reason" placeholder="Enter reason for rejection" />
            </div>

            <div className="flex items-center gap-2">
              <Button type="button" variant="outline">
                Cancel
              </Button>
              <Button type="submit" className="gap-2 bg-red-600 hover:bg-red-700">
                <ThumbsDown className="h-4 w-4" />
                Confirm Rejection
              </Button>
            </div>
          </form>
        </CardContent>
      </Card>
    </div>
  )
}
