import { NextResponse } from "next/server"
import { initializeDatabase } from "@/lib/db"

export async function GET() {
  try {
    await initializeDatabase()
    return NextResponse.json({ success: true, message: "Database initialized successfully" })
  } catch (error) {
    console.error("Error initializing database:", error)
    // Ensure we return a proper JSON response even when there's an error
    return NextResponse.json(
      {
        success: false,
        error: error instanceof Error ? error.message : "Unknown database initialization error",
      },
      { status: 500 },
    )
  }
}
