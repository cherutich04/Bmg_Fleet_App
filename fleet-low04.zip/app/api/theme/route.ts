import { cookies } from "next/headers"
import { type NextRequest, NextResponse } from "next/server"

export async function POST(request: NextRequest) {
  const { theme } = await request.json()

  // Validate theme value
  if (!["light", "dark", "system"].includes(theme)) {
    return NextResponse.json({ error: "Invalid theme" }, { status: 400 })
  }

  // Set cookie
  cookies().set("theme", theme, {
    httpOnly: true,
    path: "/",
    maxAge: 60 * 60 * 24 * 365, // 1 year
    sameSite: "lax",
  })

  return NextResponse.json({ success: true })
}

export async function GET() {
  const theme = cookies().get("theme")?.value || "system"
  return NextResponse.json({ theme })
}
