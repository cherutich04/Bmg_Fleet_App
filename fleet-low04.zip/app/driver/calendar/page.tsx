import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { requireAuth } from "@/lib/auth"
import { Calendar, Clock, MapPin } from "lucide-react"

export default async function DriverCalendarPage() {
  await requireAuth("driver")

  // Mock data - in a real app, this would come from your database
  const events = [
    {
      id: 1,
      title: "Delivery to Nairobi CBD",
      date: "2023-05-15",
      time: "08:00 - 16:00",
      location: "Nairobi CBD",
      type: "delivery",
    },
    {
      id: 2,
      title: "Vehicle Maintenance",
      date: "2023-05-18",
      time: "10:00 - 12:00",
      location: "Eldoret Main Garage",
      type: "maintenance",
    },
    {
      id: 3,
      title: "Delivery to Nakuru",
      date: "2023-05-20",
      time: "07:00 - 15:00",
      location: "Nakuru Town",
      type: "delivery",
    },
    {
      id: 4,
      title: "Team Meeting",
      date: "2023-05-22",
      time: "14:00 - 15:00",
      location: "Eldoret Office",
      type: "meeting",
    },
    {
      id: 5,
      title: "Delivery to Kisumu",
      date: "2023-05-25",
      time: "06:00 - 18:00",
      location: "Kisumu City",
      type: "delivery",
    },
  ]

  // Group events by date
  const eventsByDate = events.reduce(
    (acc, event) => {
      const date = event.date
      if (!acc[date]) {
        acc[date] = []
      }
      acc[date].push(event)
      return acc
    },
    {} as Record<string, typeof events>,
  )

  // Sort dates
  const sortedDates = Object.keys(eventsByDate).sort()

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Calendar</h2>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Schedule</CardTitle>
          <CardDescription>Your upcoming deliveries and events</CardDescription>
        </CardHeader>
        <CardContent>
          <div className="space-y-8">
            {sortedDates.map((date) => (
              <div key={date} className="space-y-4">
                <div className="flex items-center gap-2">
                  <Calendar className="h-5 w-5 text-primary" />
                  <h3 className="text-lg font-medium">
                    {new Date(date).toLocaleDateString("en-US", {
                      weekday: "long",
                      year: "numeric",
                      month: "long",
                      day: "numeric",
                    })}
                  </h3>
                </div>

                <div className="space-y-4">
                  {eventsByDate[date].map((event) => {
                    let bgColor = "bg-blue-50 dark:bg-blue-950"
                    let borderColor = "border-blue-200 dark:border-blue-800"

                    if (event.type === "maintenance") {
                      bgColor = "bg-yellow-50 dark:bg-yellow-950"
                      borderColor = "border-yellow-200 dark:border-yellow-800"
                    } else if (event.type === "meeting") {
                      bgColor = "bg-purple-50 dark:bg-purple-950"
                      borderColor = "border-purple-200 dark:border-purple-800"
                    }

                    return (
                      <div key={event.id} className={`rounded-md border p-4 ${bgColor} ${borderColor}`}>
                        <h4 className="font-medium">{event.title}</h4>
                        <div className="mt-2 flex flex-col gap-2 text-sm">
                          <div className="flex items-center gap-2">
                            <Clock className="h-4 w-4 text-muted-foreground" />
                            <span>{event.time}</span>
                          </div>
                          <div className="flex items-center gap-2">
                            <MapPin className="h-4 w-4 text-muted-foreground" />
                            <span>{event.location}</span>
                          </div>
                        </div>
                      </div>
                    )
                  })}
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
