import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Progress } from "@/components/ui/progress"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { Button } from "@/components/ui/button"
import { requireAuth } from "@/lib/auth"
import {
  AlertCircle,
  AlertTriangle,
  CheckCircle2,
  Clock,
  Fuel,
  Info,
  GaugeIcon as Speedometer,
  Target,
} from "lucide-react"

export default async function DriverDashboardPage() {
  const user = await requireAuth("driver")

  // Mock data - in a real app, this would come from your database
  const vehicleData = {
    model: "Toyota Hilux",
    plate: "KBZ 123A",
    type: "Pickup Truck",
    status: "Active",
    assignedDates: {
      start: "2023-01-01",
      end: "2023-12-31",
    },
    odometer: 45678,
    fuelConsumption: "12.5 L/100km",
  }

  const targetData = {
    progress: 68,
    amountRealized: 680000,
    targetAmount: 1000000,
    tripsCompleted: 24,
    safetyScore: 92,
  }

  const notifications = [
    {
      type: "maintenance",
      severity: "warning",
      message: "Oil change due in 500km",
      date: "2023-05-15T10:30:00",
    },
    {
      type: "activity",
      severity: "info",
      message: "Monthly target updated by admin",
      date: "2023-05-14T14:45:00",
    },
    {
      type: "maintenance",
      severity: "critical",
      message: "Brake inspection required",
      date: "2023-05-13T09:15:00",
    },
    {
      type: "activity",
      severity: "success",
      message: "Expense report approved",
      date: "2023-05-12T16:20:00",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Dashboard</h2>
        <div className="flex items-center gap-2">
          <p className="text-sm text-muted-foreground">
            Welcome back, <span className="font-medium text-foreground">{user.name}</span>
          </p>
        </div>
      </div>

      <div className="grid gap-6 md:grid-cols-2 lg:grid-cols-3">
        {/* STATUS CARD */}
        <Card className="col-span-1 md:col-span-2 lg:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">STATUS</CardTitle>
            <CardDescription>Vehicle information and performance</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <Tabs defaultValue="basics">
              <TabsList className="grid w-full grid-cols-2">
                <TabsTrigger value="basics">Vehicle Basics</TabsTrigger>
                <TabsTrigger value="performance">Performance</TabsTrigger>
              </TabsList>
              <TabsContent value="basics" className="space-y-4 pt-3">
                <div className="grid grid-cols-2 gap-4">
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Assigned Dates</p>
                    <p className="text-sm">
                      {new Date(vehicleData.assignedDates.start).toLocaleDateString()} -{" "}
                      {new Date(vehicleData.assignedDates.end).toLocaleDateString()}
                    </p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Model</p>
                    <p className="text-sm">{vehicleData.model}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Plate Number</p>
                    <p className="text-sm">{vehicleData.plate}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Type</p>
                    <p className="text-sm">{vehicleData.type}</p>
                  </div>
                  <div>
                    <p className="text-sm font-medium text-muted-foreground">Status</p>
                    <div className="flex items-center gap-1">
                      <span className="h-2 w-2 rounded-full bg-green-500"></span>
                      <p className="text-sm">{vehicleData.status}</p>
                    </div>
                  </div>
                </div>
              </TabsContent>
              <TabsContent value="performance" className="space-y-4 pt-3">
                <div className="space-y-4">
                  <div>
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-2">
                        <Speedometer className="h-4 w-4 text-muted-foreground" />
                        <p className="text-sm font-medium">Odometer</p>
                      </div>
                      <Button variant="outline" size="sm" className="h-7 text-xs">
                        Update
                      </Button>
                    </div>
                    <p className="text-2xl font-bold mt-1">{vehicleData.odometer.toLocaleString()} km</p>
                  </div>

                  <div>
                    <div className="flex items-center gap-2">
                      <Fuel className="h-4 w-4 text-muted-foreground" />
                      <p className="text-sm font-medium">Fuel Consumption</p>
                    </div>
                    <p className="text-2xl font-bold mt-1">{vehicleData.fuelConsumption}</p>
                  </div>
                </div>
              </TabsContent>
            </Tabs>
          </CardContent>
        </Card>

        {/* MONTHLY TARGET CARD */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">MONTHLY TARGET</CardTitle>
            <CardDescription>Your progress towards monthly goals</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Target Progress</p>
                <p className="text-sm font-medium">{targetData.progress}%</p>
              </div>
              <Progress value={targetData.progress} className="h-2" />
            </div>

            <div className="grid grid-cols-2 gap-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Amount Realized</p>
                <p className="text-lg font-bold">KES {targetData.amountRealized.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Set Target</p>
                <p className="text-lg font-bold">KES {targetData.targetAmount.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Trips Completed</p>
                <div className="flex items-center gap-1">
                  <Clock className="h-4 w-4 text-muted-foreground" />
                  <p className="text-lg font-bold">{targetData.tripsCompleted}</p>
                </div>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Safety Score</p>
                <div className="flex items-center gap-1">
                  <Target className="h-4 w-4 text-muted-foreground" />
                  <p className="text-lg font-bold">{targetData.safetyScore}%</p>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>

        {/* NOTIFICATIONS CARD */}
        <Card>
          <CardHeader className="pb-2">
            <CardTitle className="text-xl">NOTIFICATIONS AND ALERTS</CardTitle>
            <CardDescription>Recent activities and maintenance alerts</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            {notifications.map((notification, index) => {
              let Icon = Info
              let alertVariant = "default"

              if (notification.severity === "critical") {
                Icon = AlertCircle
                alertVariant = "destructive"
              } else if (notification.severity === "warning") {
                Icon = AlertTriangle
                alertVariant = "warning"
              } else if (notification.severity === "success") {
                Icon = CheckCircle2
                alertVariant = "success"
              }

              return (
                <Alert key={index} variant={alertVariant as any}>
                  <Icon className="h-4 w-4" />
                  <AlertTitle className="text-sm font-medium">
                    {notification.type === "maintenance" ? "Maintenance Alert" : "Activity Update"}
                  </AlertTitle>
                  <AlertDescription className="text-xs">
                    {notification.message}
                    <div className="mt-1 text-xs text-muted-foreground">
                      {new Date(notification.date).toLocaleString()}
                    </div>
                  </AlertDescription>
                </Alert>
              )
            })}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
