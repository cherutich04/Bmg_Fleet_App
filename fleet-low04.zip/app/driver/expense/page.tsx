import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Textarea } from "@/components/ui/textarea"
import { requireAuth } from "@/lib/auth"
import { ArrowDown, ArrowUp, Calendar, Download, Edit, FileText, Plus, Trash, Upload } from "lucide-react"

export default async function DriverExpensePage() {
  await requireAuth("driver")

  // Mock data - in a real app, this would come from your database
  const transactions = [
    {
      id: 1,
      type: "income",
      name: "Delivery to Nairobi CBD",
      date: "2023-05-15",
      amount: 15000,
      category: "Delivery",
      paymentMethod: "Cash",
      paidBy: "Client A",
      paidTo: "Company",
      notes: "Delivered on time",
    },
    {
      id: 2,
      type: "expense",
      name: "Fuel",
      date: "2023-05-14",
      amount: 5000,
      category: "Fuel",
      paymentMethod: "M-Pesa",
      paidBy: "Driver",
      notes: "Full tank refill",
    },
    {
      id: 3,
      type: "expense",
      name: "Lunch",
      date: "2023-05-14",
      amount: 500,
      category: "Meals",
      paymentMethod: "Cash",
      paidBy: "Driver",
      notes: "",
    },
    {
      id: 4,
      type: "income",
      name: "Delivery to Mombasa",
      date: "2023-05-13",
      amount: 25000,
      category: "Delivery",
      paymentMethod: "Bank Transfer",
      paidBy: "Client B",
      paidTo: "Company",
      notes: "Long distance delivery",
    },
  ]

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Expense Management</h2>
      </div>

      <Tabs defaultValue="money-in" className="space-y-6">
        <TabsList className="grid w-full grid-cols-2">
          <TabsTrigger value="money-in" className="gap-2">
            <ArrowDown className="h-4 w-4 text-green-500" />
            Money In
          </TabsTrigger>
          <TabsTrigger value="money-out" className="gap-2">
            <ArrowUp className="h-4 w-4 text-red-500" />
            Money Out
          </TabsTrigger>
        </TabsList>

        <TabsContent value="money-in" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Record Income</CardTitle>
              <CardDescription>Log delivery income and other payments received</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="hire-type">Hire Type</Label>
                    <Select>
                      <SelectTrigger id="hire-type">
                        <SelectValue placeholder="Select hire type" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="delivery">Delivery</SelectItem>
                        <SelectItem value="rental">Rental</SelectItem>
                        <SelectItem value="service">Service</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="project">Project</Label>
                    <Select>
                      <SelectTrigger id="project">
                        <SelectValue placeholder="Select project" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="project-a">Project A</SelectItem>
                        <SelectItem value="project-b">Project B</SelectItem>
                        <SelectItem value="project-c">Project C</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="delivery-name">Delivery Name</Label>
                    <Input id="delivery-name" placeholder="Enter delivery name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <div className="relative">
                      <Input id="date" type="date" />
                      <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (KES)</Label>
                    <Input id="amount" type="number" placeholder="0.00" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="payment-method">Payment Method</Label>
                    <Select>
                      <SelectTrigger id="payment-method">
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="m-pesa">M-Pesa</SelectItem>
                        <SelectItem value="bank-transfer">Bank Transfer</SelectItem>
                        <SelectItem value="cheque">Cheque</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paid-by">Paid By</Label>
                    <Input id="paid-by" placeholder="Enter client/customer name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paid-to">Paid To</Label>
                    <Input id="paid-to" placeholder="Enter recipient" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="receipt">Receipt Upload</Label>
                  <div className="flex items-center gap-2">
                    <Button type="button" variant="outline" className="w-full gap-2">
                      <Upload className="h-4 w-4" />
                      Upload Receipt
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea id="notes" placeholder="Enter any additional notes" />
                </div>

                <Button type="submit" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Income
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>

        <TabsContent value="money-out" className="space-y-6">
          <Card>
            <CardHeader>
              <CardTitle>Record Expense</CardTitle>
              <CardDescription>Log expenses and payments made</CardDescription>
            </CardHeader>
            <CardContent>
              <form className="space-y-6">
                <div className="grid gap-4 md:grid-cols-2">
                  <div className="space-y-2">
                    <Label htmlFor="expense-name">Expense Name</Label>
                    <Input id="expense-name" placeholder="Enter expense name" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="date">Date</Label>
                    <div className="relative">
                      <Input id="date" type="date" />
                      <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
                    </div>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="amount">Amount (KES)</Label>
                    <Input id="amount" type="number" placeholder="0.00" />
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="category">Category</Label>
                    <Select>
                      <SelectTrigger id="category">
                        <SelectValue placeholder="Select category" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="fuel">Fuel</SelectItem>
                        <SelectItem value="maintenance">Maintenance</SelectItem>
                        <SelectItem value="meals">Meals</SelectItem>
                        <SelectItem value="accommodation">Accommodation</SelectItem>
                        <SelectItem value="toll">Toll/Parking</SelectItem>
                        <SelectItem value="other">Other</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="payment-method">Payment Method</Label>
                    <Select>
                      <SelectTrigger id="payment-method">
                        <SelectValue placeholder="Select payment method" />
                      </SelectTrigger>
                      <SelectContent>
                        <SelectItem value="cash">Cash</SelectItem>
                        <SelectItem value="m-pesa">M-Pesa</SelectItem>
                        <SelectItem value="card">Card</SelectItem>
                      </SelectContent>
                    </Select>
                  </div>

                  <div className="space-y-2">
                    <Label htmlFor="paid-by">Paid By</Label>
                    <Input id="paid-by" placeholder="Enter who paid" />
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="receipt">Receipt Upload</Label>
                  <div className="flex items-center gap-2">
                    <Button type="button" variant="outline" className="w-full gap-2">
                      <Upload className="h-4 w-4" />
                      Upload Receipt
                    </Button>
                  </div>
                </div>

                <div className="space-y-2">
                  <Label htmlFor="notes">Notes</Label>
                  <Textarea id="notes" placeholder="Enter any additional notes" />
                </div>

                <Button type="submit" className="gap-2">
                  <Plus className="h-4 w-4" />
                  Add Expense
                </Button>
              </form>
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>

      <Card>
        <CardHeader className="flex flex-row items-center justify-between">
          <div>
            <CardTitle>Income & Expense Summary</CardTitle>
            <CardDescription>Recent transactions</CardDescription>
          </div>
          <Button variant="outline" size="sm" className="gap-2">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </CardHeader>
        <CardContent>
          <div className="rounded-md border">
            <div className="grid grid-cols-7 gap-2 p-4 font-medium border-b">
              <div>Type</div>
              <div className="col-span-2">Name</div>
              <div>Date</div>
              <div>Amount</div>
              <div>Category</div>
              <div>Actions</div>
            </div>
            {transactions.map((transaction) => (
              <div key={transaction.id} className="grid grid-cols-7 gap-2 p-4 border-b last:border-0">
                <div>
                  {transaction.type === "income" ? (
                    <span className="flex items-center gap-1 text-green-600">
                      <ArrowDown className="h-4 w-4" />
                      In
                    </span>
                  ) : (
                    <span className="flex items-center gap-1 text-red-600">
                      <ArrowUp className="h-4 w-4" />
                      Out
                    </span>
                  )}
                </div>
                <div className="col-span-2 font-medium">{transaction.name}</div>
                <div>{transaction.date}</div>
                <div className={transaction.type === "income" ? "text-green-600" : "text-red-600"}>
                  {transaction.type === "income" ? "+" : "-"}KES {transaction.amount.toLocaleString()}
                </div>
                <div>{transaction.category}</div>
                <div className="flex items-center gap-2">
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <Edit className="h-4 w-4" />
                    <span className="sr-only">Edit</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8">
                    <FileText className="h-4 w-4" />
                    <span className="sr-only">View Details</span>
                  </Button>
                  <Button variant="ghost" size="icon" className="h-8 w-8 text-red-600">
                    <Trash className="h-4 w-4" />
                    <span className="sr-only">Delete</span>
                  </Button>
                </div>
              </div>
            ))}
          </div>
        </CardContent>
      </Card>
    </div>
  )
}
