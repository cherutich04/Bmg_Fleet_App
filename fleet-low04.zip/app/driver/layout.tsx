import type { ReactNode } from "react"
import { redirect } from "next/navigation"
import { requireAuth } from "@/lib/auth"
import { DriverSidebar } from "@/components/driver/sidebar"
import { DriverHeader } from "@/components/driver/header"

export default async function DriverLayout({ children }: { children: ReactNode }) {
  const user = await requireAuth()

  if (user.role !== "driver") {
    redirect("/")
  }

  // Mock vehicle info - in a real app, this would come from your database
  const vehicleInfo = {
    name: "Toyota Hilux",
    plate: "KBZ 123A",
  }

  return (
    <div className="flex min-h-screen flex-col">
      <DriverSidebar />
      <div className="md:ml-64 flex-1 flex flex-col">
        <DriverHeader user={user} vehicleInfo={vehicleInfo} />
        <main className="flex-1 p-4 md:p-6">{children}</main>
      </div>
    </div>
  )
}
