"use client"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, Search } from "lucide-react"

// Mock data - in a real app, this would come from your database
const contacts = [
  {
    id: "1",
    name: "Jane Chebet",
    role: "Admin",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Please submit your expense report",
    lastMessageTime: "10:30 AM",
    unread: 2,
  },
  {
    id: "2",
    name: "Michael Rotich",
    role: "Dispatcher",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "New delivery assignment for tomorrow",
    lastMessageTime: "Yesterday",
    unread: 0,
  },
  {
    id: "3",
    name: "Sarah Jepkosgei",
    role: "Finance",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Your expense has been approved",
    lastMessageTime: "Yesterday",
    unread: 0,
  },
]

const messageHistory = {
  "1": [
    {
      id: "1",
      sender: "Jane Chebet",
      senderId: "1",
      content: "Hello John, how are you today?",
      timestamp: "10:15 AM",
      isMe: false,
    },
    {
      id: "2",
      sender: "Me",
      senderId: "current-user",
      content: "I'm doing well, thank you! How can I help you?",
      timestamp: "10:20 AM",
      isMe: true,
    },
    {
      id: "3",
      sender: "Jane Chebet",
      senderId: "1",
      content: "Please submit your expense report for the Nairobi trip by end of day.",
      timestamp: "10:25 AM",
      isMe: false,
    },
    {
      id: "4",
      sender: "Jane Chebet",
      senderId: "1",
      content: "Also, don't forget to include all receipts.",
      timestamp: "10:30 AM",
      isMe: false,
    },
  ],
  "2": [
    {
      id: "1",
      sender: "Michael Rotich",
      senderId: "2",
      content: "Hi John, I have a new delivery assignment for you.",
      timestamp: "Yesterday, 3:45 PM",
      isMe: false,
    },
    {
      id: "2",
      sender: "Me",
      senderId: "current-user",
      content: "Great! What are the details?",
      timestamp: "Yesterday, 4:00 PM",
      isMe: true,
    },
    {
      id: "3",
      sender: "Michael Rotich",
      senderId: "2",
      content: "You'll be delivering construction materials to Eldoret Construction Site tomorrow at 8 AM.",
      timestamp: "Yesterday, 4:15 PM",
      isMe: false,
    },
  ],
  "3": [
    {
      id: "1",
      sender: "Sarah Jepkosgei",
      senderId: "3",
      content: "Hello John, I've reviewed your expense report.",
      timestamp: "Yesterday, 11:30 AM",
      isMe: false,
    },
    {
      id: "2",
      sender: "Me",
      senderId: "current-user",
      content: "Hi Sarah, thank you for reviewing it. Is everything in order?",
      timestamp: "Yesterday, 11:45 AM",
      isMe: true,
    },
    {
      id: "3",
      sender: "Sarah Jepkosgei",
      senderId: "3",
      content: "Yes, your expense has been approved and will be processed for payment.",
      timestamp: "Yesterday, 12:00 PM",
      isMe: false,
    },
  ],
}

export default function DriverMessagesPage() {
  const [selectedContact, setSelectedContact] = useState<string | null>(null)
  const [message, setMessage] = useState("")
  const [messages, setMessages] = useState<typeof messageHistory>(messageHistory)
  const [searchQuery, setSearchQuery] = useState("")

  const handleSendMessage = () => {
    if (!message.trim() || !selectedContact) return

    const newMessage = {
      id: Date.now().toString(),
      sender: "Me",
      senderId: "current-user",
      content: message,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
      isMe: true,
    }

    setMessages((prev) => ({
      ...prev,
      [selectedContact]: [...(prev[selectedContact] || []), newMessage],
    }))

    setMessage("")
  }

  const filteredContacts = contacts.filter((contact) => contact.name.toLowerCase().includes(searchQuery.toLowerCase()))

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Messages</h2>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
        <Card className="md:col-span-1">
          <CardHeader className="pb-2">
            <CardTitle>Contacts</CardTitle>
            <CardDescription>Your conversations</CardDescription>
            <div className="relative mt-2">
              <Search className="absolute left-2.5 top-2.5 h-4 w-4 text-muted-foreground" />
              <Input
                placeholder="Search contacts..."
                className="pl-8"
                value={searchQuery}
                onChange={(e) => setSearchQuery(e.target.value)}
              />
            </div>
          </CardHeader>
          <CardContent>
            <div className="space-y-2">
              {filteredContacts.map((contact) => (
                <div
                  key={contact.id}
                  className={`flex items-center gap-3 rounded-md p-2 cursor-pointer hover:bg-muted ${
                    selectedContact === contact.id ? "bg-muted" : ""
                  }`}
                  onClick={() => setSelectedContact(contact.id)}
                >
                  <Avatar>
                    <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                    <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                  </Avatar>
                  <div className="flex-1 min-w-0">
                    <div className="flex items-center justify-between">
                      <p className="font-medium truncate">{contact.name}</p>
                      <p className="text-xs text-muted-foreground">{contact.lastMessageTime}</p>
                    </div>
                    <div className="flex items-center justify-between">
                      <p className="text-sm text-muted-foreground truncate">{contact.lastMessage}</p>
                      {contact.unread > 0 && (
                        <span className="inline-flex items-center justify-center h-5 w-5 rounded-full bg-primary text-primary-foreground text-xs">
                          {contact.unread}
                        </span>
                      )}
                    </div>
                  </div>
                </div>
              ))}

              {filteredContacts.length === 0 && (
                <p className="text-center text-muted-foreground py-4">No contacts found</p>
              )}
            </div>
          </CardContent>
        </Card>

        <Card className="md:col-span-2">
          <CardHeader className="pb-2">
            {selectedContact ? (
              <div className="flex items-center gap-3">
                <Avatar>
                  <AvatarImage
                    src={contacts.find((c) => c.id === selectedContact)?.avatar || "/placeholder.svg"}
                    alt={contacts.find((c) => c.id === selectedContact)?.name}
                  />
                  <AvatarFallback>{contacts.find((c) => c.id === selectedContact)?.name.charAt(0)}</AvatarFallback>
                </Avatar>
                <div>
                  <CardTitle>{contacts.find((c) => c.id === selectedContact)?.name}</CardTitle>
                  <CardDescription>{contacts.find((c) => c.id === selectedContact)?.role}</CardDescription>
                </div>
              </div>
            ) : (
              <CardTitle>Messages</CardTitle>
            )}
          </CardHeader>
          <CardContent>
            {selectedContact ? (
              <div className="flex flex-col h-[500px]">
                <div className="flex-1 overflow-y-auto mb-4 space-y-4">
                  {messages[selectedContact]?.map((msg) => (
                    <div key={msg.id} className={`flex ${msg.isMe ? "justify-end" : "justify-start"}`}>
                      <div
                        className={`max-w-[80%] rounded-lg p-3 ${
                          msg.isMe ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <p>{msg.content}</p>
                        <p
                          className={`text-xs mt-1 ${msg.isMe ? "text-primary-foreground/80" : "text-muted-foreground"}`}
                        >
                          {msg.timestamp}
                        </p>
                      </div>
                    </div>
                  ))}
                </div>
                <div className="flex items-center gap-2">
                  <Input
                    placeholder="Type a message..."
                    value={message}
                    onChange={(e) => setMessage(e.target.value)}
                    onKeyDown={(e) => {
                      if (e.key === "Enter") {
                        handleSendMessage()
                      }
                    }}
                  />
                  <Button size="icon" onClick={handleSendMessage}>
                    <Send className="h-4 w-4" />
                  </Button>
                </div>
              </div>
            ) : (
              <div className="flex items-center justify-center h-[500px] text-muted-foreground">
                Select a contact to start messaging
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </div>
  )
}
