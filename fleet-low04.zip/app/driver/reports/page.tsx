import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Label } from "@/components/ui/label"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Progress } from "@/components/ui/progress"
import { requireAuth } from "@/lib/auth"
import { Calendar, Download, FileText, Filter, PieChart, TrendingUp } from "lucide-react"

export default async function DriverReportsPage() {
  await requireAuth("driver")

  // Mock data - in a real app, this would come from your database
  const expenses = [
    {
      id: 1,
      name: "Fuel",
      date: "2023-05-14",
      amount: 5000,
      category: "Fuel",
      paymentMethod: "M-Pesa",
      status: "approved",
    },
    {
      id: 2,
      name: "Lunch",
      date: "2023-05-14",
      amount: 500,
      category: "Meals",
      paymentMethod: "Cash",
      status: "approved",
    },
    {
      id: 3,
      name: "Tire repair",
      date: "2023-05-12",
      amount: 1500,
      category: "Maintenance",
      paymentMethod: "Cash",
      status: "rejected",
      comment: "Please provide receipt next time",
    },
    {
      id: 4,
      name: "Parking",
      date: "2023-05-10",
      amount: 200,
      category: "Toll/Parking",
      paymentMethod: "Cash",
      status: "approved",
    },
    {
      id: 5,
      name: "Car wash",
      date: "2023-05-08",
      amount: 300,
      category: "Maintenance",
      paymentMethod: "M-Pesa",
      status: "approved",
    },
  ]

  const targetData = {
    progress: 68,
    amountRealized: 680000,
    targetAmount: 1000000,
  }

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <h2 className="text-3xl font-bold tracking-tight">Reports & Analytics</h2>
        <Button className="gap-2">
          <Download className="h-4 w-4" />
          Download as PDF
        </Button>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Filters</CardTitle>
          <CardDescription>Filter expenses by date, category, and payment method</CardDescription>
        </CardHeader>
        <CardContent>
          <form className="grid gap-4 md:grid-cols-4">
            <div className="space-y-2">
              <Label htmlFor="date-from">From Date</Label>
              <div className="relative">
                <Input id="date-from" type="date" />
                <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="date-to">To Date</Label>
              <div className="relative">
                <Input id="date-to" type="date" />
                <Calendar className="absolute right-3 top-2.5 h-4 w-4 text-muted-foreground" />
              </div>
            </div>

            <div className="space-y-2">
              <Label htmlFor="category">Category</Label>
              <Select>
                <SelectTrigger id="category">
                  <SelectValue placeholder="All categories" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All categories</SelectItem>
                  <SelectItem value="fuel">Fuel</SelectItem>
                  <SelectItem value="maintenance">Maintenance</SelectItem>
                  <SelectItem value="meals">Meals</SelectItem>
                  <SelectItem value="accommodation">Accommodation</SelectItem>
                  <SelectItem value="toll">Toll/Parking</SelectItem>
                  <SelectItem value="other">Other</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <div className="space-y-2">
              <Label htmlFor="payment-method">Payment Method</Label>
              <Select>
                <SelectTrigger id="payment-method">
                  <SelectValue placeholder="All methods" />
                </SelectTrigger>
                <SelectContent>
                  <SelectItem value="all">All methods</SelectItem>
                  <SelectItem value="cash">Cash</SelectItem>
                  <SelectItem value="m-pesa">M-Pesa</SelectItem>
                  <SelectItem value="card">Card</SelectItem>
                </SelectContent>
              </Select>
            </div>

            <Button type="submit" className="gap-2 md:col-span-4">
              <Filter className="h-4 w-4" />
              Apply Filters
            </Button>
          </form>
        </CardContent>
      </Card>

      <div className="grid gap-6 md:grid-cols-3">
        <Card className="md:col-span-2">
          <CardHeader>
            <CardTitle>Expense List</CardTitle>
            <CardDescription>Your recent expenses</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="rounded-md border">
              <div className="grid grid-cols-6 gap-2 p-4 font-medium border-b">
                <div className="col-span-2">Name</div>
                <div>Date</div>
                <div>Amount</div>
                <div>Category</div>
                <div>Status</div>
              </div>
              {expenses.map((expense) => (
                <div key={expense.id} className="grid grid-cols-6 gap-2 p-4 border-b last:border-0">
                  <div className="col-span-2 font-medium">{expense.name}</div>
                  <div>{expense.date}</div>
                  <div className="text-red-600">-KES {expense.amount.toLocaleString()}</div>
                  <div>{expense.category}</div>
                  <div>
                    {expense.status === "approved" ? (
                      <span className="inline-flex items-center rounded-full bg-green-100 px-2.5 py-0.5 text-xs font-medium text-green-800 dark:bg-green-900 dark:text-green-300">
                        Approved
                      </span>
                    ) : (
                      <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800 dark:bg-red-900 dark:text-red-300">
                        Rejected
                      </span>
                    )}
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Monthly Target</CardTitle>
            <CardDescription>Your progress towards monthly goals</CardDescription>
          </CardHeader>
          <CardContent className="space-y-4">
            <div className="space-y-2">
              <div className="flex items-center justify-between">
                <p className="text-sm font-medium">Target Progress</p>
                <p className="text-sm font-medium">{targetData.progress}%</p>
              </div>
              <Progress value={targetData.progress} className="h-2" />
            </div>

            <div className="space-y-4">
              <div>
                <p className="text-sm font-medium text-muted-foreground">Amount Realized</p>
                <p className="text-lg font-bold">KES {targetData.amountRealized.toLocaleString()}</p>
              </div>
              <div>
                <p className="text-sm font-medium text-muted-foreground">Set Target</p>
                <p className="text-lg font-bold">KES {targetData.targetAmount.toLocaleString()}</p>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>

      <div className="grid gap-6 md:grid-cols-2">
        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Expense Categories</CardTitle>
              <CardDescription>Breakdown by category</CardDescription>
            </div>
            <PieChart className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="aspect-square bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Pie chart will be displayed here</p>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader className="flex flex-row items-center justify-between">
            <div>
              <CardTitle>Expense Trends</CardTitle>
              <CardDescription>Monthly expense analysis</CardDescription>
            </div>
            <TrendingUp className="h-4 w-4 text-muted-foreground" />
          </CardHeader>
          <CardContent>
            <div className="aspect-square bg-muted rounded-md flex items-center justify-center">
              <p className="text-sm text-muted-foreground">Bar chart will be displayed here</p>
            </div>
          </CardContent>
        </Card>
      </div>

      <Card>
        <CardHeader>
          <CardTitle>Admin Review</CardTitle>
          <CardDescription>Rejected expenses with admin comments</CardDescription>
        </CardHeader>
        <CardContent>
          {expenses.filter((e) => e.status === "rejected").length > 0 ? (
            <div className="space-y-4">
              {expenses
                .filter((e) => e.status === "rejected")
                .map((expense) => (
                  <div key={expense.id} className="rounded-md border p-4">
                    <div className="flex items-center justify-between">
                      <div>
                        <h4 className="font-medium">{expense.name}</h4>
                        <p className="text-sm text-muted-foreground">
                          {expense.date} - KES {expense.amount.toLocaleString()}
                        </p>
                      </div>
                      <span className="inline-flex items-center rounded-full bg-red-100 px-2.5 py-0.5 text-xs font-medium text-red-800 dark:bg-red-900 dark:text-red-300">
                        Rejected
                      </span>
                    </div>
                    <div className="mt-2">
                      <p className="text-sm font-medium">Admin Comment:</p>
                      <p className="text-sm">{expense.comment}</p>
                    </div>
                  </div>
                ))}
            </div>
          ) : (
            <div className="rounded-md border border-dashed p-8 text-center">
              <FileText className="mx-auto h-8 w-8 text-muted-foreground" />
              <h3 className="mt-2 text-lg font-medium">No Rejected Expenses</h3>
              <p className="mt-1 text-sm text-muted-foreground">All your expenses have been approved by the admin.</p>
            </div>
          )}
        </CardContent>
      </Card>
    </div>
  )
}
