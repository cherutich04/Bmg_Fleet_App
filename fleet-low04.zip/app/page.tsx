import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { DbInitializer } from "@/components/db-initializer"

export default function Home() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-gradient-to-b from-blue-50 to-blue-100 dark:from-gray-900 dark:to-gray-800 p-4">
      <div className="w-full max-w-4xl">
        <DbInitializer />

        <Card className="w-full shadow-lg mt-4">
          <CardHeader className="text-center">
            <CardTitle className="text-3xl font-bold text-blue-700 dark:text-blue-400">
              BMG FLEET MANAGEMENT APP
            </CardTitle>
            <CardDescription className="text-lg">Manage your fleet with ease and efficiency</CardDescription>
          </CardHeader>
          <CardContent className="flex flex-col items-center space-y-6 p-6">
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6 w-full">
              <Card className="shadow-md hover:shadow-xl transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl">Driver Portal</CardTitle>
                  <CardDescription>Log in to manage your vehicle, track expenses, and view reports</CardDescription>
                </CardHeader>
                <CardFooter>
                  <Link href="/driver/login" className="w-full">
                    <Button className="w-full bg-gradient-to-r from-blue-600 to-blue-800 hover:from-blue-700 hover:to-blue-900">
                      Driver Login
                    </Button>
                  </Link>
                </CardFooter>
              </Card>

              <Card className="shadow-md hover:shadow-xl transition-shadow">
                <CardHeader>
                  <CardTitle className="text-xl">Admin Portal</CardTitle>
                  <CardDescription>Log in to manage fleet, drivers, and view comprehensive reports</CardDescription>
                </CardHeader>
                <CardFooter>
                  <Link href="/admin/login" className="w-full">
                    <Button className="w-full bg-gradient-to-r from-purple-600 to-purple-800 hover:from-purple-700 hover:to-purple-900">
                      Admin Login
                    </Button>
                  </Link>
                </CardFooter>
              </Card>
            </div>
          </CardContent>
          <CardFooter className="text-center text-sm text-gray-500">
            &copy; {new Date().getFullYear()} BMG Fleet Management. All rights reserved.
          </CardFooter>
        </Card>
      </div>
    </div>
  )
}
