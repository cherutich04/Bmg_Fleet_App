import type { User } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { UserNav } from "@/components/user-nav"
import { Bell } from "lucide-react"
import { Badge } from "@/components/ui/badge"

interface HeaderProps {
  user: User
  notificationCount?: number
}

export function AdminHeader({ user, notificationCount = 0 }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
      <div className="flex items-center gap-2 md:hidden">
        {/* Mobile sidebar trigger is handled in the sidebar component */}
      </div>

      <div className="flex-1">
        <h1 className="text-xl font-bold tracking-tight">BMG FLEET MANAGEMENT APP</h1>
      </div>

      <div className="flex items-center gap-4">
        <Button variant="outline" size="icon" className="relative">
          <Bell className="h-5 w-5" />
          {notificationCount > 0 && (
            <Badge className="absolute -top-1 -right-1 h-5 w-5 flex items-center justify-center p-0 text-xs">
              {notificationCount}
            </Badge>
          )}
        </Button>

        <ThemeToggle />

        <UserNav user={user} />
      </div>
    </header>
  )
}
