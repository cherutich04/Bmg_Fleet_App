"use client"

import type React from "react"

import { useState } from "react"
import Link from "next/link"
import { usePathname } from "next/navigation"
import { logout } from "@/app/actions/auth"
import { Button } from "@/components/ui/button"
import { ScrollArea } from "@/components/ui/scroll-area"
import { Sheet, SheetContent, SheetTrigger } from "@/components/ui/sheet"
import {
  BarChart3,
  Car,
  Cog,
  Home,
  LogOut,
  Menu,
  MessageSquare,
  PenToolIcon as Tool,
  Users,
  FileText,
  PlusCircle,
  CheckSquare,
} from "lucide-react"

interface SidebarProps {
  className?: string
}

export function AdminSidebar({ className }: SidebarProps) {
  const pathname = usePathname()
  const [open, setOpen] = useState(false)

  const routes = [
    {
      label: "Dashboard",
      icon: Home,
      href: "/admin/dashboard",
      color: "from-purple-500 to-purple-700",
    },
    {
      label: "Assign Vehicle & Target",
      icon: PlusCircle,
      href: "/admin/assign",
      color: "from-blue-500 to-blue-700",
    },
    {
      label: "Projects",
      icon: FileText,
      href: "/admin/projects",
      color: "from-green-500 to-green-700",
    },
    {
      label: "Drivers",
      icon: Users,
      href: "/admin/drivers",
      color: "from-yellow-500 to-yellow-700",
    },
    {
      label: "Fleet",
      icon: Car,
      href: "/admin/fleet",
      color: "from-red-500 to-red-700",
    },
    {
      label: "Maintenance",
      icon: Tool,
      href: "/admin/maintenance",
      color: "from-orange-500 to-orange-700",
    },
    {
      label: "Review Expenses",
      icon: CheckSquare,
      href: "/admin/review",
      color: "from-pink-500 to-pink-700",
    },
    {
      label: "Reports",
      icon: BarChart3,
      href: "/admin/reports",
      color: "from-indigo-500 to-indigo-700",
    },
    {
      label: "Messages",
      icon: MessageSquare,
      href: "/admin/messages",
      color: "from-teal-500 to-teal-700",
    },
    {
      label: "Settings & Roles",
      icon: Cog,
      href: "/admin/settings",
      color: "from-gray-500 to-gray-700",
    },
  ]

  return (
    <>
      <Sheet open={open} onOpenChange={setOpen}>
        <SheetTrigger asChild>
          <Button variant="outline" size="icon" className="md:hidden">
            <Menu className="h-5 w-5" />
            <span className="sr-only">Toggle menu</span>
          </Button>
        </SheetTrigger>
        <SheetContent side="left" className="p-0">
          <MobileSidebar routes={routes} pathname={pathname} onClose={() => setOpen(false)} />
        </SheetContent>
      </Sheet>

      <aside className={`hidden md:flex md:w-64 md:flex-col md:fixed md:inset-y-0 z-10 ${className}`}>
        <DesktopSidebar routes={routes} pathname={pathname} />
      </aside>
    </>
  )
}

interface SidebarRouteProps {
  routes: {
    label: string
    icon: React.ElementType
    href: string
    color: string
  }[]
  pathname: string
  onClose?: () => void
}

function MobileSidebar({ routes, pathname, onClose }: SidebarRouteProps) {
  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-950 border-r">
      <div className="p-4 border-b">
        <h2 className="text-xl font-bold">BMG Fleet Management</h2>
      </div>
      <ScrollArea className="flex-1 p-3">
        <nav className="flex flex-col gap-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              onClick={onClose}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:text-primary ${
                pathname === route.href
                  ? "bg-gradient-to-r " + route.color + " text-white"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
          <form action={logout}>
            <button
              type="submit"
              className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all text-muted-foreground hover:bg-muted hover:text-primary"
            >
              <LogOut className="h-5 w-5" />
              Logout
            </button>
          </form>
        </nav>
      </ScrollArea>
    </div>
  )
}

function DesktopSidebar({ routes, pathname }: SidebarRouteProps) {
  return (
    <div className="flex flex-col h-full bg-white dark:bg-gray-950 border-r">
      <div className="p-6 border-b">
        <h2 className="text-xl font-bold">BMG Fleet Management</h2>
      </div>
      <ScrollArea className="flex-1 p-4">
        <nav className="flex flex-col gap-1">
          {routes.map((route) => (
            <Link
              key={route.href}
              href={route.href}
              className={`flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all hover:text-primary ${
                pathname === route.href
                  ? "bg-gradient-to-r " + route.color + " text-white"
                  : "text-muted-foreground hover:bg-muted"
              }`}
            >
              <route.icon className="h-5 w-5" />
              {route.label}
            </Link>
          ))}
          <form action={logout}>
            <button
              type="submit"
              className="w-full flex items-center gap-3 rounded-lg px-3 py-2 text-sm transition-all text-muted-foreground hover:bg-muted hover:text-primary"
            >
              <LogOut className="h-5 w-5" />
              Logout
            </button>
          </form>
        </nav>
      </ScrollArea>
    </div>
  )
}
