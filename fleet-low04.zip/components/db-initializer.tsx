"use client"

import { useEffect, useState } from "react"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"
import { AlertCircle, CheckCircle } from "lucide-react"

export function DbInitializer() {
  const [status, setStatus] = useState<"loading" | "success" | "error">("loading")
  const [message, setMessage] = useState<string>("Initializing database...")

  useEffect(() => {
    const initDb = async () => {
      try {
        const response = await fetch("/api/init-db")
        const data = await response.json()

        if (data.success) {
          setStatus("success")
          setMessage("Database initialized successfully!")
        } else {
          setStatus("error")
          setMessage(`Failed to initialize database: ${data.error || "Unknown error"}`)
        }
      } catch (error) {
        setStatus("error")
        setMessage(`Failed to initialize database: ${error instanceof Error ? error.message : "Unknown error"}`)
      }
    }

    initDb()
  }, [])

  if (status === "loading") {
    return (
      <Alert className="bg-blue-50 text-blue-800 border-blue-200 dark:bg-blue-950 dark:text-blue-300 dark:border-blue-800">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Initializing</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
      </Alert>
    )
  }

  if (status === "error") {
    return (
      <Alert variant="destructive">
        <AlertCircle className="h-4 w-4" />
        <AlertTitle>Error</AlertTitle>
        <AlertDescription>{message}</AlertDescription>
      </Alert>
    )
  }

  return (
    <Alert className="bg-green-50 text-green-800 border-green-200 dark:bg-green-950 dark:text-green-300 dark:border-green-800">
      <CheckCircle className="h-4 w-4" />
      <AlertTitle>Success</AlertTitle>
      <AlertDescription>{message}</AlertDescription>
    </Alert>
  )
}
