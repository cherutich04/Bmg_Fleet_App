import type { User } from "@/lib/auth"
import { Button } from "@/components/ui/button"
import { ThemeToggle } from "@/components/theme-toggle"
import { UserNav } from "@/components/user-nav"
import { Calendar, Car } from "lucide-react"

interface HeaderProps {
  user: User
  vehicleInfo?: {
    name: string
    plate: string
  }
}

export function DriverHeader({ user, vehicleInfo }: HeaderProps) {
  return (
    <header className="sticky top-0 z-30 flex h-16 items-center gap-4 border-b bg-background px-4 md:px-6">
      <div className="flex items-center gap-2 md:hidden">
        {/* Mobile sidebar trigger is handled in the sidebar component */}
      </div>

      <div className="flex-1">
        <h1 className="text-xl font-bold tracking-tight">BMG FLEET MANAGEMENT APP</h1>
      </div>

      <div className="flex items-center gap-4">
        {vehicleInfo && (
          <div className="hidden md:flex items-center gap-2 text-sm">
            <Car className="h-4 w-4 text-muted-foreground" />
            <span className="font-medium">{vehicleInfo.name}</span>
            <span className="text-muted-foreground">({vehicleInfo.plate})</span>
          </div>
        )}

        <Button variant="outline" size="sm" className="hidden md:flex gap-2">
          <Calendar className="h-4 w-4" />
          <span>{new Date().toLocaleDateString()}</span>
        </Button>

        <ThemeToggle />

        <UserNav user={user} />
      </div>
    </header>
  )
}
