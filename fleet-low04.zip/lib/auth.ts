import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { jwtVerify, SignJWT } from "jose"

// In a real app, you would store this in an environment variable
const JWT_SECRET = new TextEncoder().encode("your-secret-key")

export type UserRole = "driver" | "admin" | "finance" | "dispatcher"

export interface User {
  id: string
  name: string
  email: string
  role: UserRole
  image?: string
}

export async function createSession(user: User) {
  // Create a JWT token
  const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 1 week
  const session = await new SignJWT({ user })
    .setProtectedHeader({ alg: "HS256" })
    .setIssuedAt()
    .setExpirationTime(expires)
    .sign(JWT_SECRET)

  // Set the session cookie
  cookies().set("session", session, {
    expires,
    httpOnly: true,
    path: "/",
    secure: process.env.NODE_ENV === "production",
    sameSite: "lax",
  })

  return session
}

export async function getSession() {
  const session = cookies().get("session")?.value

  if (!session) return null

  try {
    const { payload } = await jwtVerify(session, JWT_SECRET)
    return payload.user as User
  } catch (error) {
    return null
  }
}

export async function deleteSession() {
  cookies().delete("session")
}

export async function requireAuth(role?: UserRole) {
  const user = await getSession()

  if (!user) {
    redirect("/")
  }

  if (role && user.role !== role) {
    if (user.role === "driver") {
      redirect("/driver/dashboard")
    } else if (user.role === "admin" || user.role === "finance" || user.role === "dispatcher") {
      redirect("/admin/dashboard")
    } else {
      redirect("/")
    }
  }

  return user
}
