import { Pool } from "pg"

// Update the pool creation with better error handling
const pool = new Pool({
  connectionString: process.env.DATABASE_URL,
  ssl: {
    rejectUnauthorized: false, // This might be needed for some Neon connections
  },
  // Add connection timeout
  connectionTimeoutMillis: 10000,
})

// Update the query function with better error handling
export async function query(text: string, params?: any[]) {
  const start = Date.now()
  try {
    const res = await pool.query(text, params)
    const duration = Date.now() - start
    console.log("Executed query", { text, duration, rows: res.rowCount })
    return res
  } catch (error) {
    console.error("Error executing query", { text, error })
    throw error
  }
}

// Initialize the database with tables if they don't exist
export async function initializeDatabase() {
  try {
    // Create users table
    await query(`
      CREATE TABLE IF NOT EXISTS users (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        email VARCHAR(255) UNIQUE NOT NULL,
        password VARCHAR(255) NOT NULL,
        role VARCHAR(50) NOT NULL,
        phone VARCHAR(50),
        id_number VARCHAR(50),
        license_number VARCHAR(50),
        license_expiry DATE,
        date_of_birth DATE,
        employment_date DATE,
        driver_type VARCHAR(50),
        address TEXT,
        emergency_contact_name VARCHAR(255),
        emergency_contact_phone VARCHAR(50),
        image_url VARCHAR(255),
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create vehicles table
    await query(`
      CREATE TABLE IF NOT EXISTS vehicles (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        plate VARCHAR(50) UNIQUE NOT NULL,
        type VARCHAR(50) NOT NULL,
        status VARCHAR(50) NOT NULL,
        odometer INT,
        fuel_consumption DECIMAL(10, 2),
        purchase_date DATE,
        insurance_expiry DATE,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create vehicle_assignments table
    await query(`
      CREATE TABLE IF NOT EXISTS vehicle_assignments (
        id SERIAL PRIMARY KEY,
        vehicle_id INT REFERENCES vehicles(id),
        user_id INT REFERENCES users(id),
        project_id INT,
        start_date DATE NOT NULL,
        end_date DATE,
        notes TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create projects table
    await query(`
      CREATE TABLE IF NOT EXISTS projects (
        id SERIAL PRIMARY KEY,
        name VARCHAR(255) NOT NULL,
        description TEXT,
        status VARCHAR(50) NOT NULL,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create expenses table
    await query(`
      CREATE TABLE IF NOT EXISTS expenses (
        id SERIAL PRIMARY KEY,
        user_id INT REFERENCES users(id),
        vehicle_id INT REFERENCES vehicles(id),
        project_id INT REFERENCES projects(id),
        type VARCHAR(50) NOT NULL,
        name VARCHAR(255) NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        date DATE NOT NULL,
        category VARCHAR(50),
        payment_method VARCHAR(50),
        paid_by VARCHAR(255),
        paid_to VARCHAR(255),
        receipt_url VARCHAR(255),
        notes TEXT,
        status VARCHAR(50) DEFAULT 'pending',
        rejection_reason TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create targets table
    await query(`
      CREATE TABLE IF NOT EXISTS targets (
        id SERIAL PRIMARY KEY,
        user_id INT REFERENCES users(id),
        project_id INT REFERENCES projects(id),
        month INT NOT NULL,
        year INT NOT NULL,
        amount DECIMAL(10, 2) NOT NULL,
        description TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Create maintenance table
    await query(`
      CREATE TABLE IF NOT EXISTS maintenance (
        id SERIAL PRIMARY KEY,
        vehicle_id INT REFERENCES vehicles(id),
        type VARCHAR(50) NOT NULL,
        description TEXT NOT NULL,
        date DATE NOT NULL,
        cost DECIMAL(10, 2),
        odometer INT,
        performed_by VARCHAR(255),
        notes TEXT,
        created_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP,
        updated_at TIMESTAMP WITH TIME ZONE DEFAULT CURRENT_TIMESTAMP
      )
    `)

    // Insert sample data if tables are empty
    const usersCount = await query("SELECT COUNT(*) FROM users")
    if (usersCount.rows[0].count === "0") {
      await insertSampleData()
    }

    console.log("Database initialized successfully")
  } catch (error) {
    console.error("Error initializing database", error)
    throw error
  }
}

// Insert sample data
async function insertSampleData() {
  try {
    // Insert users
    await query(`
      INSERT INTO users (name, email, password, role, phone, id_number, license_number, license_expiry, driver_type, image_url)
      VALUES 
        ('John Kipchoge', 'driver@example.com', '$2a$10$8Wz6gLyQMFdUzQyLV5YDKuQx.CO9yWTJrIxLCaWMjbWZgOFPJsmKe', 'driver', '+254712345678', '12345678', 'DL12345', '2025-12-31', 'full-time', '/placeholder.svg?height=40&width=40'),
        ('Jane Chebet', 'admin@example.com', '$2a$10$8Wz6gLyQMFdUzQyLV5YDKuQx.CO9yWTJrIxLCaWMjbWZgOFPJsmKe', 'admin', '+254723456789', '23456789', NULL, NULL, NULL, '/placeholder.svg?height=40&width=40'),
        ('David Kimutai', 'driver2@example.com', '$2a$10$8Wz6gLyQMFdUzQyLV5YDKuQx.CO9yWTJrIxLCaWMjbWZgOFPJsmKe', 'driver', '+254734567890', '34567890', 'DL23456', '2024-10-15', 'full-time', '/placeholder.svg?height=40&width=40'),
        ('Sarah Jepkosgei', 'finance@example.com', '$2a$10$8Wz6gLyQMFdUzQyLV5YDKuQx.CO9yWTJrIxLCaWMjbWZgOFPJsmKe', 'finance', '+254745678901', '45678901', NULL, NULL, NULL, '/placeholder.svg?height=40&width=40'),
        ('Michael Rotich', 'dispatcher@example.com', '$2a$10$8Wz6gLyQMFdUzQyLV5YDKuQx.CO9yWTJrIxLCaWMjbWZgOFPJsmKe', 'dispatcher', '+254756789012', '56789012', NULL, NULL, NULL, '/placeholder.svg?height=40&width=40')
    `)

    // Insert vehicles
    await query(`
      INSERT INTO vehicles (name, plate, type, status, odometer, fuel_consumption)
      VALUES 
        ('Toyota Hilux', 'KBZ 123A', 'Pickup Truck', 'active', 45678, 12.5),
        ('Isuzu D-Max', 'KCA 456B', 'Pickup Truck', 'active', 32456, 13.2),
        ('Ford Ranger', 'KDG 789C', 'Pickup Truck', 'maintenance', 67890, 14.0),
        ('Toyota Land Cruiser', 'KBN 234D', 'SUV', 'active', 23456, 15.5),
        ('Mitsubishi Fuso', 'KCT 567E', 'Truck', 'active', 78901, 18.0)
    `)

    // Insert projects
    await query(`
      INSERT INTO projects (name, description, status)
      VALUES 
        ('Eldoret-Nairobi Deliveries', 'Regular deliveries between Eldoret and Nairobi', 'active'),
        ('Eldoret-Nakuru Route', 'Transportation services along Eldoret-Nakuru highway', 'active'),
        ('Eldoret Construction Sites', 'Transportation of materials to construction sites in Eldoret', 'active'),
        ('Kitale Agricultural Supplies', 'Delivery of agricultural supplies to Kitale region', 'inactive'),
        ('Eldoret-Kisumu Route', 'Transportation services along Eldoret-Kisumu highway', 'active')
    `)

    // Insert vehicle assignments
    await query(`
      INSERT INTO vehicle_assignments (vehicle_id, user_id, project_id, start_date, end_date, notes)
      VALUES 
        (1, 1, 1, '2023-01-01', '2023-12-31', 'Primary driver for Nairobi route'),
        (2, 3, 2, '2023-02-01', '2023-12-31', 'Primary driver for Nakuru route'),
        (4, 1, 5, '2023-03-01', '2023-06-30', 'Temporary assignment for Kisumu route')
    `)

    // Insert expenses
    await query(`
      INSERT INTO expenses (user_id, vehicle_id, project_id, type, name, amount, date, category, payment_method, paid_by, status)
      VALUES 
        (1, 1, 1, 'expense', 'Fuel', 5000, '2023-05-14', 'Fuel', 'M-Pesa', 'Driver', 'approved'),
        (1, 1, 1, 'expense', 'Lunch', 500, '2023-05-14', 'Meals', 'Cash', 'Driver', 'approved'),
        (3, 2, 2, 'expense', 'Tire repair', 1500, '2023-05-12', 'Maintenance', 'Cash', 'Driver', 'rejected'),
        (1, 1, 1, 'expense', 'Parking', 200, '2023-05-10', 'Toll/Parking', 'Cash', 'Driver', 'approved'),
        (3, 2, 2, 'expense', 'Car wash', 300, '2023-05-08', 'Maintenance', 'M-Pesa', 'Driver', 'approved'),
        (1, 1, 1, 'income', 'Delivery to Nairobi CBD', 15000, '2023-05-15', 'Delivery', 'Cash', 'Client A', 'approved'),
        (3, 2, 2, 'income', 'Delivery to Nakuru', 12000, '2023-05-13', 'Delivery', 'M-Pesa', 'Client B', 'approved')
    `)

    // Insert targets
    await query(`
      INSERT INTO targets (user_id, project_id, month, year, amount, description)
      VALUES 
        (1, 1, 5, 2023, 1000000, 'Monthly target for Nairobi route'),
        (3, 2, 5, 2023, 800000, 'Monthly target for Nakuru route')
    `)

    // Insert maintenance records
    await query(`
      INSERT INTO maintenance (vehicle_id, type, description, date, cost, odometer)
      VALUES 
        (1, 'Routine', 'Oil change and filter replacement', '2023-04-15', 3500, 45000),
        (2, 'Repair', 'Brake pad replacement', '2023-04-20', 5000, 32000),
        (3, 'Major', 'Engine overhaul', '2023-05-01', 50000, 67500)
    `)

    console.log("Sample data inserted successfully")
  } catch (error) {
    console.error("Error inserting sample data", error)
    throw error
  }
}
