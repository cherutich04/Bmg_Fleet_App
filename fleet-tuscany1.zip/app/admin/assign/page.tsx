"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { CalendarIcon, Car, Target } from "lucide-react"
import { format } from "date-fns"
import { cn } from "@/lib/utils"
import { motion } from "framer-motion"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"

// Mock data for the user
const user = {
  id: 1,
  username: "admin",
  firstName: "Admin",
  lastName: "User",
  role: "admin" as const,
}

// Mock data for drivers
const drivers = [
  { id: 1, name: "John Doe", currentVehicle: "KDG 442X" },
  { id: 2, name: "Jane Smith", currentVehicle: "KCG 123Y" },
  { id: 3, name: "Bob Johnson", currentVehicle: "KBZ 789Z" },
  { id: 4, name: "Alice Brown", currentVehicle: null },
]

// Mock data for vehicles
const vehicles = [
  { id: 1, plateNumber: "KDG 442X", model: "Land Cruiser (LC-79)", status: "assigned", assignedTo: "John Doe" },
  { id: 2, plateNumber: "KCG 123Y", model: "Toyota Hilux", status: "assigned", assignedTo: "Jane Smith" },
  { id: 3, plateNumber: "KBZ 789Z", model: "Isuzu D-Max", status: "assigned", assignedTo: "Bob Johnson" },
  { id: 4, plateNumber: "KAB 456X", model: "Land Cruiser (LC-79)", status: "available", assignedTo: null },
  { id: 5, plateNumber: "KCD 789Y", model: "Toyota Hilux", status: "maintenance", assignedTo: null },
]

// Mock data for assignments
const initialAssignments = [
  {
    id: 1,
    driverName: "John Doe",
    vehiclePlate: "KDG 442X",
    startDate: "2023-01-01",
    endDate: "2023-12-31",
  },
  {
    id: 2,
    driverName: "Jane Smith",
    vehiclePlate: "KCG 123Y",
    startDate: "2023-02-15",
    endDate: "2023-12-31",
  },
  {
    id: 3,
    driverName: "Bob Johnson",
    vehiclePlate: "KBZ 789Z",
    startDate: "2023-03-10",
    endDate: "2023-12-31",
  },
]

// Mock data for targets
const initialTargets = [
  {
    id: 1,
    driverName: "John Doe",
    month: "April",
    year: "2023",
    targetAmount: 200000,
  },
  {
    id: 2,
    driverName: "Jane Smith",
    month: "April",
    year: "2023",
    targetAmount: 180000,
  },
  {
    id: 3,
    driverName: "Bob Johnson",
    month: "April",
    year: "2023",
    targetAmount: 220000,
  },
]

export default function AssignPage() {
  const [selectedDriver, setSelectedDriver] = useState("")
  const [selectedVehicle, setSelectedVehicle] = useState("")
  const [startDate, setStartDate] = useState<Date | undefined>(new Date())
  const [endDate, setEndDate] = useState<Date | undefined>(undefined)
  const [assignments, setAssignments] = useState(initialAssignments)

  const [targetDriver, setTargetDriver] = useState("")
  const [targetMonth, setTargetMonth] = useState("April")
  const [targetYear, setTargetYear] = useState("2023")
  const [targetAmount, setTargetAmount] = useState("")
  const [targets, setTargets] = useState(initialTargets)

  const months = [
    "January",
    "February",
    "March",
    "April",
    "May",
    "June",
    "July",
    "August",
    "September",
    "October",
    "November",
    "December",
  ]

  const years = ["2023", "2024", "2025", "2026", "2027"]

  const handleAssignVehicle = () => {
    if (!selectedDriver || !selectedVehicle || !startDate) return

    const newAssignment = {
      id: Math.max(0, ...assignments.map((a) => a.id)) + 1,
      driverName: drivers.find((d) => d.id.toString() === selectedDriver)?.name || "",
      vehiclePlate: vehicles.find((v) => v.id.toString() === selectedVehicle)?.plateNumber || "",
      startDate: format(startDate, "yyyy-MM-dd"),
      endDate: endDate ? format(endDate, "yyyy-MM-dd") : "Indefinite",
    }

    setAssignments([...assignments, newAssignment])

    // Reset form
    setSelectedDriver("")
    setSelectedVehicle("")
    setStartDate(new Date())
    setEndDate(undefined)
  }

  const handleSetTarget = () => {
    if (!targetDriver || !targetMonth || !targetYear || !targetAmount) return

    const newTarget = {
      id: Math.max(0, ...targets.map((t) => t.id)) + 1,
      driverName: drivers.find((d) => d.id.toString() === targetDriver)?.name || "",
      month: targetMonth,
      year: targetYear,
      targetAmount: Number.parseInt(targetAmount),
    }

    setTargets([...targets, newTarget])

    // Reset form
    setTargetDriver("")
    setTargetMonth("April")
    setTargetYear("2023")
    setTargetAmount("")
  }

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <AdminHeader user={user} />

        <main className="flex-1 overflow-auto p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="mx-auto max-w-6xl"
          >
            <h1 className="text-2xl font-bold mb-6">Assign Vehicle & Set Target</h1>

            <Tabs defaultValue="assign" className="mb-6">
              <TabsList className="mb-4">
                <TabsTrigger value="assign">Assign Vehicle</TabsTrigger>
                <TabsTrigger value="target">Set Monthly Target</TabsTrigger>
              </TabsList>

              <TabsContent value="assign">
                <Card className="gradient-border">
                  <CardHeader className="bg-primary/10">
                    <div className="flex items-center">
                      <Car className="mr-2 h-5 w-5 text-primary" />
                      <CardTitle>Assign Vehicle to Driver</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Driver</label>
                        <Select value={selectedDriver} onValueChange={setSelectedDriver}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select driver" />
                          </SelectTrigger>
                          <SelectContent>
                            {drivers.map((driver) => (
                              <SelectItem key={driver.id} value={driver.id.toString()}>
                                {driver.name} {driver.currentVehicle ? `(Current: ${driver.currentVehicle})` : ""}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Vehicle</label>
                        <Select value={selectedVehicle} onValueChange={setSelectedVehicle}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select vehicle" />
                          </SelectTrigger>
                          <SelectContent>
                            {vehicles.map((vehicle) => (
                              <SelectItem
                                key={vehicle.id}
                                value={vehicle.id.toString()}
                                disabled={vehicle.status === "maintenance"}
                              >
                                {vehicle.plateNumber} - {vehicle.model}
                                {vehicle.status === "assigned"
                                  ? ` (Assigned to ${vehicle.assignedTo})`
                                  : vehicle.status === "maintenance"
                                    ? " (Under Maintenance)"
                                    : " (Available)"}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Assignment Start Date</label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !startDate && "text-muted-foreground",
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {startDate ? format(startDate, "PPP") : <span>Pick a date</span>}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar mode="single" selected={startDate} onSelect={setStartDate} initialFocus />
                          </PopoverContent>
                        </Popover>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Assignment End Date (Optional)</label>
                        <Popover>
                          <PopoverTrigger asChild>
                            <Button
                              variant={"outline"}
                              className={cn(
                                "w-full justify-start text-left font-normal",
                                !endDate && "text-muted-foreground",
                              )}
                            >
                              <CalendarIcon className="mr-2 h-4 w-4" />
                              {endDate ? format(endDate, "PPP") : <span>Pick a date</span>}
                            </Button>
                          </PopoverTrigger>
                          <PopoverContent className="w-auto p-0">
                            <Calendar
                              mode="single"
                              selected={endDate}
                              onSelect={setEndDate}
                              initialFocus
                              disabled={(date) => date < (startDate || new Date())}
                            />
                          </PopoverContent>
                        </Popover>
                      </div>
                    </div>

                    <Button onClick={handleAssignVehicle} className="w-full glow-effect">
                      Assign Vehicle
                    </Button>
                  </CardContent>
                </Card>

                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Current Assignments</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Driver</TableHead>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>Start Date</TableHead>
                          <TableHead>End Date</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {assignments.map((assignment) => (
                          <TableRow key={assignment.id}>
                            <TableCell>{assignment.driverName}</TableCell>
                            <TableCell>{assignment.vehiclePlate}</TableCell>
                            <TableCell>{assignment.startDate}</TableCell>
                            <TableCell>{assignment.endDate}</TableCell>
                          </TableRow>
                        ))}
                        {assignments.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                              No assignments found.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="target">
                <Card className="gradient-border">
                  <CardHeader className="bg-primary/10">
                    <div className="flex items-center">
                      <Target className="mr-2 h-5 w-5 text-primary" />
                      <CardTitle>Set Monthly Target</CardTitle>
                    </div>
                  </CardHeader>
                  <CardContent className="p-6 space-y-4">
                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Driver</label>
                        <Select value={targetDriver} onValueChange={setTargetDriver}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select driver" />
                          </SelectTrigger>
                          <SelectContent>
                            {drivers.map((driver) => (
                              <SelectItem key={driver.id} value={driver.id.toString()}>
                                {driver.name}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Target Amount (Kshs)</label>
                        <Input
                          type="number"
                          placeholder="Enter target amount"
                          value={targetAmount}
                          onChange={(e) => setTargetAmount(e.target.value)}
                        />
                      </div>
                    </div>

                    <div className="grid gap-4 md:grid-cols-2">
                      <div className="space-y-2">
                        <label className="text-sm font-medium">Month</label>
                        <Select value={targetMonth} onValueChange={setTargetMonth}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select month" />
                          </SelectTrigger>
                          <SelectContent>
                            {months.map((month) => (
                              <SelectItem key={month} value={month}>
                                {month}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>

                      <div className="space-y-2">
                        <label className="text-sm font-medium">Year</label>
                        <Select value={targetYear} onValueChange={setTargetYear}>
                          <SelectTrigger>
                            <SelectValue placeholder="Select year" />
                          </SelectTrigger>
                          <SelectContent>
                            {years.map((year) => (
                              <SelectItem key={year} value={year}>
                                {year}
                              </SelectItem>
                            ))}
                          </SelectContent>
                        </Select>
                      </div>
                    </div>

                    <Button onClick={handleSetTarget} className="w-full glow-effect">
                      Set Target
                    </Button>
                  </CardContent>
                </Card>

                <Card className="mt-6">
                  <CardHeader>
                    <CardTitle>Current Targets</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Driver</TableHead>
                          <TableHead>Month</TableHead>
                          <TableHead>Year</TableHead>
                          <TableHead>Target Amount (Kshs)</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {targets.map((target) => (
                          <TableRow key={target.id}>
                            <TableCell>{target.driverName}</TableCell>
                            <TableCell>{target.month}</TableCell>
                            <TableCell>{target.year}</TableCell>
                            <TableCell>{target.targetAmount.toLocaleString()}</TableCell>
                          </TableRow>
                        ))}
                        {targets.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={4} className="text-center py-8 text-muted-foreground">
                              No targets found.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>

          <footer className="mt-8 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
