import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { requireAuth } from "@/lib/auth"
import { AdminDashboardSummary } from "@/components/admin/dashboard-summary"
import { AdminFleetMap } from "@/components/admin/fleet-map"
import { AdminAlerts } from "@/components/admin/alerts"
import { AdminAnalytics } from "@/components/admin/analytics"
import { AdminQuickActions } from "@/components/admin/quick-actions"

export default async function AdminDashboard() {
  const user = await requireAuth("admin")

  // This would normally come from your database
  const fleetSummary = {
    activeVehicles: 24,
    totalVehicles: 30,
    maintenanceAlerts: 3,
    fuelEfficiency: 8.5,
    fuelTrend: "up",
    compliance: 92,
  }

  const alerts = [
    {
      id: "1",
      message: "KDG 442X - Engine Fault (Check Now)",
      type: "critical",
      timestamp: "10 min ago",
    },
    {
      id: "2",
      message: "M-Pesa Payment Failed - Ksh 15,000 (Retry)",
      type: "warning",
      timestamp: "30 min ago",
    },
    {
      id: "3",
      message: "Insurance Renewal Due in 7 Days",
      type: "low",
      timestamp: "2 hours ago",
    },
  ]

  const analyticsData = {
    mileageFuel: [
      { vehicle: "KDG 442X", mileage: 1200, fuelCost: 15000 },
      { vehicle: "KCG 123Y", mileage: 800, fuelCost: 10000 },
      { vehicle: "KBZ 789Z", mileage: 1500, fuelCost: 18000 },
      { vehicle: "KAB 456X", mileage: 950, fuelCost: 12000 },
    ],
  }

  return (
    <div className="flex h-screen">
      <AdminSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <AdminHeader user={user} />

        <main className="flex-1 overflow-auto bg-gray-50 p-4">
          <div className="mx-auto max-w-7xl space-y-6">
            <h1 className="text-2xl font-bold">Admin Dashboard</h1>

            <AdminDashboardSummary summary={fleetSummary} />

            <div className="grid gap-6 lg:grid-cols-3">
              <div className="lg:col-span-2">
                <AdminFleetMap />
              </div>
              <div>
                <AdminAlerts alerts={alerts} />
              </div>
            </div>

            <AdminAnalytics data={analyticsData} />

            <AdminQuickActions />
          </div>

          <footer className="mt-8 rounded-lg border bg-white p-4 text-center text-sm text-gray-500">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
