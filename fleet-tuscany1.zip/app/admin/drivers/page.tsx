"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { UserPlus, Search, Edit, Trash, Eye } from "lucide-react"
import { format } from "date-fns"
import { motion } from "framer-motion"
import Link from "next/link"

// Mock data for the user
const user = {
  id: 1,
  username: "admin",
  firstName: "Admin",
  lastName: "User",
  role: "admin" as const,
}

// Mock data for drivers
const initialDrivers = [
  {
    id: 1,
    username: "driver1",
    firstName: "John",
    lastName: "Doe",
    email: "john@example.com",
    phone: "+254712345678",
    licenseNumber: "DL12345",
    licenseExpiry: "2024-12-31",
    profilePicture: "/placeholder.svg?height=40&width=40",
    currentVehicle: "KDG 442X",
    status: "active",
  },
  {
    id: 2,
    username: "driver2",
    firstName: "Jane",
    lastName: "Smith",
    email: "jane@example.com",
    phone: "+254723456789",
    licenseNumber: "DL67890",
    licenseExpiry: "2024-10-15",
    profilePicture: "/placeholder.svg?height=40&width=40",
    currentVehicle: "KCG 123Y",
    status: "active",
  },
  {
    id: 3,
    username: "driver3",
    firstName: "Bob",
    lastName: "Johnson",
    email: "bob@example.com",
    phone: "+254734567890",
    licenseNumber: "DL54321",
    licenseExpiry: "2023-11-30",
    profilePicture: "/placeholder.svg?height=40&width=40",
    currentVehicle: "KBZ 789Z",
    status: "active",
  },
  {
    id: 4,
    username: "driver4",
    firstName: "Alice",
    lastName: "Brown",
    email: "alice@example.com",
    phone: "+254745678901",
    licenseNumber: "DL09876",
    licenseExpiry: "2024-08-22",
    profilePicture: "/placeholder.svg?height=40&width=40",
    currentVehicle: null,
    status: "inactive",
  },
]

export default function DriversPage() {
  const [drivers, setDrivers] = useState(initialDrivers)
  const [searchTerm, setSearchTerm] = useState("")

  const filteredDrivers = drivers.filter(
    (driver) =>
      driver.firstName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      driver.lastName.toLowerCase().includes(searchTerm.toLowerCase()) ||
      driver.username.toLowerCase().includes(searchTerm.toLowerCase()) ||
      driver.email.toLowerCase().includes(searchTerm.toLowerCase()) ||
      (driver.currentVehicle && driver.currentVehicle.toLowerCase().includes(searchTerm.toLowerCase())),
  )

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "active":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Active</Badge>
      case "inactive":
        return (
          <Badge variant="outline" className="bg-gray-100 text-gray-800 dark:bg-gray-800 dark:text-gray-300">
            Inactive
          </Badge>
        )
      default:
        return null
    }
  }

  const getLicenseStatus = (expiryDate: string) => {
    const today = new Date()
    const expiry = new Date(expiryDate)
    const daysUntilExpiry = Math.ceil((expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24))

    if (daysUntilExpiry < 0) {
      return <Badge variant="destructive">Expired</Badge>
    } else if (daysUntilExpiry <= 30) {
      return (
        <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">Expiring Soon</Badge>
      )
    } else {
      return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Valid</Badge>
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <AdminHeader user={user} />

        <main className="flex-1 overflow-auto p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="mx-auto max-w-7xl"
          >
            <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between mb-6">
              <h1 className="text-2xl font-bold">Driver Management</h1>
              <div className="mt-4 sm:mt-0">
                <Button asChild className="glow-effect">
                  <Link href="/admin/drivers/add">
                    <UserPlus className="h-4 w-4 mr-2" />
                    Add New Driver
                  </Link>
                </Button>
              </div>
            </div>

            <Card className="mb-6">
              <CardHeader>
                <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between">
                  <CardTitle>Driver List</CardTitle>
                  <div className="mt-4 sm:mt-0 relative">
                    <Search className="absolute left-2 top-2.5 h-4 w-4 text-muted-foreground" />
                    <Input
                      placeholder="Search drivers..."
                      className="pl-8 max-w-xs"
                      value={searchTerm}
                      onChange={(e) => setSearchTerm(e.target.value)}
                    />
                  </div>
                </div>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Driver</TableHead>
                      <TableHead>Contact</TableHead>
                      <TableHead>License</TableHead>
                      <TableHead>Current Vehicle</TableHead>
                      <TableHead>Status</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {filteredDrivers.map((driver) => (
                      <TableRow key={driver.id}>
                        <TableCell>
                          <div className="flex items-center gap-3">
                            <Avatar className="h-9 w-9">
                              <AvatarImage
                                src={driver.profilePicture || "/placeholder.svg"}
                                alt={`${driver.firstName} ${driver.lastName}`}
                              />
                              <AvatarFallback>
                                {driver.firstName.charAt(0)}
                                {driver.lastName.charAt(0)}
                              </AvatarFallback>
                            </Avatar>
                            <div>
                              <div className="font-medium">
                                {driver.firstName} {driver.lastName}
                              </div>
                              <div className="text-sm text-muted-foreground">@{driver.username}</div>
                            </div>
                          </div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{driver.email}</div>
                          <div className="text-sm text-muted-foreground">{driver.phone}</div>
                        </TableCell>
                        <TableCell>
                          <div className="text-sm">{driver.licenseNumber}</div>
                          <div className="flex items-center gap-2">
                            <span className="text-xs text-muted-foreground">
                              Expires: {format(new Date(driver.licenseExpiry), "dd MMM yyyy")}
                            </span>
                            {getLicenseStatus(driver.licenseExpiry)}
                          </div>
                        </TableCell>
                        <TableCell>
                          {driver.currentVehicle ? (
                            <Badge
                              variant="outline"
                              className="bg-blue-50 text-blue-800 dark:bg-blue-900 dark:text-blue-300"
                            >
                              {driver.currentVehicle}
                            </Badge>
                          ) : (
                            <span className="text-sm text-muted-foreground">Not assigned</span>
                          )}
                        </TableCell>
                        <TableCell>{getStatusBadge(driver.status)}</TableCell>
                        <TableCell className="text-right">
                          <div className="flex justify-end gap-2">
                            <Button size="sm" variant="ghost">
                              <Eye className="h-4 w-4" />
                              <span className="sr-only">View</span>
                            </Button>
                            <Button size="sm" variant="ghost">
                              <Edit className="h-4 w-4" />
                              <span className="sr-only">Edit</span>
                            </Button>
                            <Button size="sm" variant="ghost" className="text-destructive hover:text-destructive/90">
                              <Trash className="h-4 w-4" />
                              <span className="sr-only">Delete</span>
                            </Button>
                          </div>
                        </TableCell>
                      </TableRow>
                    ))}
                    {filteredDrivers.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={6} className="text-center py-8 text-muted-foreground">
                          {searchTerm ? "No drivers found matching your search." : "No drivers found."}
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>

            <Card>
              <CardHeader>
                <CardTitle>License Expiry Summary</CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid gap-4 md:grid-cols-3">
                  <div className="rounded-lg border p-4">
                    <div className="text-sm font-medium text-muted-foreground">Expired Licenses</div>
                    <div className="mt-2 flex items-center">
                      <Badge variant="destructive" className="mr-2">
                        {drivers.filter((d) => new Date(d.licenseExpiry) < new Date()).length}
                      </Badge>
                      <span className="text-sm">Drivers with expired licenses</span>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="text-sm font-medium text-muted-foreground">Expiring Soon</div>
                    <div className="mt-2 flex items-center">
                      <Badge className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300 mr-2">
                        {
                          drivers.filter((d) => {
                            const today = new Date()
                            const expiry = new Date(d.licenseExpiry)
                            const daysUntilExpiry = Math.ceil(
                              (expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24),
                            )
                            return daysUntilExpiry > 0 && daysUntilExpiry <= 30
                          }).length
                        }
                      </Badge>
                      <span className="text-sm">Licenses expiring within 30 days</span>
                    </div>
                  </div>

                  <div className="rounded-lg border p-4">
                    <div className="text-sm font-medium text-muted-foreground">Valid Licenses</div>
                    <div className="mt-2 flex items-center">
                      <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300 mr-2">
                        {
                          drivers.filter((d) => {
                            const today = new Date()
                            const expiry = new Date(d.licenseExpiry)
                            const daysUntilExpiry = Math.ceil(
                              (expiry.getTime() - today.getTime()) / (1000 * 60 * 60 * 24),
                            )
                            return daysUntilExpiry > 30
                          }).length
                        }
                      </Badge>
                      <span className="text-sm">Drivers with valid licenses</span>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          </motion.div>

          <footer className="mt-8 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
