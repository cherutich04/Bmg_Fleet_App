import { LoginForm } from "@/components/login-form"
import { Frame } from "lucide-react"
import Link from "next/link"

export default function AdminLoginPage() {
  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/40 p-4">
      <div className="w-full max-w-md space-y-8">
        <div className="flex flex-col items-center text-center">
          <Link href="/" className="mb-2">
            <Frame className="h-12 w-12" />
          </Link>
          <h1 className="text-2xl font-bold">BMG Fleet Management</h1>
          <h2 className="text-xl">Admin Login</h2>
        </div>

        <div className="rounded-lg border bg-card p-8 shadow-sm">
          <LoginForm role="admin" />
        </div>

        <div className="text-center text-sm">
          <Link href="/driver/login" className="text-primary hover:underline">
            Driver Login
          </Link>
        </div>
      </div>
    </div>
  )
}
