"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send, Users } from "lucide-react"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { motion } from "framer-motion"

// Mock data for the user
const user = {
  id: 1,
  username: "admin",
  firstName: "Admin",
  lastName: "User",
  role: "admin" as const,
}

// Mock data for drivers
const drivers = [
  {
    id: 1,
    name: "John Doe",
    role: "driver",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "I'll update the odometer reading",
    lastMessageTime: "11:45 AM",
    unread: 0,
    vehicle: "KDG 442X",
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "driver",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Yes, I'm heading to Eldoret today",
    lastMessageTime: "Yesterday",
    unread: 1,
    vehicle: "KCG 123Y",
  },
  {
    id: 3,
    name: "Bob Johnson",
    role: "driver",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Vehicle needs maintenance",
    lastMessageTime: "2 days ago",
    unread: 0,
    vehicle: "KBZ 789Z",
  },
]

// Mock data for messages
const mockMessages = [
  {
    id: 1,
    senderId: 1,
    receiverId: 1,
    text: "Hello John, I need to update you on the maintenance schedule.",
    timestamp: "10:30 AM",
  },
  {
    id: 2,
    senderId: 1,
    receiverId: 1,
    text: "Your vehicle is due for service next week.",
    timestamp: "10:31 AM",
  },
  {
    id: 3,
    senderId: 1,
    receiverId: 1,
    text: "Please update your odometer reading before the service.",
    timestamp: "10:32 AM",
  },
  {
    id: 4,
    senderId: 1,
    receiverId: 1,
    text: "I'll update the odometer reading",
    timestamp: "11:45 AM",
    isFromDriver: true,
  },
]

// Mock data for group messages
const mockGroupMessages = [
  {
    id: 1,
    senderId: 1,
    senderName: "Admin User",
    text: "Attention all drivers: Please submit your expense reports by Friday.",
    timestamp: "Yesterday, 2:30 PM",
  },
  {
    id: 2,
    senderId: 2,
    senderName: "Jane Smith",
    text: "Will do, thanks for the reminder.",
    timestamp: "Yesterday, 3:15 PM",
  },
  {
    id: 3,
    senderId: 3,
    senderName: "Bob Johnson",
    text: "Already submitted mine.",
    timestamp: "Yesterday, 4:00 PM",
  },
]

export default function AdminMessagesPage() {
  const [selectedDriver, setSelectedDriver] = useState(drivers[0])
  const [messages, setMessages] = useState(mockMessages)
  const [groupMessages, setGroupMessages] = useState(mockGroupMessages)
  const [newMessage, setNewMessage] = useState("")
  const [newGroupMessage, setNewGroupMessage] = useState("")
  const [activeTab, setActiveTab] = useState("direct")

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const message = {
      id: messages.length + 1,
      senderId: user.id,
      receiverId: selectedDriver.id,
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  const handleSendGroupMessage = () => {
    if (!newGroupMessage.trim()) return

    const message = {
      id: groupMessages.length + 1,
      senderId: user.id,
      senderName: `${user.firstName} ${user.lastName}`,
      text: newGroupMessage,
      timestamp: `Today, ${new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" })}`,
    }

    setGroupMessages([...groupMessages, message])
    setNewGroupMessage("")
  }

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <AdminHeader user={user} />

        <main className="flex-1 overflow-hidden p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="mx-auto h-full max-w-7xl"
          >
            <Tabs defaultValue="direct" onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="direct">Direct Messages</TabsTrigger>
                <TabsTrigger value="group">Group Chat</TabsTrigger>
              </TabsList>

              <TabsContent value="direct" className="h-[calc(100vh-12rem)]">
                <Card className="flex h-full overflow-hidden gradient-border">
                  <div className="w-1/3 border-r">
                    <CardHeader className="bg-primary/10">
                      <CardTitle className="text-lg">Drivers</CardTitle>
                    </CardHeader>
                    <div className="overflow-auto h-[calc(100%-4rem)]">
                      {drivers.map((driver) => (
                        <div
                          key={driver.id}
                          className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-muted/50 transition-colors ${
                            selectedDriver.id === driver.id ? "bg-muted" : ""
                          }`}
                          onClick={() => setSelectedDriver(driver)}
                        >
                          <Avatar className="h-10 w-10">
                            <AvatarImage src={driver.avatar || "/placeholder.svg"} alt={driver.name} />
                            <AvatarFallback>{driver.name.charAt(0)}</AvatarFallback>
                          </Avatar>
                          <div className="flex-1 min-w-0">
                            <div className="flex justify-between items-center">
                              <span className="font-medium truncate">{driver.name}</span>
                              <span className="text-xs text-muted-foreground">{driver.lastMessageTime}</span>
                            </div>
                            <div className="flex justify-between items-center">
                              <span className="text-sm text-muted-foreground truncate">{driver.lastMessage}</span>
                              {driver.unread > 0 && (
                                <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-primary rounded-full">
                                  {driver.unread}
                                </span>
                              )}
                            </div>
                            <div className="text-xs text-muted-foreground">Vehicle: {driver.vehicle}</div>
                          </div>
                        </div>
                      ))}
                    </div>
                  </div>

                  <div className="flex flex-col flex-1">
                    <CardHeader className="bg-primary/10 flex-row items-center justify-between">
                      <div className="flex items-center gap-3">
                        <Avatar className="h-8 w-8">
                          <AvatarImage src={selectedDriver.avatar || "/placeholder.svg"} alt={selectedDriver.name} />
                          <AvatarFallback>{selectedDriver.name.charAt(0)}</AvatarFallback>
                        </Avatar>
                        <CardTitle className="text-lg">{selectedDriver.name}</CardTitle>
                      </div>
                      <span className="text-xs text-muted-foreground">{selectedDriver.vehicle}</span>
                    </CardHeader>

                    <CardContent className="flex-1 overflow-auto p-4 space-y-4">
                      {messages.map((message) => (
                        <div
                          key={message.id}
                          className={`flex ${!message.isFromDriver ? "justify-end" : "justify-start"}`}
                        >
                          <div
                            className={`max-w-[70%] rounded-lg p-3 ${
                              !message.isFromDriver ? "bg-primary text-primary-foreground" : "bg-muted"
                            }`}
                          >
                            <p className="text-sm">{message.text}</p>
                            <span className="text-xs opacity-70 block text-right mt-1">{message.timestamp}</span>
                          </div>
                        </div>
                      ))}
                    </CardContent>

                    <div className="p-4 border-t">
                      <div className="flex gap-2">
                        <Input
                          value={newMessage}
                          onChange={(e) => setNewMessage(e.target.value)}
                          placeholder="Type a message..."
                          className="flex-1"
                          onKeyDown={(e) => {
                            if (e.key === "Enter" && !e.shiftKey) {
                              e.preventDefault()
                              handleSendMessage()
                            }
                          }}
                        />
                        <Button onClick={handleSendMessage} className="glow-effect">
                          <Send className="h-4 w-4" />
                        </Button>
                      </div>
                    </div>
                  </div>
                </Card>
              </TabsContent>

              <TabsContent value="group" className="h-[calc(100vh-12rem)]">
                <Card className="flex flex-col h-full overflow-hidden gradient-border">
                  <CardHeader className="bg-primary/10 flex-row items-center justify-between">
                    <div className="flex items-center gap-3">
                      <Users className="h-6 w-6 text-primary" />
                      <CardTitle className="text-lg">All Drivers Group Chat</CardTitle>
                    </div>
                    <span className="text-xs text-muted-foreground">{drivers.length} members</span>
                  </CardHeader>

                  <CardContent className="flex-1 overflow-auto p-4 space-y-4">
                    {groupMessages.map((message) => (
                      <div
                        key={message.id}
                        className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}
                      >
                        <div
                          className={`max-w-[70%] rounded-lg p-3 ${
                            message.senderId === user.id ? "bg-primary text-primary-foreground" : "bg-muted"
                          }`}
                        >
                          {message.senderId !== user.id && (
                            <p className="text-xs font-medium mb-1">{message.senderName}</p>
                          )}
                          <p className="text-sm">{message.text}</p>
                          <span className="text-xs opacity-70 block text-right mt-1">{message.timestamp}</span>
                        </div>
                      </div>
                    ))}
                  </CardContent>

                  <div className="p-4 border-t">
                    <div className="flex gap-2">
                      <Input
                        value={newGroupMessage}
                        onChange={(e) => setNewGroupMessage(e.target.value)}
                        placeholder="Type a message to all drivers..."
                        className="flex-1"
                        onKeyDown={(e) => {
                          if (e.key === "Enter" && !e.shiftKey) {
                            e.preventDefault()
                            handleSendGroupMessage()
                          }
                        }}
                      />
                      <Button onClick={handleSendGroupMessage} className="glow-effect">
                        <Send className="h-4 w-4" />
                      </Button>
                    </div>
                  </div>
                </Card>
              </TabsContent>
            </Tabs>
          </motion.div>

          <footer className="mt-4 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
