"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Edit, Trash, Plus, Save, X } from "lucide-react"
import { motion } from "framer-motion"
import { format } from "date-fns"

// Mock data for the user
const user = {
  id: 1,
  username: "admin",
  firstName: "Admin",
  lastName: "User",
  role: "admin" as const,
}

// Mock data for projects
const initialProjects = [
  {
    id: 1,
    name: "Kaberewo",
    createdAt: "2023-01-15T08:30:00Z",
  },
  {
    id: 2,
    name: "MTRH",
    createdAt: "2023-02-20T10:15:00Z",
  },
  {
    id: 3,
    name: "Nauyapong",
    createdAt: "2023-03-10T14:45:00Z",
  },
  {
    id: 4,
    name: "Kaptarkok",
    createdAt: "2023-04-05T09:20:00Z",
  },
]

export default function ProjectsPage() {
  const [projects, setProjects] = useState(initialProjects)
  const [newProjectName, setNewProjectName] = useState("")
  const [editingProject, setEditingProject] = useState<{ id: number; name: string } | null>(null)

  const handleAddProject = () => {
    if (!newProjectName.trim()) return

    const newProject = {
      id: Math.max(0, ...projects.map((p) => p.id)) + 1,
      name: newProjectName,
      createdAt: new Date().toISOString(),
    }

    setProjects([...projects, newProject])
    setNewProjectName("")
  }

  const handleEditProject = (project: { id: number; name: string }) => {
    setEditingProject(project)
  }

  const handleSaveEdit = () => {
    if (!editingProject) return

    setProjects(
      projects.map((project) =>
        project.id === editingProject.id ? { ...project, name: editingProject.name } : project,
      ),
    )
    setEditingProject(null)
  }

  const handleCancelEdit = () => {
    setEditingProject(null)
  }

  const handleDeleteProject = (id: number) => {
    setProjects(projects.filter((project) => project.id !== id))
  }

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <AdminHeader user={user} />

        <main className="flex-1 overflow-auto p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="mx-auto max-w-5xl"
          >
            <h1 className="text-2xl font-bold mb-6">Project Management</h1>

            <Card className="mb-6 gradient-border">
              <CardHeader className="bg-primary/10">
                <CardTitle>Add New Project</CardTitle>
              </CardHeader>
              <CardContent className="p-4">
                <div className="flex gap-2">
                  <Input
                    value={newProjectName}
                    onChange={(e) => setNewProjectName(e.target.value)}
                    placeholder="Enter project name"
                    className="flex-1"
                  />
                  <Button onClick={handleAddProject} className="glow-effect">
                    <Plus className="h-4 w-4 mr-2" />
                    Add Project
                  </Button>
                </div>
              </CardContent>
            </Card>

            <Card className="gradient-border">
              <CardHeader className="bg-primary/10">
                <CardTitle>Project List</CardTitle>
              </CardHeader>
              <CardContent className="p-0">
                <Table>
                  <TableHeader>
                    <TableRow>
                      <TableHead>Project Name</TableHead>
                      <TableHead>Creation Date</TableHead>
                      <TableHead className="text-right">Actions</TableHead>
                    </TableRow>
                  </TableHeader>
                  <TableBody>
                    {projects.map((project) => (
                      <TableRow key={project.id}>
                        <TableCell>
                          {editingProject?.id === project.id ? (
                            <Input
                              value={editingProject.name}
                              onChange={(e) => setEditingProject({ ...editingProject, name: e.target.value })}
                              className="max-w-xs"
                            />
                          ) : (
                            project.name
                          )}
                        </TableCell>
                        <TableCell>{format(new Date(project.createdAt), "PPP")}</TableCell>
                        <TableCell className="text-right">
                          {editingProject?.id === project.id ? (
                            <div className="flex justify-end gap-2">
                              <Button size="sm" variant="ghost" onClick={handleSaveEdit}>
                                <Save className="h-4 w-4" />
                              </Button>
                              <Button size="sm" variant="ghost" onClick={handleCancelEdit}>
                                <X className="h-4 w-4" />
                              </Button>
                            </div>
                          ) : (
                            <div className="flex justify-end gap-2">
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleEditProject({ id: project.id, name: project.name })}
                              >
                                <Edit className="h-4 w-4" />
                              </Button>
                              <Button
                                size="sm"
                                variant="ghost"
                                onClick={() => handleDeleteProject(project.id)}
                                className="text-destructive hover:text-destructive/90"
                              >
                                <Trash className="h-4 w-4" />
                              </Button>
                            </div>
                          )}
                        </TableCell>
                      </TableRow>
                    ))}
                    {projects.length === 0 && (
                      <TableRow>
                        <TableCell colSpan={3} className="text-center py-8 text-muted-foreground">
                          No projects found. Add a new project to get started.
                        </TableCell>
                      </TableRow>
                    )}
                  </TableBody>
                </Table>
              </CardContent>
            </Card>
          </motion.div>

          <footer className="mt-8 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
