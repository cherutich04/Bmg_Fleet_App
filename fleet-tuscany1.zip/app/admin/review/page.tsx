"use client"

import { useState } from "react"
import { AdminSidebar } from "@/components/admin/sidebar"
import { AdminHeader } from "@/components/admin/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Badge } from "@/components/ui/badge"
import {
  Dialog,
  DialogContent,
  DialogDescription,
  DialogFooter,
  DialogHeader,
  DialogTitle,
} from "@/components/ui/dialog"
import { Textarea } from "@/components/ui/textarea"
import { FileText, CheckCircle, XCircle } from "lucide-react"
import { format } from "date-fns"
import { motion } from "framer-motion"

// Mock data for the user
const user = {
  id: 1,
  username: "admin",
  firstName: "Admin",
  lastName: "User",
  role: "admin" as const,
}

// Mock data for expenses
const initialExpenses = [
  {
    id: 1,
    driverName: "John Doe",
    vehiclePlate: "KDG 442X",
    expenseName: "Fuel",
    date: "2023-04-12",
    amount: 5000,
    category: "Fuel Costs",
    paymentMethod: "M-Pesa",
    hasReceipt: true,
    notes: "Full tank",
    status: "pending",
    adminComments: "",
  },
  {
    id: 2,
    driverName: "Jane Smith",
    vehiclePlate: "KCG 123Y",
    expenseName: "Tire repair",
    date: "2023-04-14",
    amount: 1500,
    category: "Service & Maintenance",
    paymentMethod: "Cash",
    hasReceipt: true,
    notes: "Puncture repair",
    status: "pending",
    adminComments: "",
  },
  {
    id: 3,
    driverName: "Bob Johnson",
    vehiclePlate: "KBZ 789Z",
    expenseName: "Oil change",
    date: "2023-04-20",
    amount: 3000,
    category: "Service & Maintenance",
    paymentMethod: "Cash",
    hasReceipt: true,
    notes: "Regular maintenance",
    status: "approved",
    adminComments: "Approved - necessary maintenance",
  },
  {
    id: 4,
    driverName: "John Doe",
    vehiclePlate: "KDG 442X",
    expenseName: "Hotel accommodation",
    date: "2023-04-18",
    amount: 5000,
    category: "Miscellaneous",
    paymentMethod: "M-Pesa",
    hasReceipt: false,
    notes: "Overnight stay",
    status: "rejected",
    adminComments: "Personal expense, not related to work",
  },
  {
    id: 5,
    driverName: "Jane Smith",
    vehiclePlate: "KCG 123Y",
    expenseName: "Lunch",
    date: "2023-04-19",
    amount: 800,
    category: "Miscellaneous",
    paymentMethod: "Cash",
    hasReceipt: false,
    notes: "Meal during trip",
    status: "rejected",
    adminComments: "No receipt provided, please resubmit with receipt",
  },
]

export default function ReviewExpensesPage() {
  const [expenses, setExpenses] = useState(initialExpenses)
  const [activeTab, setActiveTab] = useState("pending")
  const [rejectionReason, setRejectionReason] = useState("")
  const [selectedExpense, setSelectedExpense] = useState<number | null>(null)
  const [isRejectDialogOpen, setIsRejectDialogOpen] = useState(false)

  const pendingExpenses = expenses.filter((expense) => expense.status === "pending")
  const approvedExpenses = expenses.filter((expense) => expense.status === "approved")
  const rejectedExpenses = expenses.filter((expense) => expense.status === "rejected")

  const handleApproveExpense = (id: number) => {
    setExpenses(
      expenses.map((expense) =>
        expense.id === id ? { ...expense, status: "approved", adminComments: "Approved" } : expense,
      ),
    )
  }

  const openRejectDialog = (id: number) => {
    setSelectedExpense(id)
    setRejectionReason("")
    setIsRejectDialogOpen(true)
  }

  const handleRejectExpense = () => {
    if (!selectedExpense || !rejectionReason.trim()) return

    setExpenses(
      expenses.map((expense) =>
        expense.id === selectedExpense ? { ...expense, status: "rejected", adminComments: rejectionReason } : expense,
      ),
    )

    setIsRejectDialogOpen(false)
    setSelectedExpense(null)
    setRejectionReason("")
  }

  const getStatusBadge = (status: string) => {
    switch (status) {
      case "pending":
        return (
          <Badge variant="outline" className="bg-yellow-100 text-yellow-800 dark:bg-yellow-900 dark:text-yellow-300">
            Pending
          </Badge>
        )
      case "approved":
        return <Badge className="bg-green-100 text-green-800 dark:bg-green-900 dark:text-green-300">Approved</Badge>
      case "rejected":
        return <Badge className="bg-red-100 text-red-800 dark:bg-red-900 dark:text-red-300">Rejected</Badge>
      default:
        return null
    }
  }

  return (
    <div className="flex h-screen bg-background">
      <AdminSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <AdminHeader user={user} />

        <main className="flex-1 overflow-auto p-4">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            transition={{ duration: 0.3 }}
            className="mx-auto max-w-7xl"
          >
            <h1 className="text-2xl font-bold mb-6">Review Expenses</h1>

            <Tabs defaultValue="pending" onValueChange={setActiveTab}>
              <TabsList className="mb-4">
                <TabsTrigger value="pending" className="relative">
                  Pending Review
                  {pendingExpenses.length > 0 && (
                    <span className="absolute -top-1 -right-1 flex h-5 w-5 items-center justify-center rounded-full bg-primary text-xs text-primary-foreground">
                      {pendingExpenses.length}
                    </span>
                  )}
                </TabsTrigger>
                <TabsTrigger value="approved">Approved</TabsTrigger>
                <TabsTrigger value="rejected">Rejected</TabsTrigger>
              </TabsList>

              <TabsContent value="pending">
                <Card className="gradient-border">
                  <CardHeader className="bg-primary/10">
                    <CardTitle>Pending Expenses</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Driver</TableHead>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>Expense</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount (Kshs)</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Receipt</TableHead>
                          <TableHead>Notes</TableHead>
                          <TableHead>Actions</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {pendingExpenses.map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell>{expense.driverName}</TableCell>
                            <TableCell>{expense.vehiclePlate}</TableCell>
                            <TableCell>{expense.expenseName}</TableCell>
                            <TableCell>{format(new Date(expense.date), "dd MMM yyyy")}</TableCell>
                            <TableCell>{expense.amount.toLocaleString()}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell>
                              {expense.hasReceipt ? (
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <FileText className="h-4 w-4" />
                                </Button>
                              ) : (
                                "No"
                              )}
                            </TableCell>
                            <TableCell className="max-w-[200px] truncate">{expense.notes || "-"}</TableCell>
                            <TableCell>
                              <div className="flex gap-2">
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 text-green-600 hover:text-green-700 hover:bg-green-50"
                                  onClick={() => handleApproveExpense(expense.id)}
                                >
                                  <CheckCircle className="h-4 w-4 mr-1" />
                                  Approve
                                </Button>
                                <Button
                                  size="sm"
                                  variant="outline"
                                  className="h-8 text-red-600 hover:text-red-700 hover:bg-red-50"
                                  onClick={() => openRejectDialog(expense.id)}
                                >
                                  <XCircle className="h-4 w-4 mr-1" />
                                  Reject
                                </Button>
                              </div>
                            </TableCell>
                          </TableRow>
                        ))}
                        {pendingExpenses.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                              No pending expenses to review.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="approved">
                <Card>
                  <CardHeader>
                    <CardTitle>Approved Expenses</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Driver</TableHead>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>Expense</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount (Kshs)</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Receipt</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Comments</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {approvedExpenses.map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell>{expense.driverName}</TableCell>
                            <TableCell>{expense.vehiclePlate}</TableCell>
                            <TableCell>{expense.expenseName}</TableCell>
                            <TableCell>{format(new Date(expense.date), "dd MMM yyyy")}</TableCell>
                            <TableCell>{expense.amount.toLocaleString()}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell>
                              {expense.hasReceipt ? (
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <FileText className="h-4 w-4" />
                                </Button>
                              ) : (
                                "No"
                              )}
                            </TableCell>
                            <TableCell>{getStatusBadge(expense.status)}</TableCell>
                            <TableCell className="max-w-[200px] truncate">{expense.adminComments || "-"}</TableCell>
                          </TableRow>
                        ))}
                        {approvedExpenses.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                              No approved expenses found.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>

              <TabsContent value="rejected">
                <Card>
                  <CardHeader>
                    <CardTitle>Rejected Expenses</CardTitle>
                  </CardHeader>
                  <CardContent className="p-0">
                    <Table>
                      <TableHeader>
                        <TableRow>
                          <TableHead>Driver</TableHead>
                          <TableHead>Vehicle</TableHead>
                          <TableHead>Expense</TableHead>
                          <TableHead>Date</TableHead>
                          <TableHead>Amount (Kshs)</TableHead>
                          <TableHead>Category</TableHead>
                          <TableHead>Receipt</TableHead>
                          <TableHead>Status</TableHead>
                          <TableHead>Rejection Reason</TableHead>
                        </TableRow>
                      </TableHeader>
                      <TableBody>
                        {rejectedExpenses.map((expense) => (
                          <TableRow key={expense.id}>
                            <TableCell>{expense.driverName}</TableCell>
                            <TableCell>{expense.vehiclePlate}</TableCell>
                            <TableCell>{expense.expenseName}</TableCell>
                            <TableCell>{format(new Date(expense.date), "dd MMM yyyy")}</TableCell>
                            <TableCell>{expense.amount.toLocaleString()}</TableCell>
                            <TableCell>{expense.category}</TableCell>
                            <TableCell>
                              {expense.hasReceipt ? (
                                <Button variant="ghost" size="icon" className="h-8 w-8">
                                  <FileText className="h-4 w-4" />
                                </Button>
                              ) : (
                                "No"
                              )}
                            </TableCell>
                            <TableCell>{getStatusBadge(expense.status)}</TableCell>
                            <TableCell className="max-w-[200px] truncate">{expense.adminComments || "-"}</TableCell>
                          </TableRow>
                        ))}
                        {rejectedExpenses.length === 0 && (
                          <TableRow>
                            <TableCell colSpan={9} className="text-center py-8 text-muted-foreground">
                              No rejected expenses found.
                            </TableCell>
                          </TableRow>
                        )}
                      </TableBody>
                    </Table>
                  </CardContent>
                </Card>
              </TabsContent>
            </Tabs>

            <Dialog open={isRejectDialogOpen} onOpenChange={setIsRejectDialogOpen}>
              <DialogContent>
                <DialogHeader>
                  <DialogTitle>Reject Expense</DialogTitle>
                  <DialogDescription>
                    Please provide a reason for rejecting this expense. This will be visible to the driver.
                  </DialogDescription>
                </DialogHeader>
                <div className="py-4">
                  <Textarea
                    placeholder="Enter rejection reason..."
                    value={rejectionReason}
                    onChange={(e) => setRejectionReason(e.target.value)}
                    className="min-h-[100px]"
                  />
                </div>
                <DialogFooter>
                  <Button variant="outline" onClick={() => setIsRejectDialogOpen(false)}>
                    Cancel
                  </Button>
                  <Button variant="destructive" onClick={handleRejectExpense} disabled={!rejectionReason.trim()}>
                    Reject Expense
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </motion.div>

          <footer className="mt-8 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
