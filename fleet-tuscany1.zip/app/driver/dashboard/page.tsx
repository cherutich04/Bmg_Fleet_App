import { DriverSidebar } from "@/components/driver/sidebar"
import { DriverHeader } from "@/components/driver/header"
import { StatusCard } from "@/components/driver/status-card"
import { MonthlyTargetCard } from "@/components/driver/monthly-target-card"
import { NotificationsCard } from "@/components/driver/notifications-card"
import { requireAuth } from "@/lib/auth"

export default async function DriverDashboard() {
  const user = await requireAuth("driver")

  // This would normally come from your database
  const vehicleData = {
    startDate: "2023-01-01",
    endDate: "2023-12-31",
    model: "Land Cruiser (LC-79)",
    plate: "KDG 442X",
    type: "Pickup Truck",
    status: "active" as const,
    odometer: 181771.6,
    fuelEfficiency: 10,
  }

  const targetData = {
    month: "April",
    targetPercentage: 15,
    amountRealized: 35000,
    targetAmount: 200000,
    tripsCompleted: 4,
    location: {
      lastUpdated: "15 min ago",
      destination: "Kaberewo",
    },
  }

  const alerts = [
    {
      id: "1",
      message: "Oil Change Due in 500km",
      type: "maintenance" as const,
      severity: "high" as const,
    },
    {
      id: "2",
      message: "Insurance Valid until Dec 2023",
      type: "other" as const,
      severity: "low" as const,
    },
  ]

  const notifications = [
    {
      id: "1",
      message: "Fuel expense approved",
      timestamp: "2h ago",
    },
    {
      id: "2",
      message: "New message from dispatcher",
      timestamp: "3h ago",
    },
    {
      id: "3",
      message: "Route change notification",
      timestamp: "5h ago",
    },
  ]

  const handleOdometerUpdate = async (value: number) => {
    // This would normally update the database
    console.log("Updating odometer to:", value)
    // Simulate API call
    await new Promise((resolve) => setTimeout(resolve, 1000))
    return
  }

  return (
    <div className="flex h-screen bg-background">
      <DriverSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <DriverHeader user={user} vehicleInfo={{ plateNumber: vehicleData.plate }} />

        <main className="flex-1 overflow-auto p-4">
          <div className="mx-auto max-w-7xl">
            <div className="grid gap-4 md:grid-cols-3">
              <StatusCard vehicleData={vehicleData} onOdometerUpdate={handleOdometerUpdate} />
              <MonthlyTargetCard targetData={targetData} />
              <NotificationsCard alerts={alerts} notifications={notifications} />
            </div>
          </div>

          <footer className="mt-8 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
