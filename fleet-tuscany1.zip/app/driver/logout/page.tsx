"use client"

import { useEffect } from "react"
import { useRouter } from "next/navigation"
import { Frame } from "lucide-react"

export default function LogoutPage() {
  const router = useRouter()

  useEffect(() => {
    async function logout() {
      try {
        await fetch("/api/auth/logout", {
          method: "POST",
          headers: {
            "Content-Type": "application/json",
          },
        })

        // Redirect to home page after logout
        router.push("/")
      } catch (error) {
        console.error("Logout error:", error)
      }
    }

    logout()
  }, [router])

  return (
    <div className="flex min-h-screen flex-col items-center justify-center bg-muted/40 p-4">
      <div className="mb-4">
        <Frame className="h-12 w-12 animate-pulse" />
      </div>
      <h1 className="text-2xl font-bold">Logging out...</h1>
      <p className="mt-2 text-muted-foreground">Please wait while we log you out.</p>
    </div>
  )
}
