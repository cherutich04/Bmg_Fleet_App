"use client"

import { useState } from "react"
import { DriverSidebar } from "@/components/driver/sidebar"
import { DriverHeader } from "@/components/driver/header"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Input } from "@/components/ui/input"
import { Button } from "@/components/ui/button"
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar"
import { Send } from "lucide-react"
import { motion } from "framer-motion"

// Mock data for the user
const user = {
  id: 1,
  username: "driver1",
  firstName: "John",
  lastName: "Doe",
  role: "driver" as const,
}

// Mock data for contacts
const contacts = [
  {
    id: 1,
    name: "Admin User",
    role: "admin",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Please update your odometer reading",
    lastMessageTime: "10:30 AM",
    unread: 2,
  },
  {
    id: 2,
    name: "Jane Smith",
    role: "driver",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Are you heading to Eldoret today?",
    lastMessageTime: "Yesterday",
    unread: 0,
  },
  {
    id: 3,
    name: "Bob Johnson",
    role: "driver",
    avatar: "/placeholder.svg?height=40&width=40",
    lastMessage: "Thanks for the update",
    lastMessageTime: "2 days ago",
    unread: 0,
  },
]

// Mock data for messages
const mockMessages = [
  {
    id: 1,
    senderId: 1,
    receiverId: 1,
    text: "Hello, I need to update you on the maintenance schedule.",
    timestamp: "10:30 AM",
  },
  {
    id: 2,
    senderId: 1,
    receiverId: 1,
    text: "Your vehicle is due for service next week.",
    timestamp: "10:31 AM",
  },
  {
    id: 3,
    senderId: 1,
    receiverId: 1,
    text: "Please update your odometer reading before the service.",
    timestamp: "10:32 AM",
  },
]

export default function MessagesPage() {
  const [selectedContact, setSelectedContact] = useState(contacts[0])
  const [messages, setMessages] = useState(mockMessages)
  const [newMessage, setNewMessage] = useState("")

  const handleSendMessage = () => {
    if (!newMessage.trim()) return

    const message = {
      id: messages.length + 1,
      senderId: user.id,
      receiverId: selectedContact.id,
      text: newMessage,
      timestamp: new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" }),
    }

    setMessages([...messages, message])
    setNewMessage("")
  }

  return (
    <div className="flex h-screen bg-background">
      <DriverSidebar />

      <div className="flex flex-1 flex-col overflow-hidden">
        <DriverHeader user={user} vehicleInfo={{ plateNumber: "KDG 442X" }} />

        <main className="flex-1 overflow-hidden p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            transition={{ duration: 0.3 }}
            className="mx-auto h-full max-w-7xl"
          >
            <Card className="flex h-[calc(100vh-12rem)] overflow-hidden gradient-border">
              <div className="w-1/3 border-r">
                <CardHeader className="bg-primary/10">
                  <CardTitle className="text-lg">Conversations</CardTitle>
                </CardHeader>
                <div className="overflow-auto h-[calc(100%-4rem)]">
                  {contacts.map((contact) => (
                    <div
                      key={contact.id}
                      className={`flex items-center gap-3 p-3 cursor-pointer hover:bg-muted/50 transition-colors ${
                        selectedContact.id === contact.id ? "bg-muted" : ""
                      }`}
                      onClick={() => setSelectedContact(contact)}
                    >
                      <Avatar className="h-10 w-10">
                        <AvatarImage src={contact.avatar || "/placeholder.svg"} alt={contact.name} />
                        <AvatarFallback>{contact.name.charAt(0)}</AvatarFallback>
                      </Avatar>
                      <div className="flex-1 min-w-0">
                        <div className="flex justify-between items-center">
                          <span className="font-medium truncate">{contact.name}</span>
                          <span className="text-xs text-muted-foreground">{contact.lastMessageTime}</span>
                        </div>
                        <div className="flex justify-between items-center">
                          <span className="text-sm text-muted-foreground truncate">{contact.lastMessage}</span>
                          {contact.unread > 0 && (
                            <span className="inline-flex items-center justify-center w-5 h-5 text-xs font-bold text-white bg-primary rounded-full">
                              {contact.unread}
                            </span>
                          )}
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              </div>

              <div className="flex flex-col flex-1">
                <CardHeader className="bg-primary/10 flex-row items-center justify-between">
                  <div className="flex items-center gap-3">
                    <Avatar className="h-8 w-8">
                      <AvatarImage src={selectedContact.avatar || "/placeholder.svg"} alt={selectedContact.name} />
                      <AvatarFallback>{selectedContact.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <CardTitle className="text-lg">{selectedContact.name}</CardTitle>
                  </div>
                  <span className="text-xs text-muted-foreground">{selectedContact.role}</span>
                </CardHeader>

                <CardContent className="flex-1 overflow-auto p-4 space-y-4">
                  {messages.map((message) => (
                    <div
                      key={message.id}
                      className={`flex ${message.senderId === user.id ? "justify-end" : "justify-start"}`}
                    >
                      <div
                        className={`max-w-[70%] rounded-lg p-3 ${
                          message.senderId === user.id ? "bg-primary text-primary-foreground" : "bg-muted"
                        }`}
                      >
                        <p className="text-sm">{message.text}</p>
                        <span className="text-xs opacity-70 block text-right mt-1">{message.timestamp}</span>
                      </div>
                    </div>
                  ))}
                </CardContent>

                <div className="p-4 border-t">
                  <div className="flex gap-2">
                    <Input
                      value={newMessage}
                      onChange={(e) => setNewMessage(e.target.value)}
                      placeholder="Type a message..."
                      className="flex-1"
                      onKeyDown={(e) => {
                        if (e.key === "Enter" && !e.shiftKey) {
                          e.preventDefault()
                          handleSendMessage()
                        }
                      }}
                    />
                    <Button onClick={handleSendMessage} className="glow-effect">
                      <Send className="h-4 w-4" />
                    </Button>
                  </div>
                </div>
              </div>
            </Card>
          </motion.div>

          <footer className="mt-4 rounded-lg border bg-card/50 backdrop-blur-sm p-4 text-center text-sm text-muted-foreground">
            © 2025 BMG Fleet Management App
          </footer>
        </main>
      </div>
    </div>
  )
}
