import Link from "next/link"
import { Button } from "@/components/ui/button"
import { Frame } from "lucide-react"

export default function Home() {
  return (
    <div className="flex flex-col min-h-screen">
      <header className="border-b">
        <div className="container mx-auto py-4 px-4 flex items-center justify-between">
          <div className="flex items-center gap-2">
            <Frame className="h-8 w-8" />
            <span className="text-xl font-bold">BMG Fleet Management</span>
          </div>
        </div>
      </header>

      <main className="flex-1 container mx-auto py-12 px-4">
        <div className="max-w-3xl mx-auto text-center">
          <h1 className="text-4xl font-bold mb-6">Welcome to BMG Fleet Management System</h1>
          <p className="text-xl text-muted-foreground mb-8">
            Manage your fleet operations efficiently with our comprehensive management system.
          </p>

          <div className="flex flex-col sm:flex-row gap-4 justify-center">
            <Button asChild size="lg" className="bg-green-600 hover:bg-green-700">
              <Link href="/driver/login">Driver Login</Link>
            </Button>
            <Button asChild size="lg" variant="outline">
              <Link href="/admin/login">Admin Login</Link>
            </Button>
          </div>
        </div>
      </main>

      <footer className="border-t py-6">
        <div className="container mx-auto px-4 text-center text-sm text-muted-foreground">
          © 2025 BMG Fleet Management App
        </div>
      </footer>
    </div>
  )
}
