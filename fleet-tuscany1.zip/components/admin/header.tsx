"use client"

import { motion } from "framer-motion"
import Image from "next/image"
import { Frame } from "lucide-react"
import { ThemeToggle } from "@/components/theme-toggle"
import type { User } from "@/lib/auth"

interface HeaderProps {
  user: User
}

export function AdminHeader({ user }: HeaderProps) {
  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col border-b bg-background/80 backdrop-blur-md p-4 md:flex-row md:items-center md:justify-between"
    >
      <div className="mb-4 flex items-center md:mb-0">
        <Frame className="mr-2 h-6 w-6 text-primary" />
        <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-500">
          BMG FLEET MANAGEMENT
        </h1>
      </div>

      <div className="flex items-center gap-4">
        <ThemeToggle />
        <span className="text-sm font-medium">
          Admin: {user.firstName} {user.lastName}
        </span>
        <div className="h-10 w-10 overflow-hidden rounded-full bg-muted border-2 border-primary/50 shadow-lg">
          <Image
            src="/placeholder.svg?height=40&width=40"
            alt="Profile"
            width={40}
            height={40}
            className="h-full w-full object-cover"
          />
        </div>
      </div>
    </motion.header>
  )
}
