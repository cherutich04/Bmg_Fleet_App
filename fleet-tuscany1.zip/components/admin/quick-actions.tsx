import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Car, FolderPlus, UserPlus, MessageSquare } from "lucide-react"
import Link from "next/link"

export function AdminQuickActions() {
  return (
    <Card>
      <CardHeader>
        <CardTitle>Quick Actions</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="grid gap-4 sm:grid-cols-2 md:grid-cols-4">
          <Button asChild variant="outline" className="h-auto flex-col gap-2 p-4">
            <Link href="/admin/assign">
              <Car className="h-6 w-6" />
              <span>Assign Vehicle to Driver</span>
            </Link>
          </Button>

          <Button asChild variant="outline" className="h-auto flex-col gap-2 p-4">
            <Link href="/admin/projects">
              <FolderPlus className="h-6 w-6" />
              <span>Add New Project</span>
            </Link>
          </Button>

          <Button asChild variant="outline" className="h-auto flex-col gap-2 p-4">
            <Link href="/admin/drivers/add">
              <UserPlus className="h-6 w-6" />
              <span>Add New Driver</span>
            </Link>
          </Button>

          <Button asChild variant="outline" className="h-auto flex-col gap-2 p-4">
            <Link href="/admin/messages">
              <MessageSquare className="h-6 w-6" />
              <span>Message Drivers</span>
            </Link>
          </Button>
        </div>
      </CardContent>
    </Card>
  )
}
