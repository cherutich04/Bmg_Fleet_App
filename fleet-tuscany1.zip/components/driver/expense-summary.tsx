"use client"

import { useState } from "react"
import { format } from "date-fns"
import { Download, Edit, FileText } from "lucide-react"
import { Button } from "@/components/ui/button"
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"

interface IncomeItem {
  id: string
  name: string
  amount: number
  date: string
  paidBy: string
  paymentMethod: string
  hasReceipt: boolean
  notes: string
}

interface ExpenseItem {
  id: string
  name: string
  amount: number
  date: string
  paidBy: string
  paymentMethod: string
  category: string
  hasReceipt: boolean
  notes: string
}

interface ExpenseSummaryProps {
  incomeData: IncomeItem[]
  expenseData: ExpenseItem[]
}

export function ExpenseSummary({ incomeData, expenseData }: ExpenseSummaryProps) {
  const [activeTab, setActiveTab] = useState("income")

  const formatDate = (dateString: string) => {
    try {
      return format(new Date(dateString), "dd MMM yyyy")
    } catch (error) {
      return dateString
    }
  }

  const formatPaymentMethod = (method: string) => {
    switch (method) {
      case "mpesa":
        return "M-Pesa"
      case "bank":
        return "Bank Transfer"
      default:
        return method.charAt(0).toUpperCase() + method.slice(1)
    }
  }

  const totalIncome = incomeData.reduce((sum, item) => sum + item.amount, 0)
  const totalExpense = expenseData.reduce((sum, item) => sum + item.amount, 0)
  const balance = totalIncome - totalExpense

  return (
    <Card>
      <CardHeader>
        <CardTitle>Income & Expense Summary</CardTitle>
      </CardHeader>
      <CardContent>
        <div className="mb-4 flex flex-wrap items-center justify-between gap-2">
          <div className="space-y-1">
            <div className="text-sm font-medium">
              Total Income: <span className="text-green-600">Ksh. {totalIncome.toLocaleString()}</span>
            </div>
            <div className="text-sm font-medium">
              Total Expenses: <span className="text-red-600">Ksh. {totalExpense.toLocaleString()}</span>
            </div>
            <div className="text-sm font-medium">
              Balance:{" "}
              <span className={balance >= 0 ? "text-green-600" : "text-red-600"}>Ksh. {balance.toLocaleString()}</span>
            </div>
          </div>
          <Button variant="outline" size="sm" className="gap-1">
            <Download className="h-4 w-4" />
            Export
          </Button>
        </div>

        <Tabs defaultValue="income" onValueChange={setActiveTab}>
          <TabsList className="grid w-full grid-cols-2">
            <TabsTrigger value="income">Income (Money In)</TabsTrigger>
            <TabsTrigger value="expense">Expenses (Money Out)</TabsTrigger>
          </TabsList>

          <TabsContent value="income">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Delivery Name</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Paid By</TableHead>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="w-[80px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {incomeData.length > 0 ? (
                    incomeData.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.amount.toLocaleString()}</TableCell>
                        <TableCell>{formatDate(item.date)}</TableCell>
                        <TableCell>{item.paidBy}</TableCell>
                        <TableCell>{formatPaymentMethod(item.paymentMethod)}</TableCell>
                        <TableCell>
                          {item.hasReceipt ? (
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <FileText className="h-4 w-4" />
                            </Button>
                          ) : (
                            "No"
                          )}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">{item.notes || "-"}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={8} className="h-24 text-center">
                        No income entries found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>

          <TabsContent value="expense">
            <div className="rounded-md border">
              <Table>
                <TableHeader>
                  <TableRow>
                    <TableHead>Expense Name</TableHead>
                    <TableHead>Amount (Kshs)</TableHead>
                    <TableHead>Date</TableHead>
                    <TableHead>Category</TableHead>
                    <TableHead>Paid By</TableHead>
                    <TableHead>Payment Method</TableHead>
                    <TableHead>Receipt</TableHead>
                    <TableHead>Notes</TableHead>
                    <TableHead className="w-[80px]">Actions</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {expenseData.length > 0 ? (
                    expenseData.map((item) => (
                      <TableRow key={item.id}>
                        <TableCell>{item.name}</TableCell>
                        <TableCell>{item.amount.toLocaleString()}</TableCell>
                        <TableCell>{formatDate(item.date)}</TableCell>
                        <TableCell>{item.category}</TableCell>
                        <TableCell>{item.paidBy}</TableCell>
                        <TableCell>{formatPaymentMethod(item.paymentMethod)}</TableCell>
                        <TableCell>
                          {item.hasReceipt ? (
                            <Button variant="ghost" size="icon" className="h-8 w-8">
                              <FileText className="h-4 w-4" />
                            </Button>
                          ) : (
                            "No"
                          )}
                        </TableCell>
                        <TableCell className="max-w-[200px] truncate">{item.notes || "-"}</TableCell>
                        <TableCell>
                          <Button variant="ghost" size="icon" className="h-8 w-8">
                            <Edit className="h-4 w-4" />
                            <span className="sr-only">Edit</span>
                          </Button>
                        </TableCell>
                      </TableRow>
                    ))
                  ) : (
                    <TableRow>
                      <TableCell colSpan={9} className="h-24 text-center">
                        No expense entries found.
                      </TableCell>
                    </TableRow>
                  )}
                </TableBody>
              </Table>
            </div>
          </TabsContent>
        </Tabs>
      </CardContent>
    </Card>
  )
}
