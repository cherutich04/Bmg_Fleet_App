"use client"

import { useState, useEffect } from "react"
import Image from "next/image"
import { Calendar } from "@/components/ui/calendar"
import { Popover, PopoverContent, PopoverTrigger } from "@/components/ui/popover"
import { Button } from "@/components/ui/button"
import { CalendarIcon } from "lucide-react"
import { format } from "date-fns"
import { motion } from "framer-motion"
import type { User } from "@/lib/auth"

interface HeaderProps {
  user: User
  vehicleInfo?: {
    plateNumber: string
  }
}

export function DriverHeader({ user, vehicleInfo }: HeaderProps) {
  const [date, setDate] = useState<Date | undefined>(new Date())
  const [time, setTime] = useState<string>(format(new Date(), "HH:mm:ss"))

  // Update time every second
  useEffect(() => {
    const timer = setInterval(() => {
      setTime(format(new Date(), "HH:mm:ss"))
    }, 1000)

    return () => clearInterval(timer)
  }, [])

  return (
    <motion.header
      initial={{ y: -20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3 }}
      className="flex flex-col border-b bg-background/80 backdrop-blur-md p-4 md:flex-row md:items-center md:justify-between"
    >
      <div className="mb-4 text-center md:mb-0 md:text-left">
        <h1 className="text-xl font-bold bg-clip-text text-transparent bg-gradient-to-r from-primary to-blue-500">
          BMG FLEET MANAGEMENT APP
        </h1>
      </div>

      <div className="flex flex-col items-center gap-4 md:flex-row">
        <div className="flex items-center gap-3">
          <div className="flex flex-col items-center">
            <div className="h-12 w-12 overflow-hidden rounded-full bg-muted border-2 border-primary/50 shadow-lg">
              <Image
                src="/placeholder.svg?height=48&width=48"
                alt="Profile"
                width={48}
                height={48}
                className="h-full w-full object-cover"
              />
            </div>
            <span className="mt-1 text-sm font-medium">
              Driver: {user.lastName} {user.firstName}
            </span>
          </div>
        </div>

        {vehicleInfo && (
          <div className="text-center md:text-right">
            <p className="text-sm font-medium">
              Driver: {user.lastName} - {vehicleInfo.plateNumber}
            </p>
          </div>
        )}

        <div className="flex flex-col items-center">
          <div className="flex items-center gap-2">
            <span className="text-sm font-medium font-mono">{time}</span>
            <Popover>
              <PopoverTrigger asChild>
                <Button variant="outline" size="sm" className="h-8 w-8 p-0 rounded-full">
                  <CalendarIcon className="h-4 w-4" />
                  <span className="sr-only">Open calendar</span>
                </Button>
              </PopoverTrigger>
              <PopoverContent className="w-auto p-0">
                <Calendar mode="single" selected={date} onSelect={setDate} initialFocus />
              </PopoverContent>
            </Popover>
          </div>
          <span className="mt-1 text-xs">{date ? format(date, "PPP") : "Select a date"}</span>
        </div>
      </div>
    </motion.header>
  )
}
