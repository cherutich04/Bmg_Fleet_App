"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface MonthlyTargetCardProps {
  targetData: {
    month: string
    targetPercentage: number
    amountRealized: number
    targetAmount: number
    tripsCompleted: number
    safetyScore?: number
    location?: {
      lastUpdated: string
      destination?: string
    }
  }
}

export function MonthlyTargetCard({ targetData }: MonthlyTargetCardProps) {
  const getProgressColor = (percentage: number) => {
    if (percentage <= 25) return "bg-red-500 dark:bg-red-600"
    if (percentage <= 50) return "bg-orange-500 dark:bg-orange-600"
    if (percentage <= 75) return "bg-emerald-500 dark:bg-emerald-600"
    return "bg-green-700 dark:bg-green-800"
  }

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3, delay: 0.1 }}
    >
      <Card className="card-target overflow-hidden gradient-border">
        <CardHeader className="bg-primary/10">
          <CardTitle className="text-center font-bold text-primary">MONTHLY TARGET</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-5">
          <div>
            <h3 className="font-semibold text-lg">Month: {targetData.month}</h3>
            <div className="mt-2 space-y-3">
              <div>
                <div className="flex items-center justify-between">
                  <span className="text-sm font-medium">Target Achieved: {targetData.targetPercentage}%</span>
                </div>
                <div className="mt-1 h-2 w-full overflow-hidden rounded-full bg-muted">
                  <div
                    className={cn(
                      "h-full transition-all duration-1000 ease-in-out",
                      getProgressColor(targetData.targetPercentage),
                    )}
                    style={{ width: `${targetData.targetPercentage}%` }}
                  />
                </div>
              </div>

              <div className="flex items-center justify-between">
                <div className="text-sm">
                  <span className="font-medium">Amount Realized:</span>{" "}
                  <span className="text-amber-700 dark:text-amber-500">
                    Ksh. {targetData.amountRealized.toLocaleString()}
                  </span>
                </div>
                <div className="text-sm">
                  <span className="font-medium">Set Monthly Target:</span>{" "}
                  <span className="text-amber-700 dark:text-amber-500">
                    Ksh. {targetData.targetAmount.toLocaleString()}
                  </span>
                </div>
              </div>

              <div className="text-sm">
                <span className="font-medium">Trips Completed:</span> {targetData.tripsCompleted} Trips
              </div>

              {targetData.safetyScore !== undefined && (
                <div className="text-sm">
                  <span className="font-medium">Safety Score:</span> {targetData.safetyScore}
                </div>
              )}
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Map snippet</h3>
            <div className="mt-2 space-y-2">
              <div className="h-32 w-full rounded-lg bg-muted/50 backdrop-blur-sm overflow-hidden">
                {/* Map placeholder */}
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                  Location Map
                </div>
              </div>

              {targetData.location && (
                <div className="space-y-1 text-sm">
                  <div>
                    <span className="font-medium">Last updated:</span> {targetData.location.lastUpdated}
                  </div>
                  {targetData.location.destination && (
                    <div>
                      <span className="font-medium">Enroute to:</span> {targetData.location.destination}
                    </div>
                  )}
                </div>
              )}
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
