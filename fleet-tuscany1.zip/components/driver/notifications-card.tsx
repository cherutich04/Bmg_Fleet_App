"use client"

import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { cn } from "@/lib/utils"

interface Alert {
  id: string
  message: string
  type: "maintenance" | "other"
  severity: "high" | "medium" | "low"
}

interface Notification {
  id: string
  message: string
  timestamp: string
}

interface NotificationsCardProps {
  alerts: Alert[]
  notifications: Notification[]
}

export function NotificationsCard({ alerts, notifications }: NotificationsCardProps) {
  const getAlertColor = (severity: string) => {
    switch (severity) {
      case "high":
        return "text-red-600 dark:text-red-400"
      case "medium":
        return "text-orange-600 dark:text-orange-400"
      case "low":
        return "text-green-600 dark:text-green-400"
      default:
        return "text-gray-600 dark:text-gray-400"
    }
  }

  return (
    <motion.div
      initial={{ y: 20, opacity: 0 }}
      animate={{ y: 0, opacity: 1 }}
      transition={{ duration: 0.3, delay: 0.2 }}
    >
      <Card className="card-notification overflow-hidden gradient-border">
        <CardHeader className="bg-primary/10">
          <CardTitle className="text-center font-bold text-primary">NOTIFICATIONS AND ALERTS</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-5">
          <div>
            <h3 className="font-semibold text-lg">Alerts:</h3>
            <div className="mt-2 space-y-2">
              <div>
                <h4 className="text-sm font-medium">Maintenance Alerts</h4>
                <ul className="mt-1 space-y-1">
                  {alerts
                    .filter((alert) => alert.type === "maintenance")
                    .map((alert) => (
                      <li key={alert.id} className={cn("text-sm", getAlertColor(alert.severity))}>
                        {alert.message}
                      </li>
                    ))}
                  {alerts.filter((alert) => alert.type === "maintenance").length === 0 && (
                    <li className="text-sm text-muted-foreground">No maintenance alerts</li>
                  )}
                </ul>
              </div>

              <div>
                <h4 className="text-sm font-medium">Other Alerts</h4>
                <ul className="mt-1 space-y-1">
                  {alerts
                    .filter((alert) => alert.type === "other")
                    .map((alert) => (
                      <li key={alert.id} className={cn("text-sm", getAlertColor(alert.severity))}>
                        {alert.message}
                      </li>
                    ))}
                  {alerts.filter((alert) => alert.type === "other").length === 0 && (
                    <li className="text-sm text-muted-foreground">No other alerts</li>
                  )}
                </ul>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Notifications:</h3>
            <div className="mt-2">
              <h4 className="text-sm font-medium">Recent Activities</h4>
              <ul className="mt-1 space-y-1">
                {notifications.map((notification) => (
                  <li key={notification.id} className="text-sm">
                    {notification.message}
                    <span className="ml-1 text-xs text-muted-foreground">({notification.timestamp})</span>
                  </li>
                ))}
                {notifications.length === 0 && <li className="text-sm text-muted-foreground">No recent activities</li>}
              </ul>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
