"use client"

import { useState } from "react"
import { motion } from "framer-motion"
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Badge } from "@/components/ui/badge"
import { cn } from "@/lib/utils"

interface StatusCardProps {
  vehicleData: {
    startDate: string
    endDate: string
    model: string
    plate: string
    type: string
    status: "active" | "inactive" | "maintenance"
    odometer: number
    fuelEfficiency: number
  }
  onOdometerUpdate: (value: number) => Promise<void>
}

export function StatusCard({ vehicleData, onOdometerUpdate }: StatusCardProps) {
  const [odometer, setOdometer] = useState(vehicleData.odometer.toString())
  const [isUpdating, setIsUpdating] = useState(false)

  const getStatusColor = (status: string) => {
    switch (status) {
      case "active":
        return "bg-green-500 text-white dark:bg-green-600"
      case "inactive":
        return "bg-gray-500 text-white dark:bg-gray-600"
      case "maintenance":
        return "bg-orange-500 text-white dark:bg-orange-600"
      default:
        return "bg-gray-500 text-white dark:bg-gray-600"
    }
  }

  const handleOdometerUpdate = async () => {
    try {
      setIsUpdating(true)
      await onOdometerUpdate(Number.parseFloat(odometer))
      // Success notification could be added here
    } catch (error) {
      console.error("Failed to update odometer:", error)
      // Error notification could be added here
    } finally {
      setIsUpdating(false)
    }
  }

  return (
    <motion.div initial={{ y: 20, opacity: 0 }} animate={{ y: 0, opacity: 1 }} transition={{ duration: 0.3 }}>
      <Card className="card-status overflow-hidden gradient-border">
        <CardHeader className="bg-primary/10">
          <CardTitle className="text-center font-bold text-primary">STATUS</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4 p-5">
          <div>
            <h3 className="font-semibold text-lg">Vehicle Basics</h3>
            <div className="mt-2 space-y-2">
              <div className="text-sm">
                <span className="font-medium">Assigned From:</span> {vehicleData.startDate}{" "}
                <span className="font-medium">To:</span> {vehicleData.endDate}
              </div>
              <div className="flex items-center gap-2">
                <Badge variant="outline" className="bg-background">
                  {vehicleData.model}
                </Badge>
                <Badge className="bg-yellow-300 text-black dark:bg-yellow-400">{vehicleData.plate}</Badge>
                <Badge className={cn("ml-auto", getStatusColor(vehicleData.status))}>
                  {vehicleData.status.charAt(0).toUpperCase() + vehicleData.status.slice(1)}
                </Badge>
              </div>
              <div className="text-sm">
                <span className="font-medium">Type:</span> {vehicleData.type}
              </div>
              <div className="h-32 w-full rounded-lg bg-muted/50 backdrop-blur-sm overflow-hidden">
                {/* Vehicle image placeholder */}
                <div className="flex h-full items-center justify-center text-sm text-muted-foreground">
                  Vehicle Image
                </div>
              </div>
            </div>
          </div>

          <div>
            <h3 className="font-semibold text-lg">Performance</h3>
            <div className="mt-2 space-y-2">
              <div className="text-sm">
                <span className="font-medium">Odometer:</span> {vehicleData.odometer.toFixed(2)} km
              </div>
              <div className="flex items-center gap-2">
                <Input
                  type="number"
                  value={odometer}
                  onChange={(e) => setOdometer(e.target.value)}
                  placeholder="Update odometer reading"
                  className="text-sm"
                />
                <Button size="sm" onClick={handleOdometerUpdate} disabled={isUpdating} className="glow-effect">
                  {isUpdating ? "Saving..." : "Save"}
                </Button>
              </div>
              <div className="flex items-center">
                <Badge className="bg-yellow-300 text-black dark:bg-yellow-400">
                  {vehicleData.fuelEfficiency}L per 100Km
                </Badge>
              </div>
            </div>
          </div>
        </CardContent>
      </Card>
    </motion.div>
  )
}
