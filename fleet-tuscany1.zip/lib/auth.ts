import { cookies } from "next/headers"
import { redirect } from "next/navigation"
import { query } from "./db"
import { z } from "zod"
import bcrypt from "bcrypt"

// User schema validation
const UserSchema = z.object({
  username: z.string().min(3),
  password: z.string().min(6),
})

export type UserRole = "driver" | "admin"

export type User = {
  id: number
  username: string
  role: UserRole
  firstName?: string
  lastName?: string
}

// Authentication functions
export async function login(username: string, password: string, role: UserRole) {
  try {
    // Validate input
    UserSchema.parse({ username, password })

    // Query the appropriate table based on role
    const table = role === "driver" ? "drivers" : "admins"
    const result = await query(
      `SELECT id, username, password, first_name, last_name FROM ${table} WHERE username = $1`,
      [username],
    )

    if (result.rows.length === 0) {
      return { success: false, error: "Invalid username or password" }
    }

    const user = result.rows[0]

    // Compare passwords
    const match = await bcrypt.compare(password, user.password)

    if (!match) {
      return { success: false, error: "Invalid username or password" }
    }

    // Create session
    const sessionId = crypto.randomUUID()
    const expires = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000) // 7 days

    // Store session in database
    await query("INSERT INTO sessions (id, user_id, role, expires) VALUES ($1, $2, $3, $4)", [
      sessionId,
      user.id,
      role,
      expires,
    ])

    // Set cookie
    cookies().set("session_id", sessionId, {
      expires,
      httpOnly: true,
      path: "/",
      secure: process.env.NODE_ENV === "production",
      sameSite: "lax",
    })

    return {
      success: true,
      user: {
        id: user.id,
        username: user.username,
        role,
        firstName: user.first_name,
        lastName: user.last_name,
      },
    }
  } catch (error) {
    console.error("Login error:", error)
    return { success: false, error: "An error occurred during login" }
  }
}

export async function logout() {
  const sessionId = cookies().get("session_id")?.value

  if (sessionId) {
    // Delete session from database
    await query("DELETE FROM sessions WHERE id = $1", [sessionId])

    // Clear cookie
    cookies().delete("session_id")
  }

  return { success: true }
}

export async function getUser(): Promise<User | null> {
  const sessionId = cookies().get("session_id")?.value

  if (!sessionId) {
    return null
  }

  try {
    // Get session from database
    const result = await query(
      `SELECT s.user_id, s.role, 
        CASE 
          WHEN s.role = 'driver' THEN d.username
          WHEN s.role = 'admin' THEN a.username
        END as username,
        CASE 
          WHEN s.role = 'driver' THEN d.first_name
          WHEN s.role = 'admin' THEN a.first_name
        END as first_name,
        CASE 
          WHEN s.role = 'driver' THEN d.last_name
          WHEN s.role = 'admin' THEN a.last_name
        END as last_name
      FROM sessions s
      LEFT JOIN drivers d ON s.user_id = d.id AND s.role = 'driver'
      LEFT JOIN admins a ON s.user_id = a.id AND s.role = 'admin'
      WHERE s.id = $1 AND s.expires > NOW()`,
      [sessionId],
    )

    if (result.rows.length === 0) {
      cookies().delete("session_id")
      return null
    }

    const user = result.rows[0]

    return {
      id: user.user_id,
      username: user.username,
      role: user.role as UserRole,
      firstName: user.first_name,
      lastName: user.last_name,
    }
  } catch (error) {
    console.error("Get user error:", error)
    return null
  }
}

export async function requireAuth(role?: UserRole) {
  const user = await getUser()

  if (!user) {
    redirect("/")
  }

  if (role && user.role !== role) {
    redirect(`/${user.role}/dashboard`)
  }

  return user
}
