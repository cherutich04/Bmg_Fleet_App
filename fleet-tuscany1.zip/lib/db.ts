import { Pool } from "pg"

// Use the provided connection string
const connectionString =
  "postgresql://neondb_owner:npg_dhabwUKO72jW@ep-frosty-violet-a4gmp1kx-pooler.us-east-1.aws.neon.tech/neondb?sslmode=require"

let pool: Pool | null = null

export function getDb() {
  if (!pool) {
    pool = new Pool({
      connectionString,
    })
  }

  return pool
}

export async function query(text: string, params?: any[]) {
  const db = getDb()
  try {
    const result = await db.query(text, params)
    return result
  } catch (error) {
    console.error("Database query error:", error)
    throw error
  }
}
