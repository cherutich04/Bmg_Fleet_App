-- Create the database
-- CREATE DATABASE fleet_management;

-- Connect to the database
-- \c fleet_management

-- Create the drivers table
CREATE TABLE drivers (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE,
  phone VARCHAR(20),
  license_number VARCHAR(50),
  license_expiry DATE,
  profile_picture VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the admins table
CREATE TABLE admins (
  id SERIAL PRIMARY KEY,
  username VARCHAR(50) UNIQUE NOT NULL,
  password VARCHAR(255) NOT NULL,
  first_name VARCHAR(100) NOT NULL,
  last_name VARCHAR(100) NOT NULL,
  email VARCHAR(100) UNIQUE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the sessions table
CREATE TABLE sessions (
  id VARCHAR(255) PRIMARY KEY,
  user_id INTEGER NOT NULL,
  role VARCHAR(10) NOT NULL,
  expires TIMESTAMP NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the vehicles table
CREATE TABLE vehicles (
  id SERIAL PRIMARY KEY,
  plate_number VARCHAR(20) UNIQUE NOT NULL,
  model VARCHAR(100) NOT NULL,
  type VARCHAR(50) NOT NULL,
  status VARCHAR(20) NOT NULL DEFAULT 'active',
  odometer DECIMAL(10, 2) DEFAULT 0,
  fuel_efficiency DECIMAL(5, 2),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the vehicle_assignments table
CREATE TABLE vehicle_assignments (
  id SERIAL PRIMARY KEY,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  start_date DATE NOT NULL,
  end_date DATE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the projects table
CREATE TABLE projects (
  id SERIAL PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the monthly_targets table
CREATE TABLE monthly_targets (
  id SERIAL PRIMARY KEY,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  month INTEGER NOT NULL,
  year INTEGER NOT NULL,
  target_amount DECIMAL(10, 2) NOT NULL,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  UNIQUE(driver_id, month, year)
);

-- Create the income table
CREATE TABLE income (
  id SERIAL PRIMARY KEY,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  hire_type VARCHAR(20) NOT NULL,
  project_id INTEGER REFERENCES projects(id),
  delivery_name VARCHAR(255) NOT NULL,
  date DATE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  payment_method VARCHAR(20) NOT NULL,
  paid_by VARCHAR(100) NOT NULL,
  paid_to VARCHAR(100) NOT NULL,
  receipt_url VARCHAR(255),
  notes TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the expenses table
CREATE TABLE expenses (
  id SERIAL PRIMARY KEY,
  driver_id INTEGER NOT NULL REFERENCES drivers(id),
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  expense_name VARCHAR(255) NOT NULL,
  date DATE NOT NULL,
  amount DECIMAL(10, 2) NOT NULL,
  category VARCHAR(50) NOT NULL,
  payment_method VARCHAR(20) NOT NULL,
  paid_by VARCHAR(100) NOT NULL,
  receipt_url VARCHAR(255),
  notes TEXT,
  status VARCHAR(20) NOT NULL DEFAULT 'pending',
  admin_comments TEXT,
  reviewed_by INTEGER REFERENCES admins(id),
  reviewed_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the alerts table
CREATE TABLE alerts (
  id SERIAL PRIMARY KEY,
  vehicle_id INTEGER REFERENCES vehicles(id),
  driver_id INTEGER REFERENCES drivers(id),
  message TEXT NOT NULL,
  type VARCHAR(50) NOT NULL,
  severity VARCHAR(20) NOT NULL,
  is_resolved BOOLEAN DEFAULT FALSE,
  resolved_by INTEGER REFERENCES admins(id),
  resolved_at TIMESTAMP,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  updated_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the notifications table
CREATE TABLE notifications (
  id SERIAL PRIMARY KEY,
  user_id INTEGER NOT NULL,
  role VARCHAR(10) NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the messages table
CREATE TABLE messages (
  id SERIAL PRIMARY KEY,
  sender_id INTEGER NOT NULL,
  sender_role VARCHAR(10) NOT NULL,
  recipient_id INTEGER NOT NULL,
  recipient_role VARCHAR(10) NOT NULL,
  message TEXT NOT NULL,
  is_read BOOLEAN DEFAULT FALSE,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Create the vehicle_locations table
CREATE TABLE vehicle_locations (
  id SERIAL PRIMARY KEY,
  vehicle_id INTEGER NOT NULL REFERENCES vehicles(id),
  latitude DECIMAL(10, 8) NOT NULL,
  longitude DECIMAL(11, 8) NOT NULL,
  timestamp TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
  destination VARCHAR(255)
);

-- Insert sample data for testing
-- Sample admin
INSERT INTO admins (username, password, first_name, last_name, email)
VALUES ('admin', '$2b$10$X7VYVy9H5NvNvUYP7JK3XOQcwHXEFmUDnYGRmyQtFvs4.TPbgDXuy', 'Admin', 'User', 'admin@bmg.com');
-- Password is 'password'

-- Sample driver
INSERT INTO drivers (username, password, first_name, last_name, email, phone, license_number, license_expiry)
VALUES ('driver1', '$2b$10$X7VYVy9H5NvNvUYP7JK3XOQcwHXEFmUDnYGRmyQtFvs4.TPbgDXuy', 'John', 'Doe', 'john@example.com', '+254712345678', 'DL12345', '2024-12-31');
-- Password is 'password'

-- Sample vehicle
INSERT INTO vehicles (plate_number, model, type, status, odometer, fuel_efficiency)
VALUES ('KDG 442X', 'Land Cruiser (LC-79)', 'Pickup Truck', 'active', 181771.60, 10.0);

-- Sample vehicle assignment
INSERT INTO vehicle_assignments (vehicle_id, driver_id, start_date, end_date)
VALUES (1, 1, '2023-01-01', '2023-12-31');

-- Sample projects
INSERT INTO projects (name)
VALUES 
  ('Kaberewo'),
  ('MTRH'),
  ('Nauyapong'),
  ('Kaptarkok');

-- Sample monthly target
INSERT INTO monthly_targets (driver_id, month, year, target_amount)
VALUES (1, 4, 2023, 200000);
